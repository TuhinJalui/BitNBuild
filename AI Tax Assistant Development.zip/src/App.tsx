import React, { useState, Suspense, lazy } from 'react';
import { AuthPage } from './components/auth/AuthPage';
import { Dashboard } from './components/dashboard/Dashboard';
import { TaxCalculator } from './components/dashboard/TaxCalculator';
import { CibilScoreCard } from './components/dashboard/CibilScoreCard';
import { FileUploadCard } from './components/dashboard/FileUploadCard';
import { TaxSavingsRecommendations } from './components/dashboard/TaxSavingsRecommendations';
import { ProfilePage } from './components/profile/ProfilePage';
import { Navbar } from './components/layout/Navbar';
import { LanguageProvider } from './components/language/LanguageProvider';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner@2.0.3';

// Lazy load heavy components to prevent timeout
const CibilSimulator = lazy(() => import('./components/cibil/CibilSimulator').then(module => ({ default: module.CibilSimulator })));
const EnhancedAIAssistant = lazy(() => import('./components/ai/EnhancedAIAssistant').then(module => ({ default: module.EnhancedAIAssistant })));
const TransactionAnalyzer = lazy(() => import('./components/finance/TransactionAnalyzer').then(module => ({ default: module.TransactionAnalyzer })));
const GSTAssistant = lazy(() => import('./components/gst/GSTAssistant').then(module => ({ default: module.GSTAssistant })));
const InvestmentRecommender = lazy(() => import('./components/investments/InvestmentRecommender').then(module => ({ default: module.InvestmentRecommender })));
const RealTimeTaxCalculator = lazy(() => import('./components/calculator/RealTimeTaxCalculator').then(module => ({ default: module.RealTimeTaxCalculator })));
const VoiceAssistant = lazy(() => import('./components/VoiceAssistant').then(module => ({ default: module.VoiceAssistant })));

interface User {
  name: string;
  email: string;
  isAuthenticated: boolean;
}

// Error Boundary Component
class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; error?: Error }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Error caught by boundary:', error, errorInfo);
    toast.error('Something went wrong. Please try refreshing the page.');
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
          <div className="text-center space-y-4">
            <h2 className="text-2xl font-bold text-foreground">Oops! Something went wrong</h2>
            <p className="text-muted-foreground">We're sorry for the inconvenience. Please try refreshing the page.</p>
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90"
            >
              Refresh Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// Loading Component
const Loading = ({ message = "Loading..." }: { message?: string }) => (
  <div className="flex items-center justify-center min-h-[400px]">
    <div className="text-center space-y-4">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
      <p className="text-muted-foreground">{message}</p>
    </div>
  </div>
);

export default function App() {
  const [user, setUser] = useState<User>({
    name: '',
    email: '',
    isAuthenticated: false
  });
  
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [isAIAssistantOpen, setIsAIAssistantOpen] = useState(false);

  const handleLogin = (email: string, password: string) => {
    try {
      setUser({
        name: email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1),
        email: email,
        isAuthenticated: true
      });
      toast.success('Welcome to TaxWise! 🎉');
    } catch (error) {
      toast.error('Login failed. Please try again.');
    }
  };

  const handleRegister = (name: string, email: string, password: string) => {
    try {
      setUser({
        name: name,
        email: email,
        isAuthenticated: true
      });
      toast.success('Account created successfully! Welcome to TaxWise! 🎉');
    } catch (error) {
      toast.error('Registration failed. Please try again.');
    }
  };

  const handleGoogleLogin = () => {
    try {
      setUser({
        name: 'Demo User',
        email: 'demo@taxwise.com',
        isAuthenticated: true
      });
      toast.success('Signed in with Google successfully! 🎉');
    } catch (error) {
      toast.error('Google sign-in failed. Please try again.');
    }
  };

  const handleLogout = () => {
    setUser({
      name: '',
      email: '',
      isAuthenticated: false
    });
    setCurrentPage('dashboard');
    toast.success('Logged out successfully');
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  const handleUpdateProfile = (profileData: any) => {
    setUser(prev => ({
      ...prev,
      name: profileData.name,
      email: profileData.email
    }));
    toast.success('Profile updated successfully!');
  };

  const toggleAIAssistant = () => {
    setIsAIAssistantOpen(!isAIAssistantOpen);
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard user={user} />;
      case 'calculator':
        return (
          <Suspense fallback={<Loading message="Loading Tax Calculator..." />}>
            <RealTimeTaxCalculator />
          </Suspense>
        );
      case 'cibil':
        return (
          <Suspense fallback={<Loading message="Loading CIBIL Simulator..." />}>
            <CibilSimulator />
          </Suspense>
        );
      case 'documents':
        return (
          <div className="space-y-6">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold">Document Management</h1>
              <p className="text-muted-foreground">Upload and manage your financial documents with AI analysis</p>
            </div>
            <FileUploadCard />
          </div>
        );
      case 'insights':
        return (
          <Suspense fallback={<Loading message="Loading Investment Recommendations..." />}>
            <InvestmentRecommender />
          </Suspense>
        );
      case 'analyzer':
        return (
          <Suspense fallback={<Loading message="Loading Transaction Analyzer..." />}>
            <TransactionAnalyzer />
          </Suspense>
        );
      case 'gst':
        return (
          <Suspense fallback={<Loading message="Loading GST Assistant..." />}>
            <GSTAssistant />
          </Suspense>
        );
      case 'profile':
        return <ProfilePage user={user} onUpdateProfile={handleUpdateProfile} />;
      default:
        return <Dashboard user={user} />;
    }
  };

  if (!user.isAuthenticated) {
    return (
      <ErrorBoundary>
        <LanguageProvider>
          <div className="min-h-screen bg-background dark">
            <AuthPage
              onLogin={handleLogin}
              onRegister={handleRegister}
              onGoogleLogin={handleGoogleLogin}
            />
            <Toaster />
          </div>
        </LanguageProvider>
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary>
      <LanguageProvider>
        <div className="min-h-screen bg-background dark">
          <Navbar
            user={user}
            currentPage={currentPage}
            onNavigate={handleNavigate}
            onLogout={handleLogout}
          />
          
          <main className="container mx-auto px-4 py-6">
            <ErrorBoundary>
              {renderCurrentPage()}
            </ErrorBoundary>
          </main>

          <Suspense fallback={null}>
            <EnhancedAIAssistant 
              isOpen={isAIAssistantOpen} 
              onToggle={toggleAIAssistant}
              onNavigate={handleNavigate}
              userProfile={user}
            />
          </Suspense>
          
          <Suspense fallback={null}>
            <VoiceAssistant 
              onNavigate={handleNavigate}
              onAction={(action, data) => {
                try {
                  switch (action) {
                    case 'calculate-tax':
                      setCurrentPage('calculator');
                      break;
                    case 'show-recommendations':
                      setCurrentPage('insights');
                      break;
                    case 'analyze-transactions':
                      setCurrentPage('analyzer');
                      break;
                    case 'gst-help':
                      setCurrentPage('gst');
                      break;
                    default:
                      console.log('Voice action:', action, data);
                  }
                } catch (error) {
                  console.error('Voice action error:', error);
                  toast.error('Voice command failed. Please try again.');
                }
              }}
            />
          </Suspense>
          
          <Toaster />
        </div>
      </LanguageProvider>
    </ErrorBoundary>
  );
}