import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import { Badge } from '../ui/badge';
import { 
  Upload, 
  FileText, 
  File, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  Brain,
  Download
} from 'lucide-react';

export function FileUploadCard() {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);

  const uploadedFiles = [
    {
      name: 'Bank_Statement_HDFC_Aug2024.pdf',
      type: 'Bank Statement',
      status: 'processed',
      uploadDate: '2024-09-25',
      insights: ['₹104,000 salary credited', '₹35,000 rent payment', '12 transactions analyzed']
    },
    {
      name: 'Form16_FY2023-24.pdf',
      type: 'Form 16',
      status: 'processed',
      uploadDate: '2024-09-20',
      insights: ['₹12,50,000 gross income', '₹1,50,000 tax deducted', 'Old regime used']
    },
    {
      name: 'Credit_Card_Statement_Aug2024.pdf',
      type: 'Credit Card Statement',
      status: 'processing',
      uploadDate: '2024-09-24',
      insights: []
    },
    {
      name: 'Investment_Statement_Zerodha.csv',
      type: 'Investment Statement',
      status: 'pending',
      uploadDate: '2024-09-23',
      insights: []
    }
  ];

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    // Handle file upload logic here
    simulateUpload();
  };

  const simulateUpload = () => {
    setIsProcessing(true);
    setUploadProgress(0);
    
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsProcessing(false);
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'processed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'processing':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'pending':
        return <AlertCircle className="h-4 w-4 text-orange-500" />;
      default:
        return <File className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: { [key: string]: { variant: any; label: string } } = {
      processed: { variant: 'default', label: 'Processed' },
      processing: { variant: 'secondary', label: 'Processing' },
      pending: { variant: 'outline', label: 'Pending' }
    };
    const config = variants[status] || { variant: 'outline', label: 'Unknown' };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  return (
    <div className="space-y-6">
      {/* Upload Zone */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Upload className="h-5 w-5" />
            Smart Document Upload
          </CardTitle>
          <CardDescription className="text-muted-foreground">
            Upload your financial documents for AI-powered analysis and insights
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              isDragging
                ? 'border-primary bg-primary/5'
                : 'border-muted-foreground/25 hover:border-primary/50'
            }`}
            onDragEnter={handleDragEnter}
            onDragOver={(e) => e.preventDefault()}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <div className="space-y-4">
              <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                <Upload className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-foreground">Drop your files here or click to browse</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Supports PDF, CSV, XLS files up to 10MB
                </p>
              </div>
              <div className="flex justify-center gap-2">
                <Button onClick={simulateUpload}>
                  Choose Files
                </Button>
                <Button variant="outline">
                  <Brain className="h-4 w-4 mr-2" />
                  AI Scan
                </Button>
              </div>
            </div>
          </div>

          {(isProcessing || uploadProgress > 0) && (
            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-foreground">Processing document...</span>
                <span className="text-foreground">{uploadProgress}%</span>
              </div>
              <Progress value={uploadProgress} />
            </div>
          )}

          {/* Supported Document Types */}
          <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-muted/30 rounded-lg">
              <FileText className="h-6 w-6 mx-auto mb-2 text-primary" />
              <p className="text-xs font-medium text-foreground">Bank Statements</p>
            </div>
            <div className="text-center p-3 bg-muted/30 rounded-lg">
              <FileText className="h-6 w-6 mx-auto mb-2 text-primary" />
              <p className="text-xs font-medium text-foreground">Form 16</p>
            </div>
            <div className="text-center p-3 bg-muted/30 rounded-lg">
              <FileText className="h-6 w-6 mx-auto mb-2 text-primary" />
              <p className="text-xs font-medium text-foreground">Credit Cards</p>
            </div>
            <div className="text-center p-3 bg-muted/30 rounded-lg">
              <FileText className="h-6 w-6 mx-auto mb-2 text-primary" />
              <p className="text-xs font-medium text-foreground">Investments</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Uploaded Files */}
      <Card>
        <CardHeader>
          <CardTitle className="text-foreground">Uploaded Documents</CardTitle>
          <CardDescription className="text-muted-foreground">
            AI has analyzed your documents and extracted key insights
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {uploadedFiles.map((file, index) => (
              <div key={index} className="flex items-start gap-4 p-4 border rounded-lg">
                <div className="flex items-center gap-3 flex-1">
                  {getStatusIcon(file.status)}
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-sm text-foreground">{file.name}</p>
                      {getStatusBadge(file.status)}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {file.type} • Uploaded {new Date(file.uploadDate).toLocaleDateString()}
                    </p>
                    
                    {file.insights.length > 0 && (
                      <div className="mt-2 space-y-1">
                        <p className="text-xs font-medium text-primary">AI Insights:</p>
                        {file.insights.map((insight, i) => (
                          <p key={i} className="text-xs text-muted-foreground">• {insight}</p>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button variant="ghost" size="sm">
                    <Download className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Brain className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}