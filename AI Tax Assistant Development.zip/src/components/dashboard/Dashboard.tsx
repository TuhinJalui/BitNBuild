import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  FileText, 
  Upload, 
  Calculator,
  CreditCard,
  PieChart,
  BarChart3,
  Target
} from 'lucide-react';
import { TaxCalculator } from './TaxCalculator';
import { CibilScoreCard } from './CibilScoreCard';
import { FinancialOverview } from './FinancialOverview';
import { RecentTransactions } from './RecentTransactions';
import { FileUploadCard } from './FileUploadCard';
import { TaxSavingsRecommendations } from './TaxSavingsRecommendations';

interface DashboardProps {
  user: {
    name: string;
    email: string;
  };
}

export function Dashboard({ user }: DashboardProps) {
  const currentTaxYear = new Date().getFullYear();
  
  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Welcome back, {user.name}!</h1>
          <p className="text-muted-foreground">Here's your financial overview for FY {currentTaxYear}-{(currentTaxYear + 1).toString().slice(-2)}</p>
        </div>
        <div className="flex gap-3">
          <Button className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            Upload Documents
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Calculator className="h-4 w-4" />
            Calculate Tax
          </Button>
        </div>
      </div>

      {/* Quick Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-foreground">Total Income</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">₹12,50,000</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-400 flex items-center gap-1">
                <TrendingUp className="h-3 w-3" />
                +12% from last year
              </span>
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-foreground">Tax Liability</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">₹1,85,000</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-400 flex items-center gap-1">
                <TrendingDown className="h-3 w-3" />
                Reduced by ₹45,000
              </span>
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-foreground">Tax Savings</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">₹1,50,000</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-400">80C: ₹1,50,000 utilized</span>
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-foreground">CIBIL Score</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground flex items-center gap-2">
              780
              <Badge variant="secondary" className="text-xs bg-green-500 text-white">Excellent</Badge>
            </div>
            <Progress value={78} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
          <TabsTrigger value="overview" className="flex items-center gap-1 md:gap-2">
            <PieChart className="h-4 w-4" />
            <span className="hidden sm:inline">Overview</span>
          </TabsTrigger>
          <TabsTrigger value="tax-calculator" className="flex items-center gap-1 md:gap-2">
            <Calculator className="h-4 w-4" />
            <span className="hidden sm:inline">Tax Calculator</span>
          </TabsTrigger>
          <TabsTrigger value="cibil" className="flex items-center gap-1 md:gap-2">
            <CreditCard className="h-4 w-4" />
            <span className="hidden sm:inline">CIBIL</span>
          </TabsTrigger>
          <TabsTrigger value="documents" className="flex items-center gap-1 md:gap-2">
            <Upload className="h-4 w-4" />
            <span className="hidden sm:inline">Documents</span>
          </TabsTrigger>
          <TabsTrigger value="insights" className="flex items-center gap-1 md:gap-2">
            <BarChart3 className="h-4 w-4" />
            <span className="hidden sm:inline">Insights</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <FinancialOverview />
            <CibilScoreCard />
          </div>
          <RecentTransactions />
        </TabsContent>

        <TabsContent value="tax-calculator">
          <TaxCalculator />
        </TabsContent>

        <TabsContent value="cibil">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <CibilScoreCard detailed />
            <Card>
              <CardHeader>
                <CardTitle className="text-white">Credit Improvement Tips</CardTitle>
                <CardDescription className="text-white/70">AI-powered recommendations to boost your CIBIL score</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 bg-primary/5 rounded-lg">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium text-white">Pay down credit card balances</p>
                      <p className="text-sm text-white/70">Reduce utilization from 45% to below 30% for +25 points</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 bg-primary/5 rounded-lg">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium text-white">Increase credit limits</p>
                      <p className="text-sm text-white/70">Request limit increases on existing cards</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 bg-primary/5 rounded-lg">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium text-white">Set up autopay</p>
                      <p className="text-sm text-white/70">Never miss a payment to maintain perfect history</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="documents">
          <FileUploadCard />
        </TabsContent>

        <TabsContent value="insights">
          <TaxSavingsRecommendations />
        </TabsContent>
      </Tabs>
    </div>
  );
}