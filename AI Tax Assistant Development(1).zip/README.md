
  # AI Tax Assistant Development

  This is a code bundle for AI Tax Assistant Development. The original project is available at https://www.figma.com/design/9IVUEdpQtd2CQkCUqUz0SG/AI-Tax-Assistant-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  