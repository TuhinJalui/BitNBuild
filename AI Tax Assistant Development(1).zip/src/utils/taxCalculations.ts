// Indian Tax Calculation Utilities for FY 2024-25

export interface TaxableIncome {
  basicSalary: number;
  hra: number;
  specialAllowance: number;
  bonus: number;
  otherIncome: number;
  businessIncome: number;
  capitalGains: number;
  interestIncome: number;
}

export interface Deductions {
  section80C: number; // max 150000
  section80D: number; // max 25000/50000
  section80G: number; // donations
  section24: number; // home loan interest max 200000
  standardDeduction: number; // 50000 for salaried
  professionalTax: number;
  epf: number;
  nps: number;
}

export interface TaxRegime {
  oldRegime: boolean;
  newRegime: boolean;
}

// Tax Slabs for New Regime FY 2024-25
const newRegimeTaxSlabs = [
  { min: 0, max: 300000, rate: 0 },
  { min: 300000, max: 600000, rate: 5 },
  { min: 600000, max: 900000, rate: 10 },
  { min: 900000, max: 1200000, rate: 15 },
  { min: 1200000, max: 1500000, rate: 20 },
  { min: 1500000, max: Infinity, rate: 30 }
];

// Tax Slabs for Old Regime FY 2024-25
const oldRegimeTaxSlabs = [
  { min: 0, max: 250000, rate: 0 },
  { min: 250000, max: 500000, rate: 5 },
  { min: 500000, max: 1000000, rate: 20 },
  { min: 1000000, max: Infinity, rate: 30 }
];

export function calculateTotalIncome(income: TaxableIncome): number {
  return (
    income.basicSalary +
    income.hra +
    income.specialAllowance +
    income.bonus +
    income.otherIncome +
    income.businessIncome +
    income.capitalGains +
    income.interestIncome
  );
}

export function calculateTotalDeductions(deductions: Deductions, isOldRegime: boolean): number {
  if (!isOldRegime) {
    // New regime has limited deductions
    return deductions.standardDeduction;
  }

  return (
    Math.min(deductions.section80C, 150000) +
    Math.min(deductions.section80D, 25000) +
    deductions.section80G +
    Math.min(deductions.section24, 200000) +
    deductions.standardDeduction +
    deductions.professionalTax +
    deductions.epf +
    Math.min(deductions.nps, 50000)
  );
}

export function calculateTaxableIncome(
  totalIncome: number,
  totalDeductions: number
): number {
  return Math.max(0, totalIncome - totalDeductions);
}

export function calculateIncomeTax(taxableIncome: number, isOldRegime: boolean): number {
  const slabs = isOldRegime ? oldRegimeTaxSlabs : newRegimeTaxSlabs;
  let tax = 0;

  for (const slab of slabs) {
    if (taxableIncome > slab.min) {
      const taxableInThisSlab = Math.min(taxableIncome, slab.max) - slab.min;
      tax += (taxableInThisSlab * slab.rate) / 100;
    }
  }

  return tax;
}

export function calculateCess(incomeTax: number): number {
  return incomeTax * 0.04; // 4% Health and Education Cess
}

export function calculateSurcharge(taxableIncome: number, incomeTax: number): number {
  if (taxableIncome > 10000000) {
    return incomeTax * 0.37; // 37% surcharge for income > 1 crore (with marginal relief)
  } else if (taxableIncome > 5000000) {
    return incomeTax * 0.25; // 25% surcharge for income > 50 lakhs
  } else if (taxableIncome > 1000000) {
    return incomeTax * 0.10; // 10% surcharge for income > 10 lakhs
  }
  return 0;
}

export function calculateTotalTax(
  income: TaxableIncome,
  deductions: Deductions,
  isOldRegime: boolean
): {
  totalIncome: number;
  totalDeductions: number;
  taxableIncome: number;
  incomeTax: number;
  surcharge: number;
  cess: number;
  totalTax: number;
  taxSaved: number;
  effectiveRate: number;
} {
  const totalIncome = calculateTotalIncome(income);
  const totalDeductions = calculateTotalDeductions(deductions, isOldRegime);
  const taxableIncome = calculateTaxableIncome(totalIncome, totalDeductions);
  const incomeTax = calculateIncomeTax(taxableIncome, isOldRegime);
  const surcharge = calculateSurcharge(taxableIncome, incomeTax);
  const cess = calculateCess(incomeTax + surcharge);
  const totalTax = incomeTax + surcharge + cess;
  
  // Calculate tax without deductions for tax saved
  const taxWithoutDeductions = calculateIncomeTax(totalIncome, false) + 
    calculateSurcharge(totalIncome, calculateIncomeTax(totalIncome, false)) +
    calculateCess(calculateIncomeTax(totalIncome, false) + calculateSurcharge(totalIncome, calculateIncomeTax(totalIncome, false)));
  
  const taxSaved = Math.max(0, taxWithoutDeductions - totalTax);
  const effectiveRate = totalIncome > 0 ? (totalTax / totalIncome) * 100 : 0;

  return {
    totalIncome,
    totalDeductions,
    taxableIncome,
    incomeTax,
    surcharge,
    cess,
    totalTax,
    taxSaved,
    effectiveRate
  };
}

export function compareRegimes(
  income: TaxableIncome,
  deductions: Deductions
): {
  oldRegime: ReturnType<typeof calculateTotalTax>;
  newRegime: ReturnType<typeof calculateTotalTax>;
  recommendation: 'old' | 'new';
  savings: number;
} {
  const oldRegimeCalc = calculateTotalTax(income, deductions, true);
  const newRegimeCalc = calculateTotalTax(income, deductions, false);
  
  const recommendation = oldRegimeCalc.totalTax < newRegimeCalc.totalTax ? 'old' : 'new';
  const savings = Math.abs(oldRegimeCalc.totalTax - newRegimeCalc.totalTax);

  return {
    oldRegime: oldRegimeCalc,
    newRegime: newRegimeCalc,
    recommendation,
    savings
  };
}

// Investment recommendations based on tax saving
export function getInvestmentRecommendations(
  currentDeductions: Deductions,
  targetSavings: number
): Array<{
  section: string;
  instrument: string;
  maxAmount: number;
  currentAmount: number;
  additionalInvestment: number;
  taxSaving: number;
  description: string;
}> {
  const recommendations = [];

  // Section 80C recommendations
  const section80CUsed = currentDeductions.section80C;
  const section80CRemaining = Math.max(0, 150000 - section80CUsed);
  
  if (section80CRemaining > 0) {
    recommendations.push({
      section: '80C',
      instrument: 'ELSS Mutual Funds',
      maxAmount: 150000,
      currentAmount: section80CUsed,
      additionalInvestment: Math.min(section80CRemaining, targetSavings * 3.33),
      taxSaving: Math.min(section80CRemaining, targetSavings * 3.33) * 0.30,
      description: 'Tax-saving mutual funds with 3-year lock-in'
    });

    recommendations.push({
      section: '80C',
      instrument: 'PPF',
      maxAmount: 150000,
      currentAmount: section80CUsed,
      additionalInvestment: Math.min(section80CRemaining, targetSavings * 3.33),
      taxSaving: Math.min(section80CRemaining, targetSavings * 3.33) * 0.30,
      description: '15-year lock-in with tax-free returns'
    });
  }

  // Section 80D recommendations
  const section80DUsed = currentDeductions.section80D;
  const section80DRemaining = Math.max(0, 25000 - section80DUsed);
  
  if (section80DRemaining > 0) {
    recommendations.push({
      section: '80D',
      instrument: 'Health Insurance',
      maxAmount: 25000,
      currentAmount: section80DUsed,
      additionalInvestment: section80DRemaining,
      taxSaving: section80DRemaining * 0.30,
      description: 'Medical insurance premiums'
    });
  }

  // NPS recommendations
  const npsUsed = currentDeductions.nps;
  const npsRemaining = Math.max(0, 50000 - npsUsed);
  
  if (npsRemaining > 0) {
    recommendations.push({
      section: '80CCD(1B)',
      instrument: 'NPS',
      maxAmount: 50000,
      currentAmount: npsUsed,
      additionalInvestment: npsRemaining,
      taxSaving: npsRemaining * 0.30,
      description: 'Additional NPS contribution over 80C limit'
    });
  }

  return recommendations.sort((a, b) => b.taxSaving - a.taxSaving);
}