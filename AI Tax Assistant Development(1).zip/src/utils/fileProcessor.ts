// Advanced File Processing Utilities for TaxWise
import { parseCSV, analyzeTransactions, generateInsights, type TransactionData } from './csvParser';

export interface ProcessedFileData {
  fileName: string;
  fileType: 'pdf' | 'csv' | 'xlsx' | 'xls';
  documentType: 'bank_statement' | 'form16' | 'credit_card' | 'salary_slip' | 'investment' | 'other';
  extractedData: any;
  insights: string[];
  taxRelevantData: TaxRelevantData;
  analysis: FileAnalysis;
}

export interface TaxRelevantData {
  income: {
    salary?: number;
    interest?: number;
    dividend?: number;
    capitalGains?: number;
    business?: number;
    other?: number;
  };
  deductions: {
    section80C?: number;
    section80D?: number;
    section80G?: number;
    section24?: number;
    hra?: number;
  };
  expenses: {
    total: number;
    categories: Record<string, number>;
  };
}

export interface FileAnalysis {
  totalTransactions?: number;
  averageMonthlyIncome?: number;
  averageMonthlyExpenses?: number;
  savingsRate?: number;
  topExpenseCategories?: Array<{ category: string; amount: number; percentage: number }>;
  taxSavingOpportunities?: Array<{ section: string; currentAmount: number; maxLimit: number; potentialSaving: number }>;
  riskFactors?: string[];
  recommendations?: string[];
}

export class FileProcessor {
  static async processFile(file: File): Promise<ProcessedFileData> {
    const fileName = file.name;
    const fileType = this.getFileType(fileName);
    const documentType = this.detectDocumentType(fileName);

    let extractedData: any = {};
    let insights: string[] = [];
    let taxRelevantData: TaxRelevantData = this.initializeTaxData();
    let analysis: FileAnalysis = {};

    try {
      switch (fileType) {
        case 'csv':
          const result = await this.processCSV(file, documentType);
          extractedData = result.extractedData;
          insights = result.insights;
          taxRelevantData = result.taxRelevantData;
          analysis = result.analysis;
          break;
        case 'pdf':
          const pdfResult = await this.processPDF(file, documentType);
          extractedData = pdfResult.extractedData;
          insights = pdfResult.insights;
          taxRelevantData = pdfResult.taxRelevantData;
          analysis = pdfResult.analysis;
          break;
        case 'xlsx':
        case 'xls':
          const excelResult = await this.processExcel(file, documentType);
          extractedData = excelResult.extractedData;
          insights = excelResult.insights;
          taxRelevantData = excelResult.taxRelevantData;
          analysis = excelResult.analysis;
          break;
        default:
          throw new Error(`Unsupported file type: ${fileType}`);
      }

      return {
        fileName,
        fileType,
        documentType,
        extractedData,
        insights,
        taxRelevantData,
        analysis
      };
    } catch (error) {
      console.error('File processing error:', error);
      throw new Error(`Failed to process ${fileName}: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private static getFileType(fileName: string): 'pdf' | 'csv' | 'xlsx' | 'xls' {
    const extension = fileName.toLowerCase().split('.').pop();
    switch (extension) {
      case 'pdf': return 'pdf';
      case 'csv': return 'csv';
      case 'xlsx': return 'xlsx';
      case 'xls': return 'xls';
      default: throw new Error(`Unsupported file extension: ${extension}`);
    }
  }

  private static detectDocumentType(fileName: string): ProcessedFileData['documentType'] {
    const name = fileName.toLowerCase();
    if (name.includes('bank') || name.includes('statement')) return 'bank_statement';
    if (name.includes('form16') || name.includes('form 16')) return 'form16';
    if (name.includes('credit') || name.includes('card')) return 'credit_card';
    if (name.includes('salary') || name.includes('payslip')) return 'salary_slip';
    if (name.includes('investment') || name.includes('mutual') || name.includes('sip')) return 'investment';
    return 'other';
  }

  private static initializeTaxData(): TaxRelevantData {
    return {
      income: {},
      deductions: {},
      expenses: {
        total: 0,
        categories: {}
      }
    };
  }

  private static async processCSV(file: File, documentType: ProcessedFileData['documentType']) {
    const content = await this.readFileAsText(file);
    const fileTypeForParser = documentType === 'salary_slip' ? 'salary' : 
                             documentType === 'investment' ? 'investments' : 'transactions';
    
    const parsedData = parseCSV(content, fileTypeForParser);
    
    let extractedData: any = {};
    let insights: string[] = [];
    let taxRelevantData = this.initializeTaxData();
    let analysis: FileAnalysis = {};

    if (fileTypeForParser === 'transactions') {
      const transactionAnalysis = analyzeTransactions(parsedData);
      insights = generateInsights(parsedData);
      
      extractedData = transactionAnalysis;
      analysis = {
        totalTransactions: transactionAnalysis.totalIncome > 0 ? 
          Object.keys(transactionAnalysis.monthlyTrends).length : 0,
        averageMonthlyIncome: transactionAnalysis.totalIncome / 12,
        averageMonthlyExpenses: transactionAnalysis.totalExpenses / 12,
        savingsRate: ((transactionAnalysis.totalIncome - transactionAnalysis.totalExpenses) / transactionAnalysis.totalIncome) * 100,
        topExpenseCategories: Object.entries(transactionAnalysis.categoryBreakdown)
          .map(([category, amount]) => ({
            category,
            amount: amount as number,
            percentage: ((amount as number) / transactionAnalysis.totalExpenses) * 100
          }))
          .sort((a, b) => b.amount - a.amount)
          .slice(0, 5)
      };

      // Extract tax-relevant data
      taxRelevantData.income.salary = this.extractSalaryFromTransactions(parsedData);
      taxRelevantData.income.interest = this.extractInterestIncome(parsedData);
      taxRelevantData.deductions = transactionAnalysis.deductibleExpenses;
      taxRelevantData.expenses.total = transactionAnalysis.totalExpenses;
      taxRelevantData.expenses.categories = transactionAnalysis.categoryBreakdown;

      // Generate tax saving opportunities
      analysis.taxSavingOpportunities = this.generateTaxSavingOpportunities(taxRelevantData);
      analysis.recommendations = this.generateRecommendations(analysis, taxRelevantData);
    }

    return { extractedData, insights, taxRelevantData, analysis };
  }

  private static async processPDF(file: File, documentType: ProcessedFileData['documentType']) {
    // In a real implementation, this would use a PDF parsing library like pdf-parse
    // For now, we'll simulate PDF processing based on document type
    
    await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate processing time
    
    let extractedData: any = {};
    let insights: string[] = [];
    let taxRelevantData = this.initializeTaxData();
    let analysis: FileAnalysis = {};

    switch (documentType) {
      case 'form16':
        extractedData = {
          employeeName: 'Sample Employee',
          panNumber: 'ABCDE1234F',
          assessmentYear: '2024-25',
          grossSalary: 1250000,
          tdsDeducted: 150000,
          taxRegime: 'old',
          deductions: {
            section80C: 150000,
            section80D: 25000,
            standardDeduction: 50000
          }
        };
        
        insights = [
          `Gross annual salary: ₹${extractedData.grossSalary.toLocaleString()}`,
          `TDS deducted: ₹${extractedData.tdsDeducted.toLocaleString()}`,
          `Tax regime: ${extractedData.taxRegime.charAt(0).toUpperCase() + extractedData.taxRegime.slice(1)} regime`,
          `Section 80C utilized: ₹${extractedData.deductions.section80C.toLocaleString()}`,
          `Section 80D utilized: ₹${extractedData.deductions.section80D.toLocaleString()}`
        ];

        taxRelevantData.income.salary = extractedData.grossSalary;
        taxRelevantData.deductions = extractedData.deductions;
        
        analysis = {
          recommendations: [
            'Consider maximizing Section 80C deduction if not fully utilized',
            'Evaluate tax regime choice for next year',
            'Plan advance tax payments based on TDS vs liability'
          ]
        };
        break;

      case 'bank_statement':
        extractedData = {
          accountNumber: '****1234',
          statementPeriod: 'Aug 2024',
          openingBalance: 75000,
          closingBalance: 68000,
          totalCredits: 125000,
          totalDebits: 132000,
          transactionCount: 47
        };

        insights = [
          `${extractedData.transactionCount} transactions processed`,
          `Total credits: ₹${extractedData.totalCredits.toLocaleString()}`,
          `Total debits: ₹${extractedData.totalDebits.toLocaleString()}`,
          `Net change: ₹${(extractedData.closingBalance - extractedData.openingBalance).toLocaleString()}`,
          'Salary credit pattern detected'
        ];

        analysis = {
          averageMonthlyIncome: extractedData.totalCredits,
          averageMonthlyExpenses: extractedData.totalDebits,
          savingsRate: ((extractedData.totalCredits - extractedData.totalDebits) / extractedData.totalCredits) * 100
        };
        break;

      default:
        extractedData = { message: 'PDF processed successfully' };
        insights = ['Document processed', 'Key data extracted'];
    }

    return { extractedData, insights, taxRelevantData, analysis };
  }

  private static async processExcel(file: File, documentType: ProcessedFileData['documentType']) {
    // For Excel files, we'd typically use a library like xlsx
    // For now, simulate Excel processing
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    return {
      extractedData: { message: 'Excel file processed' },
      insights: ['Excel data extracted', 'Financial analysis completed'],
      taxRelevantData: this.initializeTaxData(),
      analysis: {}
    };
  }

  private static readFileAsText(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target?.result as string);
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsText(file);
    });
  }

  private static extractSalaryFromTransactions(transactions: TransactionData[]): number {
    return transactions
      .filter(t => t.type === 'credit' && (
        t.description.toLowerCase().includes('salary') ||
        t.description.toLowerCase().includes('pay') ||
        t.category === 'salary'
      ))
      .reduce((sum, t) => sum + t.amount, 0);
  }

  private static extractInterestIncome(transactions: TransactionData[]): number {
    return transactions
      .filter(t => t.type === 'credit' && (
        t.description.toLowerCase().includes('interest') ||
        t.category === 'interest'
      ))
      .reduce((sum, t) => sum + t.amount, 0);
  }

  private static generateTaxSavingOpportunities(taxData: TaxRelevantData): FileAnalysis['taxSavingOpportunities'] {
    const opportunities: NonNullable<FileAnalysis['taxSavingOpportunities']> = [];

    // Section 80C opportunity
    const section80CUsed = taxData.deductions.section80C || 0;
    const section80CLimit = 150000;
    if (section80CUsed < section80CLimit) {
      opportunities.push({
        section: '80C',
        currentAmount: section80CUsed,
        maxLimit: section80CLimit,
        potentialSaving: (section80CLimit - section80CUsed) * 0.30
      });
    }

    // Section 80D opportunity
    const section80DUsed = taxData.deductions.section80D || 0;
    const section80DLimit = 25000;
    if (section80DUsed < section80DLimit) {
      opportunities.push({
        section: '80D',
        currentAmount: section80DUsed,
        maxLimit: section80DLimit,
        potentialSaving: (section80DLimit - section80DUsed) * 0.30
      });
    }

    return opportunities.sort((a, b) => b.potentialSaving - a.potentialSaving);
  }

  private static generateRecommendations(analysis: FileAnalysis, taxData: TaxRelevantData): string[] {
    const recommendations: string[] = [];

    // Savings rate recommendations
    if (analysis.savingsRate && analysis.savingsRate < 20) {
      recommendations.push('Consider increasing your savings rate to at least 20% for better financial health');
    }

    // Tax saving recommendations
    const section80CUsed = taxData.deductions.section80C || 0;
    if (section80CUsed < 150000) {
      recommendations.push(`Invest ₹${(150000 - section80CUsed).toLocaleString()} more in Section 80C to save ₹${((150000 - section80CUsed) * 0.30).toLocaleString()} in taxes`);
    }

    // Expense optimization
    if (analysis.topExpenseCategories && analysis.topExpenseCategories.length > 0) {
      const topCategory = analysis.topExpenseCategories[0];
      if (topCategory.percentage > 40) {
        recommendations.push(`Your ${topCategory.category} expenses are ${topCategory.percentage.toFixed(1)}% of total expenses. Consider optimizing this category.`);
      }
    }

    return recommendations;
  }

  // Utility method to validate uploaded files
  static validateFile(file: File): { isValid: boolean; error?: string } {
    const maxSize = 10 * 1024 * 1024; // 10MB
    const supportedTypes = ['.pdf', '.csv', '.xlsx', '.xls'];
    
    if (file.size > maxSize) {
      return { isValid: false, error: 'File size exceeds 10MB limit' };
    }

    const extension = '.' + file.name.toLowerCase().split('.').pop();
    if (!supportedTypes.includes(extension)) {
      return { isValid: false, error: `Unsupported file type. Supported: ${supportedTypes.join(', ')}` };
    }

    return { isValid: true };
  }
}

// Export utility functions for external use
export const processFinancialDocument = FileProcessor.processFile.bind(FileProcessor);
export const validateFinancialDocument = FileProcessor.validateFile.bind(FileProcessor);