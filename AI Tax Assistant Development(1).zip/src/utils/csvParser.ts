// CSV Parser for Financial Data

export interface TransactionData {
  date: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
  category: string;
  taxCategory?: string;
  isDeductible?: boolean;
}

export interface SalaryData {
  month: string;
  basicSalary: number;
  hra: number;
  specialAllowance: number;
  bonus: number;
  pf: number;
  professionalTax: number;
  tds: number;
  grossSalary: number;
  netSalary: number;
}

export interface InvestmentData {
  date: string;
  instrument: string;
  amount: number;
  section: string;
  description: string;
}

// Predefined categories for automatic categorization
const TAX_CATEGORIES = {
  'salary': { section: 'income', deductible: false },
  'bonus': { section: 'income', deductible: false },
  'interest': { section: 'income', deductible: false },
  'dividend': { section: 'income', deductible: false },
  'rental': { section: 'income', deductible: false },
  'business': { section: 'income', deductible: false },
  
  'pf': { section: '80C', deductible: true },
  'ppf': { section: '80C', deductible: true },
  'elss': { section: '80C', deductible: true },
  'life insurance': { section: '80C', deductible: true },
  'home loan principal': { section: '80C', deductible: true },
  'tax saving fd': { section: '80C', deductible: true },
  'nsc': { section: '80C', deductible: true },
  'ulip': { section: '80C', deductible: true },
  
  'health insurance': { section: '80D', deductible: true },
  'medical insurance': { section: '80D', deductible: true },
  'health checkup': { section: '80D', deductible: true },
  
  'donation': { section: '80G', deductible: true },
  'charity': { section: '80G', deductible: true },
  
  'home loan interest': { section: '24', deductible: true },
  'house rent': { section: 'hra', deductible: true },
  
  'nps': { section: '80CCD', deductible: true },
  'atal pension': { section: '80CCD', deductible: true }
};

export function parseCSV(csvContent: string, fileType: 'transactions' | 'salary' | 'investments'): any[] {
  const lines = csvContent.trim().split('\n');
  if (lines.length < 2) {
    throw new Error('CSV file must have at least a header row and one data row');
  }

  const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
  const data = lines.slice(1).map(line => {
    const values = parseCSVLine(line);
    const row: any = {};
    
    headers.forEach((header, index) => {
      if (values[index] !== undefined) {
        row[header] = values[index].trim();
      }
    });
    
    return row;
  });

  switch (fileType) {
    case 'transactions':
      return parseTransactionData(data);
    case 'salary':
      return parseSalaryData(data);
    case 'investments':
      return parseInvestmentData(data);
    default:
      return data;
  }
}

function parseCSVLine(line: string): string[] {
  const values = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      values.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  
  values.push(current);
  return values;
}

function parseTransactionData(data: any[]): TransactionData[] {
  return data.map(row => {
    const amount = parseFloat(row.amount || row.debit || row.credit || '0');
    const description = (row.description || row.narration || row.particulars || '').toLowerCase();
    
    // Determine transaction type
    let type: 'credit' | 'debit' = 'debit';
    if (row.type) {
      type = row.type.toLowerCase() === 'credit' ? 'credit' : 'debit';
    } else if (row.credit && parseFloat(row.credit) > 0) {
      type = 'credit';
    } else if (row.debit && parseFloat(row.debit) > 0) {
      type = 'debit';
    } else if (amount > 0 && (description.includes('salary') || description.includes('credit'))) {
      type = 'credit';
    }

    // Auto-categorize based on description
    const category = categorizeTransaction(description);
    const taxInfo = getTaxCategory(description);

    return {
      date: formatDate(row.date || row['transaction date'] || row.timestamp),
      description: row.description || row.narration || row.particulars || '',
      amount: Math.abs(amount),
      type,
      category,
      taxCategory: taxInfo.section,
      isDeductible: taxInfo.deductible
    };
  }).filter(transaction => transaction.amount > 0);
}

function parseSalaryData(data: any[]): SalaryData[] {
  return data.map(row => ({
    month: row.month || row.period || '',
    basicSalary: parseFloat(row['basic salary'] || row.basic || '0'),
    hra: parseFloat(row.hra || row['house rent allowance'] || '0'),
    specialAllowance: parseFloat(row['special allowance'] || row.allowance || '0'),
    bonus: parseFloat(row.bonus || row.incentive || '0'),
    pf: parseFloat(row.pf || row.epf || row['provident fund'] || '0'),
    professionalTax: parseFloat(row['professional tax'] || row.pt || '0'),
    tds: parseFloat(row.tds || row['tax deducted'] || '0'),
    grossSalary: parseFloat(row['gross salary'] || row.gross || '0'),
    netSalary: parseFloat(row['net salary'] || row.net || '0')
  }));
}

function parseInvestmentData(data: any[]): InvestmentData[] {
  return data.map(row => {
    const description = (row.description || row.instrument || '').toLowerCase();
    const section = getTaxCategory(description).section;
    
    return {
      date: formatDate(row.date || row['investment date']),
      instrument: row.instrument || row.scheme || row.description || '',
      amount: parseFloat(row.amount || row.investment || '0'),
      section: section === 'income' ? '80C' : section,
      description: row.description || row.notes || ''
    };
  });
}

function categorizeTransaction(description: string): string {
  description = description.toLowerCase();
  
  if (description.includes('salary') || description.includes('pay')) return 'salary';
  if (description.includes('bonus') || description.includes('incentive')) return 'bonus';
  if (description.includes('dividend')) return 'dividend';
  if (description.includes('interest')) return 'interest';
  if (description.includes('rent')) return 'rent';
  if (description.includes('fuel') || description.includes('petrol')) return 'fuel';
  if (description.includes('food') || description.includes('restaurant')) return 'food';
  if (description.includes('medical') || description.includes('hospital')) return 'medical';
  if (description.includes('shopping') || description.includes('retail')) return 'shopping';
  if (description.includes('utility') || description.includes('electricity')) return 'utilities';
  if (description.includes('insurance')) return 'insurance';
  if (description.includes('investment') || description.includes('mutual fund')) return 'investment';
  if (description.includes('loan') || description.includes('emi')) return 'loan';
  if (description.includes('tax')) return 'tax';
  
  return 'others';
}

function getTaxCategory(description: string): { section: string; deductible: boolean } {
  description = description.toLowerCase();
  
  for (const [keyword, category] of Object.entries(TAX_CATEGORIES)) {
    if (description.includes(keyword)) {
      return category;
    }
  }
  
  return { section: 'others', deductible: false };
}

function formatDate(dateString: string): string {
  if (!dateString) return new Date().toISOString().split('T')[0];
  
  // Try to parse various date formats
  const date = new Date(dateString);
  if (!isNaN(date.getTime())) {
    return date.toISOString().split('T')[0];
  }
  
  // Try DD/MM/YYYY format
  const parts = dateString.split('/');
  if (parts.length === 3) {
    const day = parseInt(parts[0]);
    const month = parseInt(parts[1]) - 1;
    const year = parseInt(parts[2]);
    const formattedDate = new Date(year, month, day);
    if (!isNaN(formattedDate.getTime())) {
      return formattedDate.toISOString().split('T')[0];
    }
  }
  
  return new Date().toISOString().split('T')[0];
}

// Analysis functions
export function analyzeTransactions(transactions: TransactionData[]): {
  totalIncome: number;
  totalExpenses: number;
  taxSavingInvestments: number;
  categoryBreakdown: Record<string, number>;
  monthlyTrends: Record<string, { income: number; expenses: number }>;
  deductibleExpenses: { section80C: number; section80D: number; section80G: number; section24: number };
} {
  const analysis = {
    totalIncome: 0,
    totalExpenses: 0,
    taxSavingInvestments: 0,
    categoryBreakdown: {} as Record<string, number>,
    monthlyTrends: {} as Record<string, { income: number; expenses: number }>,
    deductibleExpenses: { section80C: 0, section80D: 0, section80G: 0, section24: 0 }
  };

  transactions.forEach(transaction => {
    const month = transaction.date.substring(0, 7); // YYYY-MM
    
    if (!analysis.monthlyTrends[month]) {
      analysis.monthlyTrends[month] = { income: 0, expenses: 0 };
    }
    
    if (transaction.type === 'credit') {
      analysis.totalIncome += transaction.amount;
      analysis.monthlyTrends[month].income += transaction.amount;
    } else {
      analysis.totalExpenses += transaction.amount;
      analysis.monthlyTrends[month].expenses += transaction.amount;
    }
    
    // Category breakdown
    if (!analysis.categoryBreakdown[transaction.category]) {
      analysis.categoryBreakdown[transaction.category] = 0;
    }
    analysis.categoryBreakdown[transaction.category] += transaction.amount;
    
    // Tax deductible expenses
    if (transaction.isDeductible && transaction.taxCategory) {
      switch (transaction.taxCategory) {
        case '80C':
          analysis.deductibleExpenses.section80C += transaction.amount;
          analysis.taxSavingInvestments += transaction.amount;
          break;
        case '80D':
          analysis.deductibleExpenses.section80D += transaction.amount;
          break;
        case '80G':
          analysis.deductibleExpenses.section80G += transaction.amount;
          break;
        case '24':
          analysis.deductibleExpenses.section24 += transaction.amount;
          break;
      }
    }
  });

  return analysis;
}

export function generateInsights(transactions: TransactionData[]): string[] {
  const analysis = analyzeTransactions(transactions);
  const insights = [];

  // Income vs Expenses
  const savingsRate = ((analysis.totalIncome - analysis.totalExpenses) / analysis.totalIncome) * 100;
  if (savingsRate < 20) {
    insights.push(`Your savings rate is ${savingsRate.toFixed(1)}%. Consider increasing it to at least 20% for better financial health.`);
  } else {
    insights.push(`Great! Your savings rate of ${savingsRate.toFixed(1)}% is healthy.`);
  }

  // Tax saving potential
  const section80CUsed = analysis.deductibleExpenses.section80C;
  const section80CRemaining = Math.max(0, 150000 - section80CUsed);
  if (section80CRemaining > 0) {
    insights.push(`You can save ₹${(section80CRemaining * 0.3).toLocaleString()} in taxes by investing ₹${section80CRemaining.toLocaleString()} more in Section 80C instruments.`);
  }

  // Top spending categories
  const sortedCategories = Object.entries(analysis.categoryBreakdown)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);
  
  if (sortedCategories.length > 0) {
    insights.push(`Your top spending categories are: ${sortedCategories.map(([cat, amount]) => `${cat} (₹${amount.toLocaleString()})`).join(', ')}`);
  }

  return insights;
}