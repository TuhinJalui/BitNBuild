import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Calculator, FileText, PieChart } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RechartsPieChart, Pie, Cell } from 'recharts';

export function TaxCalculator() {
  const [income, setIncome] = useState('1250000');
  const [regime, setRegime] = useState('new');
  const [deductions, setDeductions] = useState({
    section80C: '150000',
    section80D: '25000',
    section80G: '0',
    hra: '300000',
    homeLoan: '200000'
  });

  const calculateTax = () => {
    const totalIncome = parseInt(income);
    const total80C = parseInt(deductions.section80C);
    const total80D = parseInt(deductions.section80D);
    const totalHRA = parseInt(deductions.hra);
    const homeLoanInterest = parseInt(deductions.homeLoan);

    if (regime === 'old') {
      const taxableIncome = totalIncome - total80C - total80D - totalHRA - homeLoanInterest;
      return calculateOldRegimeTax(taxableIncome);
    } else {
      const taxableIncome = totalIncome - 50000; // Standard deduction in new regime
      return calculateNewRegimeTax(taxableIncome);
    }
  };

  const calculateOldRegimeTax = (taxableIncome: number) => {
    let tax = 0;
    if (taxableIncome > 1000000) {
      tax += (taxableIncome - 1000000) * 0.3;
      taxableIncome = 1000000;
    }
    if (taxableIncome > 500000) {
      tax += (taxableIncome - 500000) * 0.2;
      taxableIncome = 500000;
    }
    if (taxableIncome > 250000) {
      tax += (taxableIncome - 250000) * 0.05;
    }
    return tax;
  };

  const calculateNewRegimeTax = (taxableIncome: number) => {
    let tax = 0;
    if (taxableIncome > 1500000) {
      tax += (taxableIncome - 1500000) * 0.3;
      taxableIncome = 1500000;
    }
    if (taxableIncome > 1200000) {
      tax += (taxableIncome - 1200000) * 0.25;
      taxableIncome = 1200000;
    }
    if (taxableIncome > 900000) {
      tax += (taxableIncome - 900000) * 0.2;
      taxableIncome = 900000;
    }
    if (taxableIncome > 600000) {
      tax += (taxableIncome - 600000) * 0.15;
      taxableIncome = 600000;
    }
    if (taxableIncome > 300000) {
      tax += (taxableIncome - 300000) * 0.1;
      taxableIncome = 300000;
    }
    if (taxableIncome > 250000) {
      tax += (taxableIncome - 250000) * 0.05;
    }
    return tax;
  };

  const oldRegimeTax = calculateOldRegimeTax(parseInt(income) - parseInt(deductions.section80C) - parseInt(deductions.section80D) - parseInt(deductions.hra) - parseInt(deductions.homeLoan));
  const newRegimeTax = calculateNewRegimeTax(parseInt(income) - 50000);

  const comparisonData = [
    {
      regime: 'Old Regime',
      tax: Math.round(oldRegimeTax),
      savings: Math.round(parseInt(deductions.section80C) + parseInt(deductions.section80D) + parseInt(deductions.hra) + parseInt(deductions.homeLoan))
    },
    {
      regime: 'New Regime',
      tax: Math.round(newRegimeTax),
      savings: 50000
    }
  ];

  const pieData = [
    { name: 'Tax Liability', value: Math.round(calculateTax()), fill: '#ef4444' },
    { name: 'Take Home', value: Math.round(parseInt(income) - calculateTax()), fill: '#10b981' }
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Calculator className="h-5 w-5" />
            AI-Powered Tax Calculator
          </CardTitle>
          <CardDescription className="text-white/70">
            Calculate your tax liability and compare tax regimes with personalized recommendations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Input Section */}
            <div className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="annual-income" className="text-white">Annual Income (₹)</Label>
                  <Input
                    id="annual-income"
                    type="number"
                    placeholder="Enter your annual income"
                    value={income}
                    onChange={(e) => setIncome(e.target.value)}
                    className="bg-background/50 text-white border-white/20"
                  />
                </div>

                <div>
                  <Label htmlFor="tax-regime" className="text-white">Tax Regime</Label>
                  <Select value={regime} onValueChange={setRegime}>
                    <SelectTrigger className="bg-background/50 text-white border-white/20">
                      <SelectValue placeholder="Select tax regime" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="old">Old Regime (with deductions)</SelectItem>
                      <SelectItem value="new">New Regime (lower rates)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {regime === 'old' && (
                <div className="space-y-4">
                  <h4 className="font-medium text-white">Deductions</h4>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label htmlFor="section80c" className="text-white">Section 80C (₹)</Label>
                      <Input
                        id="section80c"
                        type="number"
                        placeholder="ELSS, PPF, etc."
                        value={deductions.section80C}
                        onChange={(e) => setDeductions({...deductions, section80C: e.target.value})}
                        className="bg-background/50 text-white border-white/20"
                      />
                    </div>
                    <div>
                      <Label htmlFor="section80d" className="text-white">Section 80D (₹)</Label>
                      <Input
                        id="section80d"
                        type="number"
                        placeholder="Health insurance premium"
                        value={deductions.section80D}
                        onChange={(e) => setDeductions({...deductions, section80D: e.target.value})}
                        className="bg-background/50 text-white border-white/20"
                      />
                    </div>
                    <div>
                      <Label htmlFor="hra" className="text-white">HRA Exemption (₹)</Label>
                      <Input
                        id="hra"
                        type="number"
                        placeholder="House rent allowance"
                        value={deductions.hra}
                        onChange={(e) => setDeductions({...deductions, hra: e.target.value})}
                        className="bg-background/50 text-white border-white/20"
                      />
                    </div>
                    <div>
                      <Label htmlFor="home-loan" className="text-white">Home Loan Interest (₹)</Label>
                      <Input
                        id="home-loan"
                        type="number"
                        placeholder="Section 24(b)"
                        value={deductions.homeLoan}
                        onChange={(e) => setDeductions({...deductions, homeLoan: e.target.value})}
                        className="bg-background/50 text-white border-white/20"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Results Section */}
            <div className="space-y-6">
              <Card className="bg-primary/5 border-primary/20">
                <CardHeader>
                  <CardTitle className="text-lg text-white">Tax Calculation Results</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white">Annual Income:</span>
                    <span className="font-medium text-white">₹{parseInt(income).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Tax Liability:</span>
                    <span className="font-bold text-primary">₹{Math.round(calculateTax()).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Take Home:</span>
                    <span className="font-bold text-green-400">₹{Math.round(parseInt(income) - calculateTax()).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Effective Tax Rate:</span>
                    <span className="font-medium text-white">{((calculateTax() / parseInt(income)) * 100).toFixed(2)}%</span>
                  </div>
                </CardContent>
              </Card>

              {/* Tax Breakdown Pie Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm text-white">Income Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={200}>
                    <RechartsPieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value: number) => `₹${value.toLocaleString()}`} />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Regime Comparison */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <PieChart className="h-5 w-5" />
            Tax Regime Comparison
          </CardTitle>
          <CardDescription className="text-white/70">
            Compare old vs new tax regime to find the best option for you
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={comparisonData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="regime" />
                  <YAxis />
                  <Tooltip formatter={(value: number) => `₹${value.toLocaleString()}`} />
                  <Bar dataKey="tax" fill="#3b82f6" name="Tax Liability" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-4">
              <h4 className="font-medium text-white">AI Recommendation</h4>
              <div className="p-4 bg-primary/10 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant={oldRegimeTax < newRegimeTax ? 'default' : 'secondary'}>
                    {oldRegimeTax < newRegimeTax ? 'Recommended' : 'Alternative'}
                  </Badge>
                  <span className="font-medium text-white">Old Regime</span>
                </div>
                <p className="text-sm text-white/70 mb-2">
                  Tax Liability: ₹{Math.round(oldRegimeTax).toLocaleString()}
                </p>
                <p className="text-sm text-white">
                  {oldRegimeTax < newRegimeTax 
                    ? `Save ₹${Math.round(newRegimeTax - oldRegimeTax).toLocaleString()} compared to new regime`
                    : `₹${Math.round(oldRegimeTax - newRegimeTax).toLocaleString()} more than new regime`
                  }
                </p>
              </div>
              <div className="p-4 bg-secondary/10 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant={newRegimeTax < oldRegimeTax ? 'default' : 'secondary'}>
                    {newRegimeTax < oldRegimeTax ? 'Recommended' : 'Alternative'}
                  </Badge>
                  <span className="font-medium text-white">New Regime</span>
                </div>
                <p className="text-sm text-white/70 mb-2">
                  Tax Liability: ₹{Math.round(newRegimeTax).toLocaleString()}
                </p>
                <p className="text-sm text-white">
                  {newRegimeTax < oldRegimeTax 
                    ? `Save ₹${Math.round(oldRegimeTax - newRegimeTax).toLocaleString()} compared to old regime`
                    : `₹${Math.round(newRegimeTax - oldRegimeTax).toLocaleString()} more than old regime`
                  }
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}