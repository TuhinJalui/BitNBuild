import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  FileText, 
  Upload, 
  Calculator,
  CreditCard,
  PieChart,
  BarChart3,
  Target,
  Brain,
  Zap,
  Bell,
  TrendingDown as ArrowDown
} from 'lucide-react';
import { TaxCalculator } from './TaxCalculator';
import { CibilScoreCard } from './CibilScoreCard';
import { FinancialOverview } from './FinancialOverview';
import { RecentTransactions } from './RecentTransactions';
import { FileUploadCard } from './FileUploadCard';
import { TaxSavingsRecommendations } from './TaxSavingsRecommendations';
import { SmartTaxDashboard } from '../ai/SmartTaxDashboard';
import { TaxAIAssistant } from '../ai/TaxAIAssistant';
import { toast } from 'sonner@2.0.3';

interface DashboardProps {
  user: {
    name: string;
    email: string;
  };
}

export function Dashboard({ user }: DashboardProps) {
  const currentTaxYear = new Date().getFullYear();
  const [isAIAssistantOpen, setIsAIAssistantOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  const handleNavigate = (page: string) => {
    setActiveTab(page);
    toast.success(`Navigated to ${page.charAt(0).toUpperCase() + page.slice(1)}`);
  };

  const handleUploadClick = () => {
    setActiveTab('documents');
    toast.info('Upload your documents for AI analysis');
  };

  const handleCalculateClick = () => {
    setActiveTab('tax-calculator');
    toast.info('Opening Tax Calculator');
  };

  const toggleAIAssistant = () => {
    setIsAIAssistantOpen(!isAIAssistantOpen);
  };

  // Sample financial data - in real app, this would come from backend/state
  const financialData = {
    totalIncome: 1250000,
    taxLiability: 185000,
    taxSavings: 150000,
    cibilScore: 780,
    monthlyGrowth: 12,
    taxReduction: 45000,
    section80CUsed: 150000,
    cibilRank: 'Excellent'
  };

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold">Welcome back, {user.name}!</h1>
          <p className="text-muted-foreground">
            Here's your financial overview for FY {currentTaxYear}-{(currentTaxYear + 1).toString().slice(-2)}
          </p>
        </div>
        <div className="flex gap-3">
          <Button onClick={handleUploadClick} className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            Upload Documents
          </Button>
          <Button variant="outline" onClick={handleCalculateClick} className="flex items-center gap-2">
            <Calculator className="h-4 w-4" />
            Calculate Tax
          </Button>
          <Button variant="outline" onClick={toggleAIAssistant} className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            AI Assistant
          </Button>
        </div>
      </div>

      {/* AI Recommendations Banner */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 border-primary/20">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/20 rounded-full">
                <Zap className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">AI Tax Optimization Alert</h3>
                <p className="text-sm text-muted-foreground">
                  You can save ₹25,000 more in taxes by optimizing your deductions
                </p>
              </div>
            </div>
            <Button size="sm" onClick={() => setActiveTab('ai-insights')}>
              View Recommendations
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20 hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Income</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{financialData.totalIncome.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500 flex items-center gap-1">
                <TrendingUp className="h-3 w-3" />
                +{financialData.monthlyGrowth}% from last year
              </span>
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tax Liability</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{financialData.taxLiability.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500 flex items-center gap-1">
                <ArrowDown className="h-3 w-3" />
                Reduced by ₹{financialData.taxReduction.toLocaleString()}
              </span>
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tax Savings</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{financialData.taxSavings.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500">80C: ₹{financialData.section80CUsed.toLocaleString()} utilized</span>
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">CIBIL Score</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold flex items-center gap-2">
              {financialData.cibilScore}
              <Badge variant="secondary" className="text-xs bg-green-500 text-white">
                {financialData.cibilRank}
              </Badge>
            </div>
            <Progress value={financialData.cibilScore / 10} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 md:grid-cols-6">
          <TabsTrigger value="overview" className="flex items-center gap-1 md:gap-2">
            <PieChart className="h-4 w-4" />
            <span className="hidden md:inline">Overview</span>
          </TabsTrigger>
          <TabsTrigger value="ai-insights" className="flex items-center gap-1 md:gap-2">
            <Brain className="h-4 w-4" />
            <span className="hidden md:inline">AI Insights</span>
          </TabsTrigger>
          <TabsTrigger value="tax-calculator" className="flex items-center gap-1 md:gap-2">
            <Calculator className="h-4 w-4" />
            <span className="hidden md:inline">Calculator</span>
          </TabsTrigger>
          <TabsTrigger value="cibil" className="flex items-center gap-1 md:gap-2">
            <CreditCard className="h-4 w-4" />
            <span className="hidden md:inline">CIBIL</span>
          </TabsTrigger>
          <TabsTrigger value="documents" className="flex items-center gap-1 md:gap-2">
            <Upload className="h-4 w-4" />
            <span className="hidden md:inline">Documents</span>
          </TabsTrigger>
          <TabsTrigger value="insights" className="flex items-center gap-1 md:gap-2">
            <BarChart3 className="h-4 w-4" />
            <span className="hidden md:inline">Reports</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <FinancialOverview />
            <CibilScoreCard />
          </div>
          <RecentTransactions />
        </TabsContent>

        <TabsContent value="ai-insights">
          <SmartTaxDashboard onNavigate={handleNavigate} />
        </TabsContent>

        <TabsContent value="tax-calculator">
          <TaxCalculator />
        </TabsContent>

        <TabsContent value="cibil">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <CibilScoreCard detailed />
            <Card>
              <CardHeader>
                <CardTitle>Credit Improvement Tips</CardTitle>
                <CardDescription>AI-powered recommendations to boost your CIBIL score</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 bg-muted/30 rounded-lg">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium">Pay down credit card balances</p>
                      <p className="text-sm text-muted-foreground">Reduce utilization from 45% to below 30% for +25 points</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 bg-muted/30 rounded-lg">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium">Increase credit limits</p>
                      <p className="text-sm text-muted-foreground">Request limit increases on existing cards</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 bg-muted/30 rounded-lg">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium">Set up autopay</p>
                      <p className="text-sm text-muted-foreground">Never miss a payment to maintain perfect history</p>
                    </div>
                  </div>
                </div>
                <Button className="w-full" onClick={() => handleNavigate('cibil-simulator')}>
                  <Target className="h-4 w-4 mr-2" />
                  Try CIBIL Simulator
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="documents">
          <FileUploadCard />
        </TabsContent>

        <TabsContent value="insights">
          <TaxSavingsRecommendations />
        </TabsContent>
      </Tabs>

      {/* AI Assistant Modal */}
      <TaxAIAssistant
        isOpen={isAIAssistantOpen}
        onToggle={toggleAIAssistant}
        onNavigate={handleNavigate}
      />
    </div>
  );
}