import React, { useState, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import { Badge } from '../ui/badge';
import { Alert, AlertDescription } from '../ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  Upload, 
  FileText, 
  File, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  Brain,
  Download,
  Eye,
  X,
  Trash2,
  BarChart3,
  Calculator,
  TrendingUp,
  Zap,
  RefreshCw
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { parseCSV, analyzeTransactions, generateInsights, type TransactionData } from '../../utils/csvParser';

interface UploadedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  status: 'uploading' | 'processing' | 'completed' | 'error';
  progress: number;
  file?: File;
  extractedData?: any;
  parsedData?: TransactionData[];
  analysis?: any;
  insights?: string[];
  fileType?: 'transactions' | 'salary' | 'investments' | 'form16' | 'bank_statement';
  uploadDate: Date;
}

export function FileUploadCard() {
  const [isDragging, setIsDragging] = useState(false);
  const [files, setFiles] = useState<UploadedFile[]>([
    {
      id: '1',
      name: 'Bank_Statement_HDFC_Aug2024.pdf',
      type: 'Bank Statement',
      status: 'completed',
      progress: 100,
      size: 1024000,
      fileType: 'bank_statement',
      uploadDate: new Date('2024-12-25'),
      extractedData: {
        totalTransactions: 127,
        totalIncome: 104000,
        totalExpenses: 78000,
        categories: ['Salary', 'Rent', 'Food', 'Utilities']
      },
      insights: [
        '₹104,000 salary credited monthly',
        '₹35,000 rent payment detected',
        '127 transactions analyzed',
        'Savings rate: 25%',
        'Top expense: Rent (₹35,000)'
      ]
    },
    {
      id: '2',
      name: 'Form16_FY2023-24.pdf',
      type: 'Form 16',
      status: 'completed',
      progress: 100,
      size: 256000,
      fileType: 'form16',
      uploadDate: new Date('2024-12-20'),
      extractedData: {
        annualSalary: 1250000,
        tdsDeducted: 150000,
        taxRegime: 'old',
        deductions: { section80C: 150000, section80D: 25000 }
      },
      insights: [
        '₹12,50,000 gross annual income',
        '₹1,50,000 TDS deducted',
        'Old tax regime used',
        'Section 80C fully utilized',
        'Additional 80D available'
      ]
    },
    {
      id: '3',
      name: 'Credit_Card_Statement_Aug2024.csv',
      type: 'Credit Card Statement',
      status: 'processing',
      progress: 65,
      size: 128000,
      fileType: 'transactions',
      uploadDate: new Date('2024-12-24'),
      insights: []
    }
  ]);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    const droppedFiles = Array.from(e.dataTransfer.files);
    handleFileUpload(droppedFiles);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    handleFileUpload(selectedFiles);
    // Reset the input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleFileUpload = async (uploadedFiles: File[]) => {
    const validFiles = uploadedFiles.filter(file => {
      const validTypes = ['.pdf', '.csv', '.xls', '.xlsx'];
      const isValidType = validTypes.some(type => file.name.toLowerCase().endsWith(type));
      const isValidSize = file.size <= 10 * 1024 * 1024; // 10MB
      
      if (!isValidType) {
        toast.error(`${file.name}: Unsupported file type`);
        return false;
      }
      if (!isValidSize) {
        toast.error(`${file.name}: File size exceeds 10MB`);
        return false;
      }
      return true;
    });

    for (const file of validFiles) {
      const newFile: UploadedFile = {
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        name: file.name,
        type: detectFileType(file.name),
        size: file.size,
        status: 'uploading',
        progress: 0,
        file,
        fileType: determineFileType(file.name),
        uploadDate: new Date()
      };

      setFiles(prev => [...prev, newFile]);
      
      try {
        // Simulate upload progress
        await simulateUpload(newFile.id);
        
        // Process the file
        await processFile(file, newFile.id);
        
        toast.success(`${file.name} processed successfully!`);
      } catch (error) {
        console.error('Upload error:', error);
        setFiles(prev => prev.map(f => 
          f.id === newFile.id 
            ? { ...f, status: 'error' as const }
            : f
        ));
        toast.error(`Failed to process ${file.name}`);
      }
    }
  };

  const simulateUpload = (fileId: string): Promise<void> => {
    return new Promise((resolve) => {
      const interval = setInterval(() => {
        setFiles(prev => prev.map(file => {
          if (file.id === fileId && file.status === 'uploading') {
            const newProgress = Math.min(file.progress + Math.random() * 15 + 5, 100);
            if (newProgress >= 100) {
              clearInterval(interval);
              resolve();
              return { ...file, progress: 100, status: 'processing' };
            }
            return { ...file, progress: newProgress };
          }
          return file;
        }));
      }, 300);
    });
  };

  const processFile = async (file: File, fileId: string) => {
    try {
      let parsedData: TransactionData[] = [];
      let analysis: any = {};
      let insights: string[] = [];
      let extractedData: any = {};

      if (file.name.toLowerCase().endsWith('.csv')) {
        const content = await readFileContent(file);
        const fileType = determineFileType(file.name);
        parsedData = parseCSV(content, fileType);
        
        if (fileType === 'transactions') {
          analysis = analyzeTransactions(parsedData);
          insights = generateInsights(parsedData);
          extractedData = analysis;
        }
      } else if (file.name.toLowerCase().endsWith('.pdf')) {
        // Mock PDF processing
        const result = await processPDFFile(file.name);
        insights = result.insights;
        extractedData = result.data;
      }

      setFiles(prev => prev.map(f => {
        if (f.id === fileId) {
          return {
            ...f,
            status: 'completed',
            parsedData,
            analysis,
            insights,
            extractedData
          };
        }
        return f;
      }));

    } catch (error) {
      console.error('Processing error:', error);
      throw error;
    }
  };

  const readFileContent = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target?.result as string);
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsText(file);
    });
  };

  const detectFileType = (fileName: string): string => {
    const name = fileName.toLowerCase();
    if (name.includes('bank') || name.includes('statement')) return 'Bank Statement';
    if (name.includes('form16') || name.includes('form 16')) return 'Form 16';
    if (name.includes('credit') || name.includes('card')) return 'Credit Card Statement';
    if (name.includes('salary') || name.includes('payslip')) return 'Salary Slip';
    if (name.includes('investment') || name.includes('mutual')) return 'Investment Statement';
    return 'Financial Document';
  };

  const determineFileType = (fileName: string): 'transactions' | 'salary' | 'investments' => {
    const name = fileName.toLowerCase();
    if (name.includes('salary') || name.includes('payslip')) return 'salary';
    if (name.includes('investment') || name.includes('mutual') || name.includes('sip')) return 'investments';
    return 'transactions';
  };

  const processPDFFile = async (fileName: string): Promise<{ insights: string[]; data: any }> => {
    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const name = fileName.toLowerCase();
    if (name.includes('form16')) {
      return {
        insights: [
          'Annual salary: ₹12,50,000',
          'TDS deducted: ₹1,50,000',
          'Tax regime: Old regime',
          'Section 80C used: ₹1,50,000',
          'Net tax payable: ₹25,000'
        ],
        data: {
          annualIncome: 1250000,
          tdsDeducted: 150000,
          taxRegime: 'old',
          deductions: { section80C: 150000, section80D: 25000 }
        }
      };
    } else if (name.includes('bank')) {
      return {
        insights: [
          'Total transactions: 156',
          'Monthly salary: ₹1,04,166',
          'Average monthly expenses: ₹75,000',
          'Savings rate: 28%',
          'Top expense category: Rent (₹35,000)'
        ],
        data: {
          totalTransactions: 156,
          monthlyIncome: 104166,
          monthlyExpenses: 75000,
          savingsRate: 28,
          topCategories: { rent: 35000, food: 12000, utilities: 5000 }
        }
      };
    }
    return {
      insights: ['Document processed successfully', 'Key financial data extracted'],
      data: {}
    };
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'processing':
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'uploading':
        return <Upload className="h-4 w-4 text-blue-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <File className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      completed: { variant: 'default' as const, label: 'Completed' },
      processing: { variant: 'secondary' as const, label: 'Processing' },
      uploading: { variant: 'secondary' as const, label: 'Uploading' },
      error: { variant: 'destructive' as const, label: 'Error' }
    };
    const config = variants[status as keyof typeof variants] || variants.completed;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const removeFile = (fileId: string) => {
    setFiles(prev => prev.filter(f => f.id !== fileId));
    toast.success('File removed');
  };

  const retryProcessing = async (fileId: string) => {
    const file = files.find(f => f.id === fileId);
    if (!file?.file) return;

    setFiles(prev => prev.map(f => 
      f.id === fileId 
        ? { ...f, status: 'uploading', progress: 0 }
        : f
    ));

    try {
      await simulateUpload(fileId);
      await processFile(file.file, fileId);
      toast.success('File processed successfully!');
    } catch (error) {
      setFiles(prev => prev.map(f => 
        f.id === fileId 
          ? { ...f, status: 'error' }
          : f
      ));
      toast.error('Failed to process file');
    }
  };

  const generateReport = (file: UploadedFile) => {
    const report = {
      fileName: file.name,
      fileType: file.type,
      uploadDate: file.uploadDate.toISOString(),
      analysis: file.analysis || file.extractedData,
      insights: file.insights,
      summary: {
        totalTransactions: file.analysis?.totalIncome ? 'Available' : 'N/A',
        categories: file.analysis?.categoryBreakdown ? Object.keys(file.analysis.categoryBreakdown).length : 0,
        taxSavings: file.analysis?.taxSavingInvestments || 0
      }
    };
    
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${file.name.split('.')[0]}_analysis_report.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success('Analysis report downloaded!');
  };

  const completedFiles = files.filter(f => f.status === 'completed');
  const processingFiles = files.filter(f => f.status === 'processing' || f.status === 'uploading');

  return (
    <div className="space-y-6">
      {/* Upload Zone */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Smart Document Upload & Analysis
          </CardTitle>
          <CardDescription>
            Upload your financial documents for AI-powered analysis and tax insights
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
              isDragging
                ? 'border-primary bg-primary/5'
                : 'border-muted-foreground/25 hover:border-primary/50'
            }`}
            onDragEnter={handleDragEnter}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="space-y-4">
              <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                <Upload className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Drop your files here or click to browse</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Supports PDF, CSV, XLS files up to 10MB each
                </p>
              </div>
              <div className="flex justify-center gap-2">
                <Button variant="outline">
                  <FileText className="h-4 w-4 mr-2" />
                  Browse Files
                </Button>
                <Button variant="outline">
                  <Brain className="h-4 w-4 mr-2" />
                  AI Scan
                </Button>
              </div>
            </div>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept=".csv,.pdf,.xls,.xlsx"
            onChange={handleFileSelect}
            className="hidden"
          />

          {/* Supported Document Types */}
          <div className="mt-6 grid grid-cols-2 md:grid-cols-5 gap-4">
            {[
              { icon: FileText, label: 'Bank Statements', desc: 'PDF, CSV' },
              { icon: Calculator, label: 'Form 16', desc: 'PDF' },
              { icon: BarChart3, label: 'Credit Cards', desc: 'PDF, CSV' },
              { icon: TrendingUp, label: 'Investments', desc: 'CSV, PDF' },
              { icon: Brain, label: 'Salary Slips', desc: 'PDF' }
            ].map((item, index) => (
              <div key={index} className="text-center p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <item.icon className="h-6 w-6 mx-auto mb-2 text-primary" />
                <p className="text-xs font-medium">{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Processing Status */}
      {processingFiles.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Processing Files
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {processingFiles.map(file => (
              <div key={file.id} className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
                {getStatusIcon(file.status)}
                <div className="flex-1">
                  <p className="font-medium text-sm">{file.name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Progress value={file.progress} className="flex-1 h-2" />
                    <span className="text-xs text-muted-foreground">{Math.round(file.progress)}%</span>
                  </div>
                  {file.status === 'processing' && (
                    <p className="text-xs text-primary mt-1">AI is analyzing your document...</p>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Processed Files */}
      {completedFiles.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Processed Documents</CardTitle>
            <CardDescription>
              AI has analyzed your documents and extracted key financial insights
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="list" className="space-y-4">
              <TabsList>
                <TabsTrigger value="list">List View</TabsTrigger>
                <TabsTrigger value="insights">AI Insights</TabsTrigger>
              </TabsList>
              
              <TabsContent value="list" className="space-y-4">
                {completedFiles.map(file => (
                  <Card key={file.id} className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="flex items-center gap-3 flex-1">
                        {getStatusIcon(file.status)}
                        <div className="space-y-1 flex-1">
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-sm">{file.name}</p>
                            {getStatusBadge(file.status)}
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {file.type} • {(file.size / 1024).toFixed(1)} KB • {file.uploadDate.toLocaleDateString()}
                          </p>
                          
                          {file.insights && file.insights.length > 0 && (
                            <div className="mt-2 p-2 bg-muted/50 rounded text-xs">
                              <p className="font-medium mb-1 text-primary">Key Insights:</p>
                              <div className="space-y-1">
                                {file.insights.slice(0, 3).map((insight, i) => (
                                  <p key={i} className="text-muted-foreground">• {insight}</p>
                                ))}
                                {file.insights.length > 3 && (
                                  <p className="text-muted-foreground">+ {file.insights.length - 3} more insights</p>
                                )}
                              </div>
                            </div>
                          )}

                          {file.extractedData && (
                            <div className="mt-2 p-2 bg-primary/5 rounded text-xs">
                              <p className="font-medium mb-1">Quick Summary:</p>
                              {file.fileType === 'transactions' && file.extractedData.totalIncome && (
                                <div className="grid grid-cols-2 gap-2">
                                  <span>Income: ₹{file.extractedData.totalIncome?.toLocaleString()}</span>
                                  <span>Expenses: ₹{file.extractedData.totalExpenses?.toLocaleString()}</span>
                                </div>
                              )}
                              {file.fileType === 'form16' && file.extractedData.annualSalary && (
                                <div className="grid grid-cols-2 gap-2">
                                  <span>Annual: ₹{file.extractedData.annualSalary?.toLocaleString()}</span>
                                  <span>TDS: ₹{file.extractedData.tdsDeducted?.toLocaleString()}</span>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => generateReport(file)}
                          title="Download Report"
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          title="View Details"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        {file.status === 'error' && (
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => retryProcessing(file.id)}
                            title="Retry Processing"
                          >
                            <RefreshCw className="h-4 w-4" />
                          </Button>
                        )}
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => removeFile(file.id)}
                          title="Remove File"
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="insights">
                <div className="grid gap-4">
                  {completedFiles.filter(f => f.insights?.length).length === 0 ? (
                    <Alert>
                      <Brain className="h-4 w-4" />
                      <AlertDescription>
                        No insights available yet. Upload and process documents to see AI-generated insights.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    completedFiles
                      .filter(f => f.insights?.length)
                      .map(file => (
                        <Card key={file.id}>
                          <CardHeader className="pb-3">
                            <CardTitle className="text-base flex items-center gap-2">
                              <Zap className="h-4 w-4 text-primary" />
                              {file.name}
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2">
                              {file.insights?.map((insight, i) => (
                                <div key={i} className="flex items-start gap-2 text-sm">
                                  <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                                  <span>{insight}</span>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>
                      ))
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}

      {files.length === 0 && (
        <Alert>
          <Upload className="h-4 w-4" />
          <AlertDescription>
            No documents uploaded yet. Upload your financial documents to get started with AI-powered analysis.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}