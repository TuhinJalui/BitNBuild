import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown } from 'lucide-react';

export function FinancialOverview() {
  const expenseData = [
    { name: 'Housing', value: 35000, color: '#3b82f6' },
    { name: 'Food', value: 15000, color: '#10b981' },
    { name: 'Transportation', value: 8000, color: '#f59e0b' },
    { name: 'Entertainment', value: 5000, color: '#ef4444' },
    { name: 'Healthcare', value: 3000, color: '#8b5cf6' },
    { name: 'Others', value: 7000, color: '#6b7280' }
  ];

  const monthlyTrend = [
    { month: 'Apr', income: 104000, expenses: 73000 },
    { month: 'May', income: 104000, expenses: 75000 },
    { month: 'Jun', income: 104000, expenses: 71000 },
    { month: 'Jul', income: 104000, expenses: 74000 },
    { month: 'Aug', income: 104000, expenses: 73000 }
  ];

  const totalExpenses = expenseData.reduce((sum, item) => sum + item.value, 0);
  const monthlyIncome = 104000;
  const monthlySavings = monthlyIncome - totalExpenses;
  const savingsRate = (monthlySavings / monthlyIncome) * 100;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Financial Overview</CardTitle>
        <CardDescription>Your monthly financial breakdown</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Key Metrics */}
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold text-green-500">₹{monthlySavings.toLocaleString()}</p>
            <p className="text-sm text-muted-foreground">Monthly Savings</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">{savingsRate.toFixed(1)}%</p>
            <p className="text-sm text-muted-foreground">Savings Rate</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-primary">₹{totalExpenses.toLocaleString()}</p>
            <p className="text-sm text-muted-foreground">Total Expenses</p>
          </div>
        </div>

        {/* Expense Breakdown Pie Chart */}
        <div className="space-y-4">
          <h4 className="font-medium">Expense Breakdown</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={expenseData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {expenseData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => `₹${value.toLocaleString()}`} />
              </PieChart>
            </ResponsiveContainer>
            
            <div className="space-y-3">
              {expenseData.map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-sm">{item.name}</span>
                  </div>
                  <span className="text-sm font-medium">₹{item.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Monthly Trend */}
        <div className="space-y-4">
          <h4 className="font-medium">Income vs Expenses Trend</h4>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={monthlyTrend}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip formatter={(value: number) => `₹${value.toLocaleString()}`} />
              <Bar dataKey="income" fill="#10b981" name="Income" />
              <Bar dataKey="expenses" fill="#ef4444" name="Expenses" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Insights */}
        <div className="space-y-3">
          <h4 className="font-medium">AI Insights</h4>
          <div className="space-y-2">
            <div className="flex items-start gap-3 p-3 bg-green-50 dark:bg-green-950/20 rounded-lg">
              <TrendingUp className="h-4 w-4 text-green-500 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-green-700 dark:text-green-400">Great savings rate!</p>
                <p className="text-green-600 dark:text-green-500">You're saving {savingsRate.toFixed(1)}% of your income, which is above the recommended 20%.</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-yellow-50 dark:bg-yellow-950/20 rounded-lg">
              <TrendingDown className="h-4 w-4 text-yellow-500 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-yellow-700 dark:text-yellow-400">Consider reducing housing costs</p>
                <p className="text-yellow-600 dark:text-yellow-500">Housing takes up 34% of your income. Consider refinancing or finding a cheaper option.</p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}