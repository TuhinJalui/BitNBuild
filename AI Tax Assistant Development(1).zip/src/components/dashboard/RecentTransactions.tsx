import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { ScrollArea } from '../ui/scroll-area';
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  CreditCard, 
  Wallet, 
  Home, 
  Car, 
  ShoppingBag,
  Utensils,
  MoreHorizontal
} from 'lucide-react';

export function RecentTransactions() {
  const transactions = [
    {
      id: '1',
      type: 'credit',
      description: 'Salary Credit',
      amount: 104000,
      category: 'Income',
      date: '2024-09-25',
      icon: Wallet,
      color: 'text-green-500'
    },
    {
      id: '2',
      type: 'debit',
      description: 'Rent Payment',
      amount: 35000,
      category: 'Housing',
      date: '2024-09-24',
      icon: Home,
      color: 'text-blue-500'
    },
    {
      id: '3',
      type: 'debit',
      description: 'Credit Card Payment',
      amount: 15420,
      category: 'Credit Card',
      date: '2024-09-23',
      icon: CreditCard,
      color: 'text-purple-500'
    },
    {
      id: '4',
      type: 'debit',
      description: 'SIP Investment - HDFC Equity Fund',
      amount: 10000,
      category: 'Investment',
      date: '2024-09-22',
      icon: ArrowUpRight,
      color: 'text-green-500'
    },
    {
      id: '5',
      type: 'debit',
      description: 'Fuel - Indian Oil',
      amount: 3500,
      category: 'Transportation',
      date: '2024-09-21',
      icon: Car,
      color: 'text-orange-500'
    },
    {
      id: '6',
      type: 'debit',
      description: 'Grocery Shopping - Big Bazaar',
      amount: 2800,
      category: 'Food',
      date: '2024-09-20',
      icon: ShoppingBag,
      color: 'text-indigo-500'
    },
    {
      id: '7',
      type: 'debit',
      description: 'Dinner - The Oberoi',
      amount: 1850,
      category: 'Entertainment',
      date: '2024-09-19',
      icon: Utensils,
      color: 'text-pink-500'
    },
    {
      id: '8',
      type: 'credit',
      description: 'Freelance Payment',
      amount: 25000,
      category: 'Income',
      date: '2024-09-18',
      icon: Wallet,
      color: 'text-green-500'
    }
  ];

  const getCategoryBadgeColor = (category: string) => {
    const colors: { [key: string]: string } = {
      'Income': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      'Housing': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      'Food': 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200',
      'Transportation': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
      'Entertainment': 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200',
      'Investment': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      'Credit Card': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200'
    };
    return colors[category] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Recent Transactions</CardTitle>
          <CardDescription>Your latest financial activity</CardDescription>
        </div>
        <Button variant="outline" size="sm">
          View All
        </Button>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px]">
          <div className="space-y-3">
            {transactions.map((transaction) => {
              const Icon = transaction.icon;
              return (
                <div
                  key={transaction.id}
                  className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-full bg-muted ${transaction.color}`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="space-y-1">
                      <p className="font-medium text-sm">{transaction.description}</p>
                      <div className="flex items-center gap-2">
                        <Badge 
                          variant="secondary" 
                          className={`text-xs ${getCategoryBadgeColor(transaction.category)}`}
                        >
                          {transaction.category}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {new Date(transaction.date).toLocaleDateString('en-IN', {
                            day: 'numeric',
                            month: 'short'
                          })}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-right">
                      <p className={`font-medium ${
                        transaction.type === 'credit' ? 'text-green-500' : 'text-foreground'
                      }`}>
                        {transaction.type === 'credit' ? '+' : '-'}₹{transaction.amount.toLocaleString()}
                      </p>
                    </div>
                    {transaction.type === 'credit' ? (
                      <ArrowDownLeft className="h-4 w-4 text-green-500" />
                    ) : (
                      <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
        
        {/* Quick Stats */}
        <div className="mt-6 pt-4 border-t">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-sm font-medium text-green-500">+₹129,000</p>
              <p className="text-xs text-muted-foreground">Income this month</p>
            </div>
            <div>
              <p className="text-sm font-medium text-red-500">-₹68,570</p>
              <p className="text-xs text-muted-foreground">Expenses this month</p>
            </div>
            <div>
              <p className="text-sm font-medium text-primary">₹60,430</p>
              <p className="text-xs text-muted-foreground">Net savings</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}