import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Progress } from '../ui/progress';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { CreditCard, TrendingUp, AlertCircle, CheckCircle } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface CibilScoreCardProps {
  detailed?: boolean;
}

export function CibilScoreCard({ detailed = false }: CibilScoreCardProps) {
  const currentScore = 780;
  const scoreHistory = [
    { month: 'Jan', score: 745 },
    { month: 'Feb', score: 750 },
    { month: 'Mar', score: 755 },
    { month: 'Apr', score: 760 },
    { month: 'May', score: 765 },
    { month: 'Jun', score: 770 },
    { month: 'Jul', score: 775 },
    { month: 'Aug', score: 780 }
  ];

  const getScoreColor = (score: number) => {
    if (score >= 750) return 'text-green-500';
    if (score >= 650) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getScoreStatus = (score: number) => {
    if (score >= 750) return 'Excellent';
    if (score >= 650) return 'Good';
    if (score >= 550) return 'Fair';
    return 'Poor';
  };

  const creditUtilization = 45; // percentage
  const paymentHistory = 98; // percentage
  const creditAge = 5.2; // years

  return (
    <Card className={detailed ? '' : 'h-fit'}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between text-foreground">
          <div className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            CIBIL Score
          </div>
          {!detailed && (
            <Button variant="outline" size="sm">
              View Details
            </Button>
          )}
        </CardTitle>
        <CardDescription className="text-muted-foreground">
          Your credit health at a glance
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Current Score */}
        <div className="text-center space-y-4">
          <div className="space-y-2">
            <div className={`text-4xl font-bold ${getScoreColor(currentScore)}`}>
              {currentScore}
            </div>
            <Badge variant="secondary" className="text-sm">
              {getScoreStatus(currentScore)}
            </Badge>
          </div>
          <Progress value={(currentScore / 850) * 100} className="h-3" />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>300</span>
            <span>500</span>
            <span>650</span>
            <span>750</span>
            <span>850</span>
          </div>
        </div>

        {detailed && (
          <>
            {/* Score History Chart */}
            <div className="space-y-4">
              <h4 className="font-medium text-foreground">Score Trend (Last 8 Months)</h4>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={scoreHistory}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis domain={['dataMin - 10', 'dataMax + 10']} />
                  <Tooltip />
                  <Line 
                    type="monotone" 
                    dataKey="score" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={{ fill: '#3b82f6' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Credit Factors */}
            <div className="space-y-4">
              <h4 className="font-medium text-foreground">Credit Health Factors</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-foreground">Payment History</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-foreground">{paymentHistory}%</span>
                    <Progress value={paymentHistory} className="w-20 h-2" />
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm text-foreground">Credit Utilization</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-foreground">{creditUtilization}%</span>
                    <Progress 
                      value={creditUtilization} 
                      className="w-20 h-2"
                    />
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-foreground">Credit Age</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-foreground">{creditAge} years</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="space-y-4">
              <h4 className="font-medium text-foreground">Quick Actions</h4>
              <div className="grid grid-cols-1 gap-2">
                <Button variant="outline" size="sm" className="justify-start">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Get Credit Report
                </Button>
                <Button variant="outline" size="sm" className="justify-start">
                  <CreditCard className="h-4 w-4 mr-2" />
                  Credit Card Recommendations
                </Button>
              </div>
            </div>
          </>
        )}

        {!detailed && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-foreground">Credit Utilization</span>
              <span className="font-medium text-yellow-500">{creditUtilization}%</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-foreground">Payment History</span>
              <span className="font-medium text-green-500">{paymentHistory}%</span>
            </div>
            <div className="flex items-center gap-2 p-3 bg-primary/5 rounded-lg">
              <TrendingUp className="h-4 w-4 text-primary" />
              <div className="text-sm">
                <p className="font-medium text-foreground">+35 points this year</p>
                <p className="text-muted-foreground">Keep up the good work!</p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}