import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { 
  Target, 
  TrendingUp, 
  Heart, 
  Home, 
  GraduationCap, 
  Shield,
  Banknote,
  Calculator,
  ArrowRight,
  CheckCircle
} from 'lucide-react';

export function TaxSavingsRecommendations() {
  const recommendations = [
    {
      section: '80C',
      title: 'ELSS Mutual Funds',
      description: 'Invest in Equity Linked Saving Schemes for tax savings with potential high returns',
      currentAmount: 100000,
      maxAmount: 150000,
      potentialSaving: 15000,
      icon: TrendingUp,
      color: 'text-green-500',
      bgColor: 'bg-green-50 dark:bg-green-950/20',
      priority: 'High'
    },
    {
      section: '80D',
      title: 'Health Insurance Premium',
      description: 'Increase health insurance coverage for family and parents',
      currentAmount: 15000,
      maxAmount: 50000,
      potentialSaving: 10500,
      icon: Heart,
      color: 'text-red-500',
      bgColor: 'bg-red-50 dark:bg-red-950/20',
      priority: 'High'
    },
    {
      section: '24(b)',
      title: 'Home Loan Interest',
      description: 'Claim deduction on home loan interest payments',
      currentAmount: 200000,
      maxAmount: 200000,
      potentialSaving: 0,
      icon: Home,
      color: 'text-blue-500',
      bgColor: 'bg-blue-50 dark:bg-blue-950/20',
      priority: 'Utilized'
    },
    {
      section: '80E',
      title: 'Education Loan Interest',
      description: 'No limit on education loan interest deduction',
      currentAmount: 0,
      maxAmount: 0,
      potentialSaving: 0,
      icon: GraduationCap,
      color: 'text-purple-500',
      bgColor: 'bg-purple-50 dark:bg-purple-950/20',
      priority: 'N/A'
    },
    {
      section: '80G',
      title: 'Charitable Donations',
      description: 'Donate to eligible charities for tax benefits',
      currentAmount: 0,
      maxAmount: 20000,
      potentialSaving: 6000,
      icon: Shield,
      color: 'text-orange-500',
      bgColor: 'bg-orange-50 dark:bg-orange-950/20',
      priority: 'Medium'
    },
    {
      section: 'NPS',
      title: 'National Pension System',
      description: 'Additional ₹50,000 deduction under Section 80CCD(1B)',
      currentAmount: 0,
      maxAmount: 50000,
      potentialSaving: 15000,
      icon: Target,
      color: 'text-indigo-500',
      bgColor: 'bg-indigo-50 dark:bg-indigo-950/20',
      priority: 'High'
    }
  ];

  const totalPotentialSaving = recommendations.reduce((sum, rec) => sum + rec.potentialSaving, 0);
  const currentDeductions = recommendations.reduce((sum, rec) => sum + rec.currentAmount, 0);
  const maxPossibleDeductions = recommendations.reduce((sum, rec) => sum + rec.maxAmount, 0);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'Medium':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'Utilized':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Summary Card */}
      <Card className="bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            AI Tax Savings Optimizer
          </CardTitle>
          <CardDescription>
            Personalized recommendations to maximize your tax savings
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-background/50 rounded-lg">
              <Banknote className="h-8 w-8 mx-auto mb-2 text-primary" />
              <p className="text-2xl font-bold text-primary">₹{totalPotentialSaving.toLocaleString()}</p>
              <p className="text-sm text-muted-foreground">Potential Additional Savings</p>
            </div>
            <div className="text-center p-4 bg-background/50 rounded-lg">
              <Target className="h-8 w-8 mx-auto mb-2 text-green-500" />
              <p className="text-2xl font-bold">₹{currentDeductions.toLocaleString()}</p>
              <p className="text-sm text-muted-foreground">Current Deductions</p>
            </div>
            <div className="text-center p-4 bg-background/50 rounded-lg">
              <TrendingUp className="h-8 w-8 mx-auto mb-2 text-blue-500" />
              <p className="text-2xl font-bold">₹{maxPossibleDeductions.toLocaleString()}</p>
              <p className="text-sm text-muted-foreground">Maximum Possible</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recommendations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {recommendations.map((rec, index) => {
          const Icon = rec.icon;
          const utilizationPercentage = rec.maxAmount > 0 ? (rec.currentAmount / rec.maxAmount) * 100 : 0;
          
          return (
            <Card key={index} className="relative overflow-hidden">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${rec.bgColor}`}>
                      <Icon className={`h-5 w-5 ${rec.color}`} />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{rec.title}</CardTitle>
                      <Badge variant="outline" className="text-xs">
                        Section {rec.section}
                      </Badge>
                    </div>
                  </div>
                  <Badge className={getPriorityColor(rec.priority)}>
                    {rec.priority}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">{rec.description}</p>
                
                {rec.maxAmount > 0 && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Utilization</span>
                      <span>{utilizationPercentage.toFixed(0)}%</span>
                    </div>
                    <Progress value={utilizationPercentage} />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>₹{rec.currentAmount.toLocaleString()}</span>
                      <span>₹{rec.maxAmount.toLocaleString()}</span>
                    </div>
                  </div>
                )}
                
                <div className="flex items-center justify-between pt-2">
                  <div>
                    {rec.potentialSaving > 0 && (
                      <p className="text-sm">
                        <span className="text-muted-foreground">Potential saving: </span>
                        <span className="font-medium text-green-500">₹{rec.potentialSaving.toLocaleString()}</span>
                      </p>
                    )}
                  </div>
                  {rec.priority !== 'Utilized' && rec.priority !== 'N/A' && (
                    <Button size="sm" variant="outline">
                      Invest Now
                      <ArrowRight className="h-3 w-3 ml-1" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Action Plan */}
      <Card>
        <CardHeader>
          <CardTitle>Your AI-Generated Action Plan</CardTitle>
          <CardDescription>
            Follow these steps to maximize your tax savings for FY 2024-25
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-start gap-4 p-4 bg-primary/5 rounded-lg">
              <div className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                1
              </div>
              <div>
                <h4 className="font-medium">Invest ₹50,000 in ELSS Mutual Funds</h4>
                <p className="text-sm text-muted-foreground">Complete your 80C limit and save ₹15,000 in taxes. Potential returns: 12-15% annually.</p>
                <Button size="sm" className="mt-2">Start SIP</Button>
              </div>
            </div>
            
            <div className="flex items-start gap-4 p-4 bg-red-50 dark:bg-red-950/20 rounded-lg">
              <div className="w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center text-sm font-medium">
                2
              </div>
              <div>
                <h4 className="font-medium">Upgrade Health Insurance</h4>
                <p className="text-sm text-muted-foreground">Increase coverage to ₹50,000 family + ₹50,000 parents. Save ₹10,500 and get better coverage.</p>
                <Button size="sm" variant="outline" className="mt-2">Compare Plans</Button>
              </div>
            </div>
            
            <div className="flex items-start gap-4 p-4 bg-indigo-50 dark:bg-indigo-950/20 rounded-lg">
              <div className="w-6 h-6 bg-indigo-500 text-white rounded-full flex items-center justify-center text-sm font-medium">
                3
              </div>
              <div>
                <h4 className="font-medium">Start NPS Investment</h4>
                <p className="text-sm text-muted-foreground">Invest ₹50,000 in NPS for additional ₹15,000 tax saving. Great for retirement planning.</p>
                <Button size="sm" variant="outline" className="mt-2">Open NPS</Button>
              </div>
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <h4 className="font-medium text-green-700 dark:text-green-400">Total Impact</h4>
            </div>
            <p className="text-sm text-green-600 dark:text-green-500">
              By following this plan, you can save an additional <strong>₹40,500</strong> in taxes this year!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}