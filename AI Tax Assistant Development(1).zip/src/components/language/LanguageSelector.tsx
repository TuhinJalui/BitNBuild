import React from 'react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { useLanguage } from './LanguageProvider';
import { Crown, Globe, Lock, Unlock } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface LanguageSelectorProps {
  compact?: boolean;
}

export function LanguageSelector({ compact = false }: LanguageSelectorProps) {
  const { currentLanguage, isSubscribed, changeLanguage, getAvailableLanguages } = useLanguage();
  const languages = getAvailableLanguages();

  const handleLanguageChange = (languageCode: string) => {
    const selectedLanguage = languages.find(lang => lang.code === languageCode);
    
    if (selectedLanguage?.isPremium && !isSubscribed) {
      // Show subscription prompt
      toast.error('Premium subscription required for this language');
      return;
    }
    
    changeLanguage(languageCode);
  };

  const handleSubscriptionUpgrade = () => {
    // Simulate subscription upgrade
    localStorage.setItem('taxwise-subscription', 'true');
    window.location.reload();
    toast.success('Premium subscription activated!');
  };

  if (compact) {
    return (
      <Select value={currentLanguage} onValueChange={handleLanguageChange}>
        <SelectTrigger className="w-[140px] bg-background/95 border-primary/20 text-white">
          <Globe className="h-4 w-4 mr-2" />
          <SelectValue />
        </SelectTrigger>
        <SelectContent className="bg-background border-primary/20">
          {languages.map((language) => (
            <SelectItem 
              key={language.code} 
              value={language.code}
              className="text-white hover:bg-primary/20"
              disabled={language.isPremium && !isSubscribed}
            >
              <div className="flex items-center gap-2">
                <span>{language.flag}</span>
                <span>{language.nativeName}</span>
                {language.isPremium && (
                  <Badge variant="secondary" className="text-xs bg-primary/20 text-primary">
                    {isSubscribed ? <Unlock className="h-3 w-3" /> : <Lock className="h-3 w-3" />}
                  </Badge>
                )}
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    );
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2 text-white border-primary/20 hover:bg-primary/10">
          <Globe className="h-4 w-4" />
          Language
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md bg-background border-primary/20">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Select Language
          </DialogTitle>
          <DialogDescription className="text-white/70">
            Choose your preferred language. Premium languages require a subscription.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Free Languages */}
          <div>
            <h4 className="text-sm font-medium text-white mb-2 flex items-center gap-2">
              <Unlock className="h-4 w-4 text-green-500" />
              Free Languages
            </h4>
            <div className="grid gap-2">
              {languages.filter(lang => !lang.isPremium).map((language) => (
                <Button
                  key={language.code}
                  variant={currentLanguage === language.code ? "default" : "outline"}
                  className="justify-start text-white border-primary/20 hover:bg-primary/10"
                  onClick={() => handleLanguageChange(language.code)}
                >
                  <span className="mr-2">{language.flag}</span>
                  <span className="flex-1 text-left">{language.nativeName}</span>
                  <span className="text-xs text-white/70">({language.name})</span>
                </Button>
              ))}
            </div>
          </div>

          {/* Premium Languages */}
          <div>
            <h4 className="text-sm font-medium text-white mb-2 flex items-center gap-2">
              <Crown className="h-4 w-4 text-primary" />
              Premium Languages
              {!isSubscribed && (
                <Badge variant="secondary" className="text-xs bg-primary/20 text-primary">
                  Subscription Required
                </Badge>
              )}
            </h4>
            <div className="grid gap-2">
              {languages.filter(lang => lang.isPremium).map((language) => (
                <Button
                  key={language.code}
                  variant={currentLanguage === language.code ? "default" : "outline"}
                  className={`justify-start text-white border-primary/20 hover:bg-primary/10 ${
                    !isSubscribed ? 'opacity-50' : ''
                  }`}
                  onClick={() => handleLanguageChange(language.code)}
                  disabled={!isSubscribed}
                >
                  <span className="mr-2">{language.flag}</span>
                  <span className="flex-1 text-left">{language.nativeName}</span>
                  <span className="text-xs text-white/70">({language.name})</span>
                  {!isSubscribed && <Lock className="h-4 w-4 ml-2 text-white/50" />}
                </Button>
              ))}
            </div>
          </div>

          {/* Subscription Upgrade */}
          {!isSubscribed && (
            <Card className="bg-gradient-to-r from-primary/20 to-primary/10 border-primary/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-white flex items-center gap-2">
                  <Crown className="h-4 w-4 text-primary" />
                  Unlock Premium Languages
                </CardTitle>
                <CardDescription className="text-xs text-white/70">
                  Get access to 5 regional Indian languages with premium subscription
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <Button 
                  onClick={handleSubscriptionUpgrade}
                  className="w-full bg-primary hover:bg-primary/90 text-white"
                  size="sm"
                >
                  Upgrade to Premium
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Current Subscription Status */}
          <div className="text-xs text-white/70 text-center">
            {isSubscribed ? (
              <span className="flex items-center justify-center gap-1 text-green-400">
                <Crown className="h-3 w-3" />
                Premium subscription active
              </span>
            ) : (
              <span>Hindi is free for all users</span>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}