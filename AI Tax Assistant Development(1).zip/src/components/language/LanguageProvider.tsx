import React, { createContext, useContext, useState, useEffect } from 'react';
import { toast } from 'sonner@2.0.3';

interface LanguageContextType {
  currentLanguage: string;
  isSubscribed: boolean;
  changeLanguage: (language: string) => void;
  t: (key: string) => string;
  getAvailableLanguages: () => Language[];
  checkSubscription: () => boolean;
}

interface Language {
  code: string;
  name: string;
  nativeName: string;
  isPremium: boolean;
  flag: string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Translation data
const translations: Record<string, Record<string, string>> = {
  en: {
    // Dashboard
    'dashboard.welcome': 'Welcome back',
    'dashboard.overview': 'Here\'s your financial overview for FY',
    'dashboard.totalIncome': 'Total Income',
    'dashboard.taxLiability': 'Tax Liability',
    'dashboard.taxSavings': 'Tax Savings',
    'dashboard.cibilScore': 'CIBIL Score',
    'dashboard.uploadDocuments': 'Upload Documents',
    'dashboard.calculateTax': 'Calculate Tax',
    
    // Navigation
    'nav.dashboard': 'Dashboard',
    'nav.calculator': 'Tax Calculator',
    'nav.cibil': 'CIBIL Score',
    'nav.documents': 'Documents',
    'nav.insights': 'Insights',
    'nav.profile': 'Profile',
    'nav.gst': 'GST Assistant',
    'nav.investments': 'Investments',
    
    // Common
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.submit': 'Submit',
    'common.loading': 'Loading...',
    'common.error': 'Error',
    'common.success': 'Success',
    'common.premium': 'Premium',
    'common.upgrade': 'Upgrade',
    
    // Subscription
    'subscription.required': 'Premium subscription required',
    'subscription.upgrade': 'Upgrade to access this language',
    'subscription.hindi_free': 'Hindi is free for all users',
    'subscription.unlock': 'Unlock Premium Features',
  },
  hi: {
    // Dashboard
    'dashboard.welcome': 'वापसी पर स्वागत है',
    'dashboard.overview': 'यहाँ वित्तीय वर्ष का आपका वित्तीय अवलोकन है',
    'dashboard.totalIncome': 'कुल आय',
    'dashboard.taxLiability': 'कर देनदारी',
    'dashboard.taxSavings': 'कर बचत',
    'dashboard.cibilScore': 'सिबिल स्कोर',
    'dashboard.uploadDocuments': 'दस्तावेज़ अपलोड करें',
    'dashboard.calculateTax': 'कर की गणना करें',
    
    // Navigation
    'nav.dashboard': 'डैशबोर्ड',
    'nav.calculator': 'कर कैलकुलेटर',
    'nav.cibil': 'सिबिल स्कोर',
    'nav.documents': 'दस्तावेज़',
    'nav.insights': 'अंतर्दृष्टि',
    'nav.profile': 'प्रोफ़ाइल',
    'nav.gst': 'जीएसटी सहायक',
    'nav.investments': 'निवेश',
    
    // Common
    'common.save': 'सेव करें',
    'common.cancel': 'रद्द करें',
    'common.submit': 'जमा करें',
    'common.loading': 'लोड हो रहा है...',
    'common.error': 'त्रुटि',
    'common.success': 'सफलता',
    'common.premium': 'प्रीमियम',
    'common.upgrade': 'अपग्रेड',
    
    // Subscription
    'subscription.required': 'प्रीमियम सब्सक्रिप्शन आवश्यक',
    'subscription.upgrade': 'इस भाषा तक पहुंचने के लिए अपग्रेड करें',
    'subscription.hindi_free': 'हिंदी सभी उपयोगकर्ताओं के लिए मुफ्त है',
    'subscription.unlock': 'प्रीमियम सुविधाएं अनलॉक करें',
  },
  mr: {
    // Dashboard - Marathi (Premium)
    'dashboard.welcome': 'परत येण्यावर स्वागत',
    'dashboard.overview': 'येथे तुमचा आर्थिक वर्षाचा आर्थिक आढावा आहे',
    'dashboard.totalIncome': 'एकूण उत्पन्न',
    'dashboard.taxLiability': 'कर दायित्व',
    'dashboard.taxSavings': 'कर बचत',
    'dashboard.cibilScore': 'सिबिल स्कोर',
    'dashboard.uploadDocuments': 'कागदपत्रे अपलोड करा',
    'dashboard.calculateTax': 'कराची गणना करा',
    
    // Navigation
    'nav.dashboard': 'डॅशबोर्ड',
    'nav.calculator': 'कर कॅल्क्युलेटर',
    'nav.cibil': 'सिबिल स्कोर',
    'nav.documents': 'कागदपत्रे',
    'nav.insights': 'अंतर्दृष्टी',
    'nav.profile': 'प्रोफाइल',
    'nav.gst': 'जीएसटी सहायक',
    'nav.investments': 'गुंतवणूक',
  },
  kn: {
    // Dashboard - Kannada (Premium)
    'dashboard.welcome': 'ಹಿಂತಿರುಗಿದ್ದಕ್ಕೆ ಸ್ವಾಗತ',
    'dashboard.overview': 'ಇಲ್ಲಿ ನಿಮ್ಮ ಆರ್ಥಿಕ ವರ್ಷದ ಆರ್ಥಿಕ ಅವಲೋಕನ',
    'dashboard.totalIncome': 'ಒಟ್ಟು ಆದಾಯ',
    'dashboard.taxLiability': 'ತೆರಿಗೆ ಹೊಣೆಗಾರಿಕೆ',
    'dashboard.taxSavings': 'ತೆರಿಗೆ ಉಳಿತಾಯ',
    'dashboard.cibilScore': 'ಸಿಬಿಲ್ ಸ್ಕೋರ್',
    'dashboard.uploadDocuments': 'ದಾಖಲೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ',
    'dashboard.calculateTax': 'ತೆರಿಗೆ ಲೆಕ್ಕಾಚಾರ ಮಾಡಿ',
  },
  gu: {
    // Dashboard - Gujarati (Premium)
    'dashboard.welcome': 'પાછા આવવા બદલ સ્વાગત',
    'dashboard.overview': 'અહીં તમારા નાણાકીય વર્ષનો નાણાકીય ઝાંખી છે',
    'dashboard.totalIncome': 'કુલ આવક',
    'dashboard.taxLiability': 'કર જવાબદારી',
    'dashboard.taxSavings': 'કર બચત',
    'dashboard.cibilScore': 'સિબિલ સ્કોર',
    'dashboard.uploadDocuments': 'દસ્તાવેજો અપલોડ કરો',
    'dashboard.calculateTax': 'કરની ગણતરી કરો',
  },
  ta: {
    // Dashboard - Tamil (Premium)
    'dashboard.welcome': 'திரும்பி வந்ததற்கு வரவேற்கிறோம்',
    'dashboard.overview': 'இங்கே உங்கள் நிதி ஆண்டின் நிதி மேலோட்டம்',
    'dashboard.totalIncome': 'மொத்த வருமானம்',
    'dashboard.taxLiability': 'வரி பொறுப்பு',
    'dashboard.taxSavings': 'வரி சேமிப்பு',
    'dashboard.cibilScore': 'சிபில் ஸ்கோர்',
    'dashboard.uploadDocuments': 'ஆவணங்களை பதிவேற்றவும்',
    'dashboard.calculateTax': 'வரி கணக்கிடுங்கள்',
  },
  ml: {
    // Dashboard - Malayalam (Premium)
    'dashboard.welcome': 'തിരികെ വന്നതിൽ സ്വാഗതം',
    'dashboard.overview': 'ഇവിടെ നിങ്ങളുടെ സാമ്പത്തിക വർഷത്തിന്റെ സാമ്പത്തിക അവലോകനം',
    'dashboard.totalIncome': 'മൊത്തം വരുമാനം',
    'dashboard.taxLiability': 'നികുതി ബാധ്യത',
    'dashboard.taxSavings': 'നികുതി ലാഭം',
    'dashboard.cibilScore': 'സിബിൽ സ്കോർ',
    'dashboard.uploadDocuments': 'രേഖകൾ അപ്‌ലോഡ് ചെയ്യുക',
    'dashboard.calculateTax': 'നികുതി കണക്കാക്കുക',
  }
};

const languages: Language[] = [
  { code: 'en', name: 'English', nativeName: 'English', isPremium: false, flag: '🇺🇸' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', isPremium: false, flag: '🇮🇳' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', isPremium: true, flag: '🇮🇳' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', isPremium: true, flag: '🇮🇳' },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી', isPremium: true, flag: '🇮🇳' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', isPremium: true, flag: '🇮🇳' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം', isPremium: true, flag: '🇮🇳' },
];

interface LanguageProviderProps {
  children: React.ReactNode;
}

export function LanguageProvider({ children }: LanguageProviderProps) {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [isSubscribed, setIsSubscribed] = useState(false);

  useEffect(() => {
    // Load saved language preference
    const savedLanguage = localStorage.getItem('taxwise-language');
    const savedSubscription = localStorage.getItem('taxwise-subscription') === 'true';
    
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    }
    setIsSubscribed(savedSubscription);
  }, []);

  const changeLanguage = (language: string) => {
    const targetLanguage = languages.find(lang => lang.code === language);
    
    if (!targetLanguage) {
      toast.error('Language not supported');
      return;
    }

    if (targetLanguage.isPremium && !isSubscribed) {
      toast.error('Premium subscription required for this language');
      return;
    }

    setCurrentLanguage(language);
    localStorage.setItem('taxwise-language', language);
    toast.success(`Language changed to ${targetLanguage.nativeName}`);
  };

  const t = (key: string): string => {
    const translation = translations[currentLanguage]?.[key];
    if (translation) {
      return translation;
    }
    
    // Fallback to English
    const fallback = translations['en']?.[key];
    if (fallback) {
      return fallback;
    }
    
    // Return key if no translation found
    return key;
  };

  const getAvailableLanguages = () => languages;

  const checkSubscription = () => isSubscribed;

  const value: LanguageContextType = {
    currentLanguage,
    isSubscribed,
    changeLanguage,
    t,
    getAvailableLanguages,
    checkSubscription,
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}