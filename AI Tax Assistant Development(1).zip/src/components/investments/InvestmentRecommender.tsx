import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Slider } from '../ui/slider';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';
import { 
  Target, 
  TrendingUp, 
  Shield, 
  PiggyBank, 
  Zap,
  Star,
  Calculator,
  IndianRupee,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Info
} from 'lucide-react';
import { useLanguage } from '../language/LanguageProvider';

interface UserProfile {
  income: number;
  age: number;
  riskTolerance: 'low' | 'medium' | 'high';
  investmentGoals: string[];
  timeHorizon: number;
  existingInvestments: number;
}

interface Investment {
  id: string;
  name: string;
  type: string;
  section: string;
  maxLimit: number;
  lockIn: string;
  returns: string;
  riskLevel: 'low' | 'medium' | 'high';
  taxBenefit: string;
  description: string;
  icon: any;
  pros: string[];
  cons: string[];
  minInvestment: number;
  liquidity: 'high' | 'medium' | 'low';
}

const investments: Investment[] = [
  {
    id: 'elss',
    name: 'ELSS Mutual Funds',
    type: 'Equity',
    section: '80C',
    maxLimit: 150000,
    lockIn: '3 years',
    returns: '12-15%',
    riskLevel: 'high',
    taxBenefit: 'Tax deduction + LTCG exempt up to ₹1L',
    description: 'Equity Linked Savings Scheme with shortest lock-in period',
    icon: TrendingUp,
    pros: ['Shortest lock-in period', 'High return potential', 'Professional management'],
    cons: ['Market risk', 'No guaranteed returns', 'Volatility'],
    minInvestment: 500,
    liquidity: 'low'
  },
  {
    id: 'ppf',
    name: 'Public Provident Fund',
    type: 'Government Scheme',
    section: '80C',
    maxLimit: 150000,
    lockIn: '15 years',
    returns: '7-8%',
    riskLevel: 'low',
    taxBenefit: 'EEE (Exempt-Exempt-Exempt)',
    description: 'Long-term government-backed savings scheme',
    icon: Shield,
    pros: ['Government guarantee', 'Complete tax exemption', 'Loan facility'],
    cons: ['Long lock-in', 'Low liquidity', 'Interest rate risk'],
    minInvestment: 500,
    liquidity: 'low'
  },
  {
    id: 'nps',
    name: 'National Pension Scheme',
    type: 'Pension',
    section: '80CCD(1B)',
    maxLimit: 50000,
    lockIn: 'Till retirement',
    returns: '8-12%',
    riskLevel: 'medium',
    taxBenefit: 'Additional ₹50K deduction',
    description: 'Market-linked retirement savings scheme',
    icon: PiggyBank,
    pros: ['Additional tax benefit', 'Professional management', 'Retirement corpus'],
    cons: ['Long lock-in', 'Partial withdrawal restrictions', 'Market risk'],
    minInvestment: 1000,
    liquidity: 'low'
  },
  {
    id: 'life-insurance',
    name: 'Life Insurance Premium',
    type: 'Insurance',
    section: '80C',
    maxLimit: 150000,
    lockIn: 'Policy term',
    returns: '4-6%',
    riskLevel: 'low',
    taxBenefit: 'Tax deduction on premium',
    description: 'Life cover with tax benefits',
    icon: Shield,
    pros: ['Life cover', 'Tax deduction', 'Guaranteed maturity'],
    cons: ['Low returns', 'High charges', 'Long commitment'],
    minInvestment: 12000,
    liquidity: 'low'
  },
  {
    id: 'health-insurance',
    name: 'Health Insurance Premium',
    type: 'Insurance',
    section: '80D',
    maxLimit: 25000,
    lockIn: '1 year',
    returns: 'Health cover',
    riskLevel: 'low',
    taxBenefit: 'Tax deduction up to ₹25K',
    description: 'Health coverage with tax benefits',
    icon: Shield,
    pros: ['Health coverage', 'Annual renewal', 'Tax benefit'],
    cons: ['No investment returns', 'Premium increase with age', 'Claim hassles'],
    minInvestment: 3000,
    liquidity: 'high'
  }
];

export function InvestmentRecommender() {
  const { t } = useLanguage();
  const [userProfile, setUserProfile] = useState<UserProfile>({
    income: 500000,
    age: 30,
    riskTolerance: 'medium',
    investmentGoals: [],
    timeHorizon: 10,
    existingInvestments: 0
  });

  const [recommendations, setRecommendations] = useState<Investment[]>([]);
  const [totalTaxSaving, setTotalTaxSaving] = useState(0);
  const [allocationPercentages, setAllocationPercentages] = useState<{[key: string]: number}>({});

  useEffect(() => {
    generateRecommendations();
  }, [userProfile]);

  const generateRecommendations = () => {
    let filteredInvestments = [...investments];
    
    // Filter based on risk tolerance
    if (userProfile.riskTolerance === 'low') {
      filteredInvestments = filteredInvestments.filter(inv => inv.riskLevel !== 'high');
    } else if (userProfile.riskTolerance === 'high') {
      filteredInvestments = filteredInvestments.filter(inv => inv.riskLevel !== 'low');
    }

    // Sort by preference based on user profile
    filteredInvestments.sort((a, b) => {
      let scoreA = getInvestmentScore(a);
      let scoreB = getInvestmentScore(b);
      return scoreB - scoreA;
    });

    setRecommendations(filteredInvestments.slice(0, 5));
    calculateOptimalAllocation(filteredInvestments);
  };

  const getInvestmentScore = (investment: Investment): number => {
    let score = 0;
    
    // Age-based scoring
    if (userProfile.age < 30) {
      if (investment.riskLevel === 'high') score += 3;
      if (investment.riskLevel === 'medium') score += 2;
    } else if (userProfile.age > 45) {
      if (investment.riskLevel === 'low') score += 3;
      if (investment.riskLevel === 'medium') score += 2;
    } else {
      if (investment.riskLevel === 'medium') score += 3;
      if (investment.riskLevel === 'high') score += 2;
    }

    // Risk tolerance scoring
    if (userProfile.riskTolerance === investment.riskLevel) {
      score += 3;
    }

    // Time horizon scoring
    if (userProfile.timeHorizon > 10 && investment.id === 'ppf') score += 2;
    if (userProfile.timeHorizon < 5 && investment.liquidity === 'high') score += 2;

    return score;
  };

  const calculateOptimalAllocation = (investments: Investment[]) => {
    const availableAmount = Math.min(userProfile.income * 0.2, 200000); // Max 20% of income or 2L
    const allocation: {[key: string]: number} = {};
    
    if (userProfile.riskTolerance === 'high') {
      allocation['elss'] = 0.6;
      allocation['nps'] = 0.3;
      allocation['health-insurance'] = 0.1;
    } else if (userProfile.riskTolerance === 'medium') {
      allocation['elss'] = 0.4;
      allocation['ppf'] = 0.4;
      allocation['nps'] = 0.2;
    } else {
      allocation['ppf'] = 0.6;
      allocation['life-insurance'] = 0.3;
      allocation['health-insurance'] = 0.1;
    }

    setAllocationPercentages(allocation);
    
    // Calculate tax saving (30% tax bracket assumption)
    const totalInvestment = Object.values(allocation).reduce((sum, percent) => sum + (availableAmount * percent), 0);
    setTotalTaxSaving(totalInvestment * 0.3);
  };

  const availableAmount = Math.min(userProfile.income * 0.2, 200000);

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-white">Tax Saving Investment Recommender</h1>
        <p className="text-white/70">Get personalized investment recommendations based on your profile</p>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="profile" className="flex items-center gap-2 text-white">
            <Target className="h-4 w-4" />
            Profile
          </TabsTrigger>
          <TabsTrigger value="recommendations" className="flex items-center gap-2 text-white">
            <Star className="h-4 w-4" />
            Recommendations
          </TabsTrigger>
          <TabsTrigger value="calculator" className="flex items-center gap-2 text-white">
            <Calculator className="h-4 w-4" />
            Calculator
          </TabsTrigger>
        </TabsList>

        {/* User Profile */}
        <TabsContent value="profile" className="space-y-6">
          <Card className="bg-background/50 border-primary/20">
            <CardHeader>
              <CardTitle className="text-white">Investment Profile</CardTitle>
              <CardDescription className="text-white/70">
                Help us understand your financial situation for better recommendations
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="income" className="text-white">Annual Income (₹)</Label>
                  <Input
                    id="income"
                    type="number"
                    value={userProfile.income}
                    onChange={(e) => setUserProfile(prev => ({ ...prev, income: parseInt(e.target.value) || 0 }))}
                    className="bg-background/50 border-primary/20 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="age" className="text-white">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    value={userProfile.age}
                    onChange={(e) => setUserProfile(prev => ({ ...prev, age: parseInt(e.target.value) || 0 }))}
                    className="bg-background/50 border-primary/20 text-white"
                  />
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-white">Risk Tolerance</Label>
                <RadioGroup
                  value={userProfile.riskTolerance}
                  onValueChange={(value: 'low' | 'medium' | 'high') => 
                    setUserProfile(prev => ({ ...prev, riskTolerance: value }))
                  }
                  className="flex gap-6"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="low" id="low" />
                    <Label htmlFor="low" className="text-white">Conservative</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="medium" id="medium" />
                    <Label htmlFor="medium" className="text-white">Moderate</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="high" id="high" />
                    <Label htmlFor="high" className="text-white">Aggressive</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-3">
                <Label className="text-white">Investment Time Horizon (Years)</Label>
                <Slider
                  value={[userProfile.timeHorizon]}
                  onValueChange={(value) => setUserProfile(prev => ({ ...prev, timeHorizon: value[0] }))}
                  max={30}
                  min={1}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-white/70">
                  <span>1 year</span>
                  <span>{userProfile.timeHorizon} years</span>
                  <span>30 years</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="existing" className="text-white">Existing Tax-saving Investments (₹)</Label>
                <Input
                  id="existing"
                  type="number"
                  value={userProfile.existingInvestments}
                  onChange={(e) => setUserProfile(prev => ({ ...prev, existingInvestments: parseInt(e.target.value) || 0 }))}
                  className="bg-background/50 border-primary/20 text-white"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Recommendations */}
        <TabsContent value="recommendations" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card className="bg-gradient-to-r from-primary/20 to-primary/10 border-primary/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Recommended Investment</p>
                    <p className="text-white text-2xl font-bold">₹{availableAmount.toLocaleString()}</p>
                  </div>
                  <Target className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-background/50 border-primary/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Potential Tax Saving</p>
                    <p className="text-white text-2xl font-bold">₹{totalTaxSaving.toLocaleString()}</p>
                  </div>
                  <IndianRupee className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-background/50 border-primary/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Risk Level</p>
                    <p className="text-white text-2xl font-bold capitalize">{userProfile.riskTolerance}</p>
                  </div>
                  <Zap className="h-8 w-8 text-yellow-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-white">Personalized Recommendations</h3>
            
            {recommendations.map((investment, index) => {
              const allocation = allocationPercentages[investment.id] || 0;
              const recommendedAmount = availableAmount * allocation;
              
              return (
                <Card key={investment.id} className="bg-background/50 border-primary/20">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-4">
                        <div className="p-3 bg-primary/20 rounded-lg">
                          <investment.icon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h4 className="text-white font-semibold">{investment.name}</h4>
                          <p className="text-white/70 text-sm">{investment.description}</p>
                        </div>
                      </div>
                      <Badge className={`${
                        index === 0 ? 'bg-primary' : 
                        index === 1 ? 'bg-green-500' : 'bg-yellow-500'
                      } text-white`}>
                        {index === 0 ? 'Top Pick' : index === 1 ? 'Best Value' : 'Consider'}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-white/70 text-xs">Section</p>
                        <p className="text-white font-medium">{investment.section}</p>
                      </div>
                      <div>
                        <p className="text-white/70 text-xs">Expected Returns</p>
                        <p className="text-white font-medium">{investment.returns}</p>
                      </div>
                      <div>
                        <p className="text-white/70 text-xs">Lock-in Period</p>
                        <p className="text-white font-medium">{investment.lockIn}</p>
                      </div>
                      <div>
                        <p className="text-white/70 text-xs">Risk Level</p>
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${
                            investment.riskLevel === 'high' ? 'border-red-500 text-red-400' :
                            investment.riskLevel === 'medium' ? 'border-yellow-500 text-yellow-400' :
                            'border-green-500 text-green-400'
                          }`}
                        >
                          {investment.riskLevel}
                        </Badge>
                      </div>
                    </div>

                    {allocation > 0 && (
                      <div className="mb-4 p-3 bg-primary/5 rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-white/70 text-sm">Recommended Allocation</span>
                          <span className="text-white font-medium">{(allocation * 100).toFixed(0)}%</span>
                        </div>
                        <Progress value={allocation * 100} className="mb-2" />
                        <p className="text-white text-sm">Invest ₹{recommendedAmount.toLocaleString()}</p>
                      </div>
                    )}

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h5 className="text-white font-medium text-sm mb-2 flex items-center gap-1">
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                          Pros
                        </h5>
                        <ul className="text-white/70 text-sm space-y-1">
                          {investment.pros.map((pro, idx) => (
                            <li key={idx}>• {pro}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h5 className="text-white font-medium text-sm mb-2 flex items-center gap-1">
                          <AlertTriangle className="h-4 w-4 text-yellow-500" />
                          Cons
                        </h5>
                        <ul className="text-white/70 text-sm space-y-1">
                          {investment.cons.map((con, idx) => (
                            <li key={idx}>• {con}</li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="mt-4 pt-4 border-t border-primary/20">
                      <Button className="w-full bg-primary hover:bg-primary/90 text-white">
                        Start Investing
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* Investment Calculator */}
        <TabsContent value="calculator" className="space-y-6">
          <Card className="bg-background/50 border-primary/20">
            <CardHeader>
              <CardTitle className="text-white">Investment Return Calculator</CardTitle>
              <CardDescription className="text-white/70">
                Calculate potential returns from your tax-saving investments
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label className="text-white">Monthly Investment (₹)</Label>
                    <Input
                      type="number"
                      placeholder="12500"
                      className="bg-background/50 border-primary/20 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-white">Expected Annual Return (%)</Label>
                    <Input
                      type="number"
                      placeholder="12"
                      className="bg-background/50 border-primary/20 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-white">Investment Period (Years)</Label>
                    <Input
                      type="number"
                      placeholder="10"
                      className="bg-background/50 border-primary/20 text-white"
                    />
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="p-4 bg-primary/5 rounded-lg">
                    <h4 className="text-white font-medium mb-2">Projection Results</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-white/70">Total Investment:</span>
                        <span className="text-white font-medium">₹15,00,000</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70">Total Returns:</span>
                        <span className="text-white font-medium">₹27,59,456</span>
                      </div>
                      <div className="flex justify-between text-lg">
                        <span className="text-white font-medium">Maturity Value:</span>
                        <span className="text-white font-bold">₹42,59,456</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-green-500/10 rounded-lg">
                    <h4 className="text-white font-medium mb-2">Tax Benefits</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-white/70">Annual Tax Saving:</span>
                        <span className="text-green-400 font-medium">₹45,000</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70">Total Tax Saved:</span>
                        <span className="text-green-400 font-bold">₹4,50,000</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}