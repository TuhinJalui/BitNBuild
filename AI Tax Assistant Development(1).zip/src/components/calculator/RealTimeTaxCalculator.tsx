import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Switch } from '../ui/switch';
import { 
  Calculator, 
  PieChart, 
  BarChart3, 
  TrendingDown, 
  TrendingUp,
  IndianRupee,
  FileText,
  RefreshCw,
  Zap,
  Target,
  AlertCircle
} from 'lucide-react';
import { useLanguage } from '../language/LanguageProvider';

interface TaxCalculation {
  grossIncome: number;
  totalDeductions: number;
  taxableIncome: number;
  incomeTax: number;
  cess: number;
  surcharge: number;
  totalTax: number;
  netIncome: number;
  effectiveRate: number;
  marginalRate: number;
}

interface Deduction {
  id: string;
  name: string;
  section: string;
  amount: number;
  maxLimit: number;
  description: string;
}

const defaultDeductions: Omit<Deduction, 'amount'>[] = [
  { id: '80c', name: 'Life Insurance, PPF, ELSS, etc.', section: '80C', maxLimit: 150000, description: 'Investments and insurance premiums' },
  { id: '80d', name: 'Health Insurance Premium', section: '80D', maxLimit: 25000, description: 'Health insurance for self and family' },
  { id: '80d_parents', name: 'Health Insurance (Parents)', section: '80D', maxLimit: 25000, description: 'Health insurance for parents' },
  { id: '80ccd1b', name: 'National Pension Scheme', section: '80CCD(1B)', maxLimit: 50000, description: 'Additional NPS contribution' },
  { id: '80g', name: 'Donations to Charity', section: '80G', maxLimit: 0, description: 'Donations to approved charitable institutions' },
  { id: '80e', name: 'Education Loan Interest', section: '80E', maxLimit: 0, description: 'Interest on education loan' },
  { id: '24b', name: 'Home Loan Interest', section: '24(b)', maxLimit: 200000, description: 'Interest on home loan for self-occupied property' },
  { id: 'hra', name: 'House Rent Allowance', section: 'HRA', maxLimit: 0, description: 'HRA exemption for rented accommodation' }
];

export function RealTimeTaxCalculator() {
  const { t } = useLanguage();
  const [isOldRegime, setIsOldRegime] = useState(true);
  const [income, setIncome] = useState({
    salary: 0,
    houseProperty: 0,
    businessProfession: 0,
    capitalGains: 0,
    otherSources: 0
  });
  
  const [deductions, setDeductions] = useState<Deduction[]>(
    defaultDeductions.map(d => ({ ...d, amount: 0 }))
  );
  
  const [calculation, setCalculation] = useState<TaxCalculation>({
    grossIncome: 0,
    totalDeductions: 0,
    taxableIncome: 0,
    incomeTax: 0,
    cess: 0,
    surcharge: 0,
    totalTax: 0,
    netIncome: 0,
    effectiveRate: 0,
    marginalRate: 0
  });

  useEffect(() => {
    calculateTax();
  }, [income, deductions, isOldRegime]);

  const calculateTax = () => {
    const grossIncome = Object.values(income).reduce((sum, val) => sum + val, 0);
    const totalDeductions = isOldRegime ? deductions.reduce((sum, d) => sum + Math.min(d.amount, d.maxLimit || d.amount), 0) : 0;
    
    // Standard deduction
    const standardDeduction = isOldRegime ? 50000 : 50000;
    const taxableIncome = Math.max(0, grossIncome - totalDeductions - standardDeduction);
    
    let incomeTax = 0;
    let marginalRate = 0;
    
    if (isOldRegime) {
      // Old regime tax slabs
      if (taxableIncome <= 250000) {
        incomeTax = 0;
        marginalRate = 0;
      } else if (taxableIncome <= 500000) {
        incomeTax = (taxableIncome - 250000) * 0.05;
        marginalRate = 5;
      } else if (taxableIncome <= 1000000) {
        incomeTax = 12500 + (taxableIncome - 500000) * 0.20;
        marginalRate = 20;
      } else {
        incomeTax = 112500 + (taxableIncome - 1000000) * 0.30;
        marginalRate = 30;
      }
    } else {
      // New regime tax slabs (2023-24)
      if (taxableIncome <= 300000) {
        incomeTax = 0;
        marginalRate = 0;
      } else if (taxableIncome <= 600000) {
        incomeTax = (taxableIncome - 300000) * 0.05;
        marginalRate = 5;
      } else if (taxableIncome <= 900000) {
        incomeTax = 15000 + (taxableIncome - 600000) * 0.10;
        marginalRate = 10;
      } else if (taxableIncome <= 1200000) {
        incomeTax = 45000 + (taxableIncome - 900000) * 0.15;
        marginalRate = 15;
      } else if (taxableIncome <= 1500000) {
        incomeTax = 90000 + (taxableIncome - 1200000) * 0.20;
        marginalRate = 20;
      } else {
        incomeTax = 150000 + (taxableIncome - 1500000) * 0.30;
        marginalRate = 30;
      }
    }
    
    // Surcharge calculation
    let surcharge = 0;
    if (taxableIncome > 5000000 && taxableIncome <= 10000000) {
      surcharge = incomeTax * 0.10;
    } else if (taxableIncome > 10000000 && taxableIncome <= 20000000) {
      surcharge = incomeTax * 0.15;
    } else if (taxableIncome > 20000000 && taxableIncome <= 50000000) {
      surcharge = incomeTax * 0.25;
    } else if (taxableIncome > 50000000) {
      surcharge = incomeTax * 0.37;
    }
    
    // Health and Education Cess (4%)
    const cess = (incomeTax + surcharge) * 0.04;
    const totalTax = incomeTax + surcharge + cess;
    const netIncome = grossIncome - totalTax;
    const effectiveRate = grossIncome > 0 ? (totalTax / grossIncome) * 100 : 0;
    
    setCalculation({
      grossIncome,
      totalDeductions,
      taxableIncome,
      incomeTax,
      cess,
      surcharge,
      totalTax,
      netIncome,
      effectiveRate,
      marginalRate
    });
  };

  const updateIncome = (type: keyof typeof income, value: number) => {
    setIncome(prev => ({ ...prev, [type]: value }));
  };

  const updateDeduction = (id: string, amount: number) => {
    setDeductions(prev => prev.map(d => d.id === id ? { ...d, amount } : d));
  };

  const getComparisonSavings = () => {
    // Calculate tax in both regimes for comparison
    const oldRegimeTax = calculateRegimeTax(true);
    const newRegimeTax = calculateRegimeTax(false);
    return Math.abs(oldRegimeTax - newRegimeTax);
  };

  const calculateRegimeTax = (oldRegime: boolean) => {
    const grossIncome = Object.values(income).reduce((sum, val) => sum + val, 0);
    const totalDeductions = oldRegime ? deductions.reduce((sum, d) => sum + Math.min(d.amount, d.maxLimit || d.amount), 0) : 0;
    const standardDeduction = 50000;
    const taxableIncome = Math.max(0, grossIncome - totalDeductions - standardDeduction);
    
    let incomeTax = 0;
    
    if (oldRegime) {
      if (taxableIncome <= 250000) incomeTax = 0;
      else if (taxableIncome <= 500000) incomeTax = (taxableIncome - 250000) * 0.05;
      else if (taxableIncome <= 1000000) incomeTax = 12500 + (taxableIncome - 500000) * 0.20;
      else incomeTax = 112500 + (taxableIncome - 1000000) * 0.30;
    } else {
      if (taxableIncome <= 300000) incomeTax = 0;
      else if (taxableIncome <= 600000) incomeTax = (taxableIncome - 300000) * 0.05;
      else if (taxableIncome <= 900000) incomeTax = 15000 + (taxableIncome - 600000) * 0.10;
      else if (taxableIncome <= 1200000) incomeTax = 45000 + (taxableIncome - 900000) * 0.15;
      else if (taxableIncome <= 1500000) incomeTax = 90000 + (taxableIncome - 1200000) * 0.20;
      else incomeTax = 150000 + (taxableIncome - 1500000) * 0.30;
    }
    
    return incomeTax * 1.04; // Including cess
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-white">Real-time Tax Calculator</h1>
        <p className="text-white/70">Calculate your tax liability in real-time as you enter your details</p>
      </div>

      {/* Regime Toggle */}
      <Card className="bg-gradient-to-r from-primary/20 to-primary/10 border-primary/20">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-white font-medium">Tax Regime</h3>
              <p className="text-white/70 text-sm">
                {isOldRegime ? 'Old regime with deductions' : 'New regime with lower rates'}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span className={`text-sm ${!isOldRegime ? 'text-white' : 'text-white/70'}`}>New</span>
              <Switch checked={isOldRegime} onCheckedChange={setIsOldRegime} />
              <span className={`text-sm ${isOldRegime ? 'text-white' : 'text-white/70'}`}>Old</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Input Section */}
        <div className="lg:col-span-2 space-y-6">
          {/* Income Sources */}
          <Card className="bg-background/50 border-primary/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <IndianRupee className="h-5 w-5" />
                Income Sources
              </CardTitle>
              <CardDescription className="text-white/70">
                Enter your income from various sources
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-white">Salary Income</Label>
                  <Input
                    type="number"
                    placeholder="0"
                    value={income.salary || ''}
                    onChange={(e) => updateIncome('salary', parseFloat(e.target.value) || 0)}
                    className="bg-background/50 border-primary/20 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-white">House Property Income</Label>
                  <Input
                    type="number"
                    placeholder="0"
                    value={income.houseProperty || ''}
                    onChange={(e) => updateIncome('houseProperty', parseFloat(e.target.value) || 0)}
                    className="bg-background/50 border-primary/20 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-white">Business/Profession Income</Label>
                  <Input
                    type="number"
                    placeholder="0"
                    value={income.businessProfession || ''}
                    onChange={(e) => updateIncome('businessProfession', parseFloat(e.target.value) || 0)}
                    className="bg-background/50 border-primary/20 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-white">Capital Gains</Label>
                  <Input
                    type="number"
                    placeholder="0"
                    value={income.capitalGains || ''}
                    onChange={(e) => updateIncome('capitalGains', parseFloat(e.target.value) || 0)}
                    className="bg-background/50 border-primary/20 text-white"
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label className="text-white">Other Sources</Label>
                  <Input
                    type="number"
                    placeholder="0"
                    value={income.otherSources || ''}
                    onChange={(e) => updateIncome('otherSources', parseFloat(e.target.value) || 0)}
                    className="bg-background/50 border-primary/20 text-white"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Deductions (Only for Old Regime) */}
          {isOldRegime && (
            <Card className="bg-background/50 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Tax Deductions
                </CardTitle>
                <CardDescription className="text-white/70">
                  Enter your eligible deductions under various sections
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {deductions.map((deduction) => (
                    <div key={deduction.id} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-white text-sm">{deduction.name}</Label>
                        <Badge variant="outline" className="text-xs text-primary border-primary/20">
                          {deduction.section}
                        </Badge>
                      </div>
                      <Input
                        type="number"
                        placeholder="0"
                        value={deduction.amount || ''}
                        onChange={(e) => updateDeduction(deduction.id, parseFloat(e.target.value) || 0)}
                        className="bg-background/50 border-primary/20 text-white"
                      />
                      {deduction.maxLimit > 0 && (
                        <p className="text-xs text-white/70">
                          Max limit: ₹{deduction.maxLimit.toLocaleString()}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Calculation Results */}
        <div className="space-y-6">
          {/* Real-time Summary */}
          <Card className="bg-gradient-to-b from-primary/20 to-primary/5 border-primary/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Live Calculation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-white/70">Gross Income:</span>
                  <span className="text-white font-medium">₹{calculation.grossIncome.toLocaleString()}</span>
                </div>
                
                {isOldRegime && (
                  <div className="flex justify-between">
                    <span className="text-white/70">Total Deductions:</span>
                    <span className="text-green-400 font-medium">-₹{calculation.totalDeductions.toLocaleString()}</span>
                  </div>
                )}
                
                <div className="flex justify-between">
                  <span className="text-white/70">Taxable Income:</span>
                  <span className="text-white font-medium">₹{calculation.taxableIncome.toLocaleString()}</span>
                </div>
                
                <div className="border-t border-primary/20 pt-3">
                  <div className="flex justify-between">
                    <span className="text-white/70">Income Tax:</span>
                    <span className="text-white font-medium">₹{calculation.incomeTax.toLocaleString()}</span>
                  </div>
                  
                  {calculation.surcharge > 0 && (
                    <div className="flex justify-between">
                      <span className="text-white/70">Surcharge:</span>
                      <span className="text-white font-medium">₹{calculation.surcharge.toLocaleString()}</span>
                    </div>
                  )}
                  
                  <div className="flex justify-between">
                    <span className="text-white/70">Health & Edu Cess:</span>
                    <span className="text-white font-medium">₹{calculation.cess.toLocaleString()}</span>
                  </div>
                </div>
                
                <div className="border-t border-primary/20 pt-3">
                  <div className="flex justify-between text-lg">
                    <span className="text-white font-medium">Total Tax:</span>
                    <span className="text-white font-bold">₹{calculation.totalTax.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/70">Net Income:</span>
                    <span className="text-green-400 font-bold">₹{calculation.netIncome.toLocaleString()}</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-white/70">Effective Rate:</span>
                    <span className="text-white font-medium">{calculation.effectiveRate.toFixed(1)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/70">Marginal Rate:</span>
                    <span className="text-white font-medium">{calculation.marginalRate}%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Regime Comparison */}
          <Card className="bg-background/50 border-primary/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Regime Comparison
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-white/70">Old Regime Tax:</span>
                  <span className="text-white">₹{calculateRegimeTax(true).toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-white/70">New Regime Tax:</span>
                  <span className="text-white">₹{calculateRegimeTax(false).toLocaleString()}</span>
                </div>
                <div className="border-t border-primary/20 pt-3">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-medium">You Save:</span>
                    <span className="text-green-400 font-bold">
                      ₹{getComparisonSavings().toLocaleString()}
                    </span>
                  </div>
                  <p className="text-xs text-white/70 mt-1">
                    {calculateRegimeTax(true) < calculateRegimeTax(false) ? 'Old regime is better' : 'New regime is better'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="bg-background/50 border-primary/20">
            <CardHeader>
              <CardTitle className="text-white">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full bg-primary hover:bg-primary/90 text-white">
                Generate Tax Report
              </Button>
              <Button variant="outline" className="w-full text-white border-primary/20 hover:bg-primary/10">
                Save Calculation
              </Button>
              <Button variant="outline" className="w-full text-white border-primary/20 hover:bg-primary/10">
                Share Results
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}