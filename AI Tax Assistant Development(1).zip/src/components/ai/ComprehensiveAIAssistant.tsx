import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { ScrollArea } from '../ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Alert, AlertDescription } from '../ui/alert';
import { 
  Brain, 
  Send, 
  Mic, 
  Calculator, 
  FileText, 
  TrendingUp, 
  AlertCircle,
  CheckCircle,
  DollarSign,
  PieChart,
  Target,
  Clock,
  Lightbulb,
  Zap,
  MessageSquare,
  BarChart3,
  Settings,
  X,
  MicOff,
  Volume2
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { 
  calculateTotalTax, 
  compareRegimes, 
  getInvestmentRecommendations,
  type TaxableIncome,
  type Deductions 
} from '../../utils/taxCalculations';
import { analyzeTransactions, generateInsights, type TransactionData } from '../../utils/csvParser';

interface Message {
  id: string;
  type: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  data?: any;
  actionType?: 'calculation' | 'recommendation' | 'analysis' | 'insight' | 'navigation';
  confidence?: number;
}

interface ComprehensiveAIAssistantProps {
  isOpen: boolean;
  onToggle: () => void;
  userTransactions?: TransactionData[];
  userProfile?: any;
  onNavigate: (page: string) => void;
}

export function ComprehensiveAIAssistant({ 
  isOpen, 
  onToggle, 
  userTransactions, 
  userProfile,
  onNavigate 
}: ComprehensiveAIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: `Hello ${userProfile?.name || 'there'}! 👋\n\nI'm your comprehensive Tax AI Assistant. I can help you with:\n\n🧮 **Tax Calculations** - Old vs New regime comparison\n💰 **Investment Planning** - Tax-saving recommendations\n📊 **Financial Analysis** - Transaction categorization & insights\n📋 **ITR Filing** - Step-by-step guidance\n🎯 **Optimization** - Personalized tax saving strategies\n🗣️ **Voice Commands** - Hands-free interaction\n\nWhat would you like to explore today?`,
      timestamp: new Date(),
      actionType: 'insight',
      confidence: 100
    }
  ]);
  
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [activeTab, setActiveTab] = useState('chat');
  const [conversationContext, setConversationContext] = useState<any>({});
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen) {
      inputRef.current?.focus();
    }
  }, [isOpen]);

  // Voice recognition setup
  useEffect(() => {
    if ('webkitSpeechRecognition' in window) {
      recognitionRef.current = new (window as any).webkitSpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputValue(transcript);
        setIsListening(false);
        
        // Auto-send voice messages
        setTimeout(() => {
          handleSendMessage(transcript);
        }, 500);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        toast.error('Voice recognition failed. Please try again.');
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, []);

  const quickActions = [
    { 
      label: 'Calculate Tax', 
      icon: Calculator, 
      action: 'calculate_tax',
      description: 'Get detailed tax calculations'
    },
    { 
      label: 'Compare Regimes', 
      icon: PieChart, 
      action: 'compare_regimes',
      description: 'Old vs New tax regime analysis'
    },
    { 
      label: 'Investment Ideas', 
      icon: TrendingUp, 
      action: 'investment_recommendations',
      description: 'Tax-saving investment options'
    },
    { 
      label: 'Analyze Expenses', 
      icon: BarChart3, 
      action: 'analyze_transactions',
      description: 'Smart expense categorization'
    },
    { 
      label: 'Tax Planning', 
      icon: Target, 
      action: 'tax_planning',
      description: 'Comprehensive tax strategy'
    },
    { 
      label: 'ITR Filing', 
      icon: FileText, 
      action: 'itr_filing',
      description: 'Step-by-step filing guide'
    }
  ];

  const handleSendMessage = async (messageText?: string) => {
    const text = messageText || inputValue;
    if (!text.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: text,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate realistic AI processing
    setTimeout(() => {
      const response = generateEnhancedAIResponse(text);
      setMessages(prev => [...prev, response]);
      setIsTyping(false);
      
      // Text-to-speech for AI responses (optional)
      if (voiceEnabled && 'speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(response.content.substring(0, 200));
        utterance.rate = 0.9;
        utterance.pitch = 1;
        speechSynthesis.speak(utterance);
      }
    }, 1200 + Math.random() * 800);
  };

  const handleQuickAction = (action: string) => {
    const actionHandlers: Record<string, () => Message> = {
      calculate_tax: () => ({
        id: Date.now().toString(),
        type: 'assistant',
        content: "I'll help you calculate your tax liability accurately.\n\nPlease provide:\n\n💼 **Annual Income Details:**\n• Salary/Business income\n• Other income sources (interest, dividends, etc.)\n\n📊 **Deductions & Investments:**\n• Section 80C investments (PF, ELSS, PPF)\n• Section 80D health insurance premiums\n• Home loan interest (Section 24)\n• Any other deductions\n\n🏛️ **Tax Regime Preference:**\n• Old regime (with deductions)\n• New regime (lower rates, fewer deductions)\n\nOr shall I open the Tax Calculator for you?",
        timestamp: new Date(),
        actionType: 'calculation',
        data: { action: 'navigate', page: 'calculator' },
        confidence: 95
      }),

      compare_regimes: () => {
        const sampleIncome = { basicSalary: 1000000, hra: 400000, specialAllowance: 200000, bonus: 0, otherIncome: 0, businessIncome: 0, capitalGains: 0, interestIncome: 0 };
        const sampleDeductions = { section80C: 150000, section80D: 25000, section80G: 0, section24: 0, standardDeduction: 50000, professionalTax: 2400, epf: 120000, nps: 0 };
        const comparison = compareRegimes(sampleIncome, sampleDeductions);
        
        return {
          id: Date.now().toString(),
          type: 'assistant',
          content: `📊 **Tax Regime Comparison Analysis**\n\n**🏛️ Old Regime:**\n• Tax Liability: ₹${comparison.oldRegime.totalTax.toLocaleString()}\n• Available Deductions: ₹${comparison.oldRegime.totalDeductions.toLocaleString()}\n• Effective Tax Rate: ${comparison.oldRegime.effectiveRate.toFixed(2)}%\n\n**🆕 New Regime:**\n• Tax Liability: ₹${comparison.newRegime.totalTax.toLocaleString()}\n• Limited Deductions: ₹${comparison.newRegime.totalDeductions.toLocaleString()}\n• Effective Tax Rate: ${comparison.newRegime.effectiveRate.toFixed(2)}%\n\n**✅ Recommendation:** ${comparison.recommendation.toUpperCase()} REGIME\n**💰 Potential Savings:** ₹${comparison.savings.toLocaleString()}\n\n*This is a sample calculation. Use the Tax Calculator with your actual figures for precise results.*`,
          timestamp: new Date(),
          actionType: 'analysis',
          data: comparison,
          confidence: 88
        };
      },

      investment_recommendations: () => {
        const recommendations = getInvestmentRecommendations(
          { section80C: 75000, section80D: 15000, section80G: 0, section24: 0, standardDeduction: 50000, professionalTax: 0, epf: 0, nps: 0 },
          30000
        );

        return {
          id: Date.now().toString(),
          type: 'assistant',
          content: `🎯 **Smart Tax-Saving Investment Recommendations**\n\n${recommendations.slice(0, 4).map((rec, i) => 
            `**${i + 1}. ${rec.instrument}** (${rec.section})\n   💰 Max Limit: ₹${rec.maxLimit.toLocaleString()}\n   📈 Potential Tax Saving: ₹${rec.taxSaving.toLocaleString()}\n   📝 ${rec.description}\n   ⭐ Additional Investment Needed: ₹${rec.additionalInvestment.toLocaleString()}`
          ).join('\n\n')}\n\n**💡 Pro Tips:**\n• Start with ELSS for best returns with 3-year lock-in\n• Diversify across equity and debt instruments\n• Plan investments early in the financial year\n\nWould you like personalized recommendations based on your risk profile?`,
          timestamp: new Date(),
          actionType: 'recommendation',
          data: recommendations,
          confidence: 92
        };
      },

      analyze_transactions: () => {
        if (!userTransactions || userTransactions.length === 0) {
          return {
            id: Date.now().toString(),
            type: 'assistant',
            content: "📊 **Transaction Analysis**\n\nI don't see any transaction data uploaded yet. To provide detailed expense analysis, please:\n\n1. **Upload Documents** 📁\n   • Bank statements\n   • Credit card statements\n   • Transaction CSV files\n\n2. **What I Can Analyze** 🔍\n   • Spending patterns by category\n   • Tax-deductible expenses\n   • Monthly trends and insights\n   • Potential tax savings\n   • Budget optimization suggestions\n\n3. **Smart Categorization** 🏷️\n   • Automatic expense categorization\n   • Tax-relevant transaction identification\n   • Deduction opportunity detection\n\nShall I guide you to the Document Upload section?",
            timestamp: new Date(),
            actionType: 'analysis',
            data: { action: 'navigate', page: 'documents' },
            confidence: 85
          };
        }

        const analysis = analyzeTransactions(userTransactions);
        const insights = generateInsights(userTransactions);
        
        return {
          id: Date.now().toString(),
          type: 'assistant',
          content: `📊 **Your Transaction Analysis**\n\n**💰 Financial Summary:**\n• Total Income: ₹${analysis.totalIncome.toLocaleString()}\n• Total Expenses: ₹${analysis.totalExpenses.toLocaleString()}\n• Net Savings: ₹${(analysis.totalIncome - analysis.totalExpenses).toLocaleString()}\n• Savings Rate: ${(((analysis.totalIncome - analysis.totalExpenses) / analysis.totalIncome) * 100).toFixed(1)}%\n\n**🏷️ Tax-Deductible Expenses Found:**\n• Section 80C: ₹${analysis.deductibleExpenses.section80C.toLocaleString()}\n• Section 80D: ₹${analysis.deductibleExpenses.section80D.toLocaleString()}\n• Section 80G: ₹${analysis.deductibleExpenses.section80G.toLocaleString()}\n• Section 24: ₹${analysis.deductibleExpenses.section24.toLocaleString()}\n\n**🎯 Key Insights:**\n${insights.slice(0, 3).map(insight => `• ${insight}`).join('\n')}\n\nWould you like a detailed breakdown by category?`,
          timestamp: new Date(),
          actionType: 'analysis',
          data: analysis,
          confidence: 94
        };
      },

      tax_planning: () => ({
        id: Date.now().toString(),
        type: 'assistant',
        content: "🎯 **Comprehensive Tax Planning Strategy**\n\n**📅 Year-Round Planning Approach:**\n\n**Q1 (Apr-Jun): Foundation Setting**\n• Review previous year's ITR\n• Choose optimal tax regime\n• Set up systematic investments (SIP)\n• Plan major purchases/investments\n\n**Q2 (Jul-Sep): Mid-Year Review**\n• Track investment progress\n• Adjust SIP amounts if needed\n• Plan insurance renewals\n• Estimate advance tax requirements\n\n**Q3 (Oct-Dec): Optimization Phase**\n• Maximize remaining 80C limit\n• Plan additional NPS contributions\n• Execute capital gains/losses\n• Review and rebalance portfolio\n\n**Q4 (Jan-Mar): Final Sprint**\n• Complete all tax-saving investments\n• Finalize deduction proofs\n• Prepare ITR documents\n• Plan for next financial year\n\n**🔄 Ongoing Activities:**\n• Monthly expense tracking\n• Quarterly tax liability review\n• Regular investment monitoring\n• Document maintenance\n\nWould you like me to create a personalized tax planning calendar for you?",
        timestamp: new Date(),
        actionType: 'insight',
        confidence: 90
      }),

      itr_filing: () => ({
        id: Date.now().toString(),
        type: 'assistant',
        content: "📋 **Complete ITR Filing Guide 2024-25**\n\n**🔍 Choose Your ITR Form:**\n• **ITR-1 (Sahaj):** Salary, pension, one house property\n• **ITR-2:** Multiple income sources, capital gains\n• **ITR-3:** Business/professional income\n• **ITR-4 (Sugam):** Presumptive business income\n\n**📄 Essential Documents Checklist:**\n✅ Form 16 (from employer)\n✅ Bank statements (all accounts)\n✅ Investment proofs (80C, 80D, etc.)\n✅ TDS certificates (Form 16A)\n✅ Interest certificates\n✅ Capital gains statements\n✅ House property details\n\n**⏰ Important Dates:**\n• Original Return: July 31, 2024\n• Revised Return: December 31, 2024\n• Belated Return: March 31, 2025 (with penalty)\n\n**🔄 E-Filing Process:**\n1. Register/Login to Income Tax portal\n2. Select appropriate ITR form\n3. Fill all income & deduction details\n4. Calculate tax & verify computations\n5. Generate XML/JSON file\n6. Submit with digital signature/EVC\n7. Verify within 120 days\n\n**💡 Pro Tips:**\n• Keep all documents ready before starting\n• Double-check PAN, bank account details\n• Verify calculations multiple times\n• Save acknowledgment copy\n\nNeed help with any specific section of ITR filing?",
        timestamp: new Date(),
        actionType: 'insight',
        confidence: 96
      })
    };

    const handler = actionHandlers[action];
    if (handler) {
      const response = handler();
      setMessages(prev => [...prev, response]);
      setActiveTab('chat');
    }
  };

  const generateEnhancedAIResponse = (query: string): Message => {
    const lowerQuery = query.toLowerCase();
    
    // Advanced pattern matching with context awareness
    let response: Message;
    let confidence = 75;

    if (lowerQuery.includes('salary') && (lowerQuery.includes('calculate') || lowerQuery.includes('tax'))) {
      // Extract salary amount if mentioned
      const salaryMatch = query.match(/(\d{1,3}(?:,\d{3})*|\d+)\s*(?:lakh|lakhs|thousand|k|cr|crore)?/i);
      let salaryAmount = 0;
      
      if (salaryMatch) {
        const num = parseFloat(salaryMatch[1].replace(/,/g, ''));
        const unit = salaryMatch[0].toLowerCase();
        
        if (unit.includes('lakh')) salaryAmount = num * 100000;
        else if (unit.includes('crore') || unit.includes('cr')) salaryAmount = num * 10000000;
        else if (unit.includes('thousand') || unit.includes('k')) salaryAmount = num * 1000;
        else salaryAmount = num;
      }

      if (salaryAmount > 0) {
        const calculation = calculateTotalTax(
          { basicSalary: salaryAmount, hra: salaryAmount * 0.4, specialAllowance: salaryAmount * 0.2, bonus: 0, otherIncome: 0, businessIncome: 0, capitalGains: 0, interestIncome: 0 },
          { section80C: 100000, section80D: 25000, section80G: 0, section24: 0, standardDeduction: 50000, professionalTax: 2400, epf: salaryAmount * 0.12, nps: 0 },
          true
        );

        response = {
          id: Date.now().toString(),
          type: 'assistant',
          content: `💰 **Tax Calculation for ₹${salaryAmount.toLocaleString()} Annual Salary**\n\n**📊 Income Breakdown:**\n• Basic Salary: ₹${salaryAmount.toLocaleString()}\n• HRA (assumed 40%): ₹${(salaryAmount * 0.4).toLocaleString()}\n• Special Allowance: ₹${(salaryAmount * 0.2).toLocaleString()}\n• **Gross Income:** ₹${calculation.totalIncome.toLocaleString()}\n\n**📉 Deductions:**\n• Total Deductions: ₹${calculation.totalDeductions.toLocaleString()}\n• **Taxable Income:** ₹${calculation.taxableIncome.toLocaleString()}\n\n**🏛️ Tax Computation (Old Regime):**\n• Income Tax: ₹${calculation.incomeTax.toLocaleString()}\n• Health & Education Cess: ₹${calculation.cess.toLocaleString()}\n• **Total Tax Liability:** ₹${calculation.totalTax.toLocaleString()}\n• **Effective Tax Rate:** ${calculation.effectiveRate.toFixed(2)}%\n\n*This is an estimate with standard assumptions. For precise calculation with your actual details, use our Tax Calculator.*`,
          timestamp: new Date(),
          actionType: 'calculation',
          data: calculation,
          confidence: 92
        };
      } else {
        response = {
          id: Date.now().toString(),
          type: 'assistant',
          content: "💰 **Salary Tax Calculation**\n\nI'd be happy to calculate tax on your salary! Please provide:\n\n📊 **Income Details:**\n• Annual gross salary amount\n• HRA component (if separate)\n• Other allowances\n• Any additional income sources\n\n📉 **Deductions & Investments:**\n• PF contribution\n• Section 80C investments\n• Health insurance premiums\n• Home loan interest\n\nExample: \"Calculate tax for 12 lakh salary with 1.5 lakh 80C investment\"\n\nOr I can open the Tax Calculator for detailed computation.",
          timestamp: new Date(),
          actionType: 'calculation',
          confidence: 85
        };
      }
    } else if (lowerQuery.includes('save') || lowerQuery.includes('saving') || lowerQuery.includes('reduce tax')) {
      response = {
        id: Date.now().toString(),
        type: 'assistant',
        content: "💡 **Smart Tax Saving Strategies**\n\n**🎯 Immediate Actions (High Impact):**\n• **Maximize Section 80C** - Invest up to ₹1.5L in ELSS, PPF, or PF\n• **Health Insurance** - ₹25K premium deduction under 80D\n• **NPS Contribution** - Additional ₹50K deduction under 80CCD(1B)\n\n**🏠 Property-Related Savings:**\n• **Home Loan Interest** - Up to ₹2L deduction under Section 24\n• **HRA Claims** - If paying rent, claim HRA exemption\n\n**📈 Advanced Strategies:**\n• **Tax Loss Harvesting** - Book capital losses to offset gains\n• **Employer Benefits** - Opt for tax-free perks like meal vouchers\n• **Regime Comparison** - Evaluate Old vs New tax regime annually\n\n**⏰ Timing Matters:**\n• Plan investments early in FY for better returns\n• Spread investments across quarters\n• Review and adjust mid-year\n\n**🧮 Potential Savings:**\nWith proper planning, you could save ₹50K-₹1L+ annually in taxes!\n\nWhich strategy interests you most?",
        timestamp: new Date(),
        actionType: 'recommendation',
        confidence: 94
      };
    } else if (lowerQuery.includes('itr') || lowerQuery.includes('filing') || lowerQuery.includes('return')) {
      response = {
        id: Date.now().toString(),
        type: 'assistant',
        content: "📋 **ITR Filing Made Simple**\n\n**🎯 Quick Checklist:**\n\n**Before You Start:**\n✅ Choose correct ITR form (ITR-1/2/3/4)\n✅ Gather all documents (Form 16, investment proofs)\n✅ Have bank account details ready\n✅ Ensure PAN-Aadhaar linking\n\n**🔄 Step-by-Step Process:**\n1. **Login** to incometax.gov.in\n2. **Select** appropriate ITR form\n3. **Fill** income from all sources\n4. **Claim** all eligible deductions\n5. **Calculate** tax liability\n6. **Review** all entries carefully\n7. **Submit** and verify (e-verify/DSC)\n\n**⚠️ Common Mistakes to Avoid:**\n• Wrong ITR form selection\n• Missing income sources\n• Incorrect bank account details\n• Not claiming eligible deductions\n• Missing verification within 120 days\n\n**📅 Important Deadlines:**\n• Original Return: July 31\n• Revised Return: Dec 31\n• Response to Notice: As specified\n\n**🆘 Need Help?**\nI can guide you through specific sections or help with calculations!\n\nWhich part of ITR filing do you need help with?",
        timestamp: new Date(),
        actionType: 'insight',
        confidence: 89
      };
    } else {
      // Generic helpful response
      response = {
        id: Date.now().toString(),
        type: 'assistant',
        content: `I understand you're asking about "${query}". Let me help you with that!\n\n🤖 **I can assist you with:**\n\n💰 **Tax Calculations** - Accurate liability computation\n📊 **Regime Comparison** - Old vs New tax regime analysis\n🎯 **Investment Planning** - Tax-saving recommendations\n📋 **ITR Filing** - Step-by-step guidance\n📈 **Financial Analysis** - Expense categorization & insights\n🗣️ **Voice Commands** - Just click the mic and speak!\n\n**💡 Try asking:**\n• "Calculate tax for 15 lakh salary"\n• "Compare old vs new tax regime"\n• "Best tax saving investments"\n• "How to file ITR-2?"\n• "Analyze my expenses"\n\nWhat specific information would you like to know?`,
        timestamp: new Date(),
        actionType: 'insight',
        confidence: confidence
      };
    }

    return response;
  };

  const startVoiceInput = () => {
    if (!recognitionRef.current) {
      toast.error('Voice recognition not supported in this browser');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
      return;
    }

    setIsListening(true);
    recognitionRef.current.start();
    toast.info('Listening... Speak now');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-6xl h-[85vh] flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4 border-b">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg">
              <Brain className="h-6 w-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-xl">TaxWise AI Assistant</CardTitle>
              <CardDescription>Your intelligent tax consultation & planning partner</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setVoiceEnabled(!voiceEnabled)}
              title={voiceEnabled ? 'Disable voice' : 'Enable voice'}
            >
              {voiceEnabled ? <Volume2 className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
            </Button>
            <Button variant="ghost" size="sm" onClick={onToggle}>
              <X className="h-5 w-5" />
            </Button>
          </div>
        </CardHeader>

        <div className="flex flex-1 min-h-0">
          {/* Sidebar */}
          <div className="w-80 border-r bg-muted/20 p-4 space-y-4">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="chat">
                  <MessageSquare className="h-4 w-4 mr-1" />
                  Chat
                </TabsTrigger>
                <TabsTrigger value="actions">
                  <Settings className="h-4 w-4 mr-1" />
                  Actions
                </TabsTrigger>
              </TabsList>

              <TabsContent value="chat" className="space-y-2 mt-4">
                <h3 className="font-medium text-sm">Recent Topics</h3>
                <div className="space-y-1">
                  {messages.filter(m => m.type === 'user').slice(-5).map(msg => (
                    <Button
                      key={msg.id}
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start text-xs h-auto p-2"
                      onClick={() => setInputValue(msg.content)}
                    >
                      <MessageSquare className="h-3 w-3 mr-2 flex-shrink-0" />
                      <span className="truncate">{msg.content}</span>
                    </Button>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="actions" className="space-y-2 mt-4">
                <h3 className="font-medium text-sm">Quick Actions</h3>
                <div className="space-y-2">
                  {quickActions.map((action) => (
                    <Button
                      key={action.action}
                      variant="ghost"
                      size="sm"
                      onClick={() => handleQuickAction(action.action)}
                      className="w-full justify-start text-xs h-auto p-3 flex-col items-start"
                    >
                      <div className="flex items-center gap-2 w-full">
                        <action.icon className="h-4 w-4 flex-shrink-0" />
                        <span className="font-medium">{action.label}</span>
                      </div>
                      <span className="text-xs text-muted-foreground mt-1">
                        {action.description}
                      </span>
                    </Button>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Main Chat Area */}
          <div className="flex-1 flex flex-col">
            <ScrollArea className="flex-1 p-6">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-4 ${
                        message.type === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : message.type === 'system'
                          ? 'bg-muted border'
                          : 'bg-card border shadow-sm'
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        {message.type === 'assistant' && (
                          <div className="p-1.5 bg-primary/20 rounded-full flex-shrink-0">
                            {message.actionType === 'calculation' && <Calculator className="h-4 w-4 text-primary" />}
                            {message.actionType === 'recommendation' && <TrendingUp className="h-4 w-4 text-primary" />}
                            {message.actionType === 'analysis' && <BarChart3 className="h-4 w-4 text-primary" />}
                            {message.actionType === 'insight' && <Lightbulb className="h-4 w-4 text-primary" />}
                            {!message.actionType && <Brain className="h-4 w-4 text-primary" />}
                          </div>
                        )}
                        <div className="flex-1 space-y-2">
                          <p className="whitespace-pre-line text-sm leading-relaxed">{message.content}</p>
                          
                          {message.confidence && message.confidence < 80 && (
                            <Alert className="mt-2">
                              <AlertCircle className="h-4 w-4" />
                              <AlertDescription className="text-xs">
                                I'm {message.confidence}% confident about this response. For precise information, please consult a tax professional.
                              </AlertDescription>
                            </Alert>
                          )}

                          {message.data?.action === 'navigate' && (
                            <Button
                              size="sm"
                              className="mt-2"
                              onClick={() => {
                                onNavigate(message.data.page);
                                onToggle();
                              }}
                            >
                              <Zap className="h-4 w-4 mr-2" />
                              Open {message.data.page === 'calculator' ? 'Tax Calculator' : 'Tool'}
                            </Button>
                          )}
                          
                          <div className="flex items-center justify-between mt-2">
                            <p className="text-xs opacity-70">
                              {message.timestamp.toLocaleTimeString()}
                            </p>
                            {message.confidence && (
                              <Badge variant="outline" className="text-xs">
                                {message.confidence}% confident
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-card border shadow-sm rounded-lg p-4 max-w-[80%]">
                      <div className="flex items-center space-x-3">
                        <div className="p-1.5 bg-primary/20 rounded-full">
                          <Brain className="h-4 w-4 text-primary animate-pulse" />
                        </div>
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <div ref={messagesEndRef} />
            </ScrollArea>

            {/* Input Area */}
            <div className="p-4 border-t bg-muted/20">
              <div className="flex items-center space-x-2">
                <div className="flex-1 relative">
                  <Input
                    ref={inputRef}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Ask about taxes, deductions, investments, ITR filing..."
                    onKeyPress={(e) => e.key === 'Enter' && !isTyping && handleSendMessage()}
                    className="pr-12"
                    disabled={isTyping}
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8 ${
                      isListening ? 'text-red-500 animate-pulse' : ''
                    }`}
                    onClick={startVoiceInput}
                    disabled={isTyping}
                  >
                    <Mic className="h-4 w-4" />
                  </Button>
                </div>
                <Button 
                  onClick={() => handleSendMessage()} 
                  disabled={!inputValue.trim() || isTyping}
                  className="px-6"
                >
                  <Send className="h-4 w-4 mr-2" />
                  Send
                </Button>
              </div>
              
              <div className="flex items-center justify-between text-xs text-muted-foreground mt-2">
                <span>
                  {isListening ? '🎤 Listening...' : '💡 Try: "Calculate tax for 15 lakh salary" or click mic to speak'}
                </span>
                <span>{messages.length} messages</span>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}