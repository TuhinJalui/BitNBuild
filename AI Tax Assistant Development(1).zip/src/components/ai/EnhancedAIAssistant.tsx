import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Badge } from '../ui/badge';
import { ScrollArea } from '../ui/scroll-area';
import { 
  Bot, 
  User, 
  Mic, 
  MicOff, 
  Send, 
  Sparkles, 
  Calculator,
  FileText,
  TrendingUp,
  CreditCard,
  PiggyBank,
  AlertCircle,
  CheckCircle2,
  Lightbulb,
  BarChart3,
  X
} from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  suggestions?: string[];
  data?: any;
}

interface AIAssistantProps {
  isOpen: boolean;
  onToggle: () => void;
  onNavigate?: (page: string) => void;
  userProfile?: any;
}

export function EnhancedAIAssistant({ isOpen, onToggle, onNavigate, userProfile }: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: "Hi! I'm your AI Tax & Finance Assistant. I can help you with tax calculations, investment advice, CIBIL score improvement, and answer any questions about Indian taxation. What would you like to know?",
      timestamp: new Date(),
      suggestions: [
        "Calculate my tax liability",
        "How to improve CIBIL score?",
        "Best tax-saving investments",
        "GST compliance help"
      ]
    }
  ]);
  
  const [inputValue, setInputValue] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognition = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognition.current = new SpeechRecognition();
      recognition.current.continuous = false;
      recognition.current.interimResults = false;
      recognition.current.lang = 'en-IN';

      recognition.current.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setInputValue(transcript);
        setIsListening(false);
      };

      recognition.current.onerror = () => {
        setIsListening(false);
      };

      recognition.current.onend = () => {
        setIsListening(false);
      };
    }
  }, []);

  const toggleListening = () => {
    if (!recognition.current) return;

    if (isListening) {
      recognition.current.stop();
      setIsListening(false);
    } else {
      recognition.current.start();
      setIsListening(true);
    }
  };

  const processUserMessage = async (message: string) => {
    setIsTyping(true);
    
    // Simulate AI processing time
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
    
    let response = '';
    let suggestions: string[] = [];
    let data: any = null;

    // Smart response generation based on message content
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('tax') && (lowerMessage.includes('calculate') || lowerMessage.includes('computation'))) {
      response = "I can help you calculate your tax liability! Based on your income and deductions, I'll show you both Old and New regime comparisons. Let me guide you through this step by step.";
      suggestions = [
        "Start tax calculation",
        "Compare tax regimes",
        "Show tax-saving tips",
        "Upload salary slip"
      ];
      data = { action: 'tax-calculation' };
    }
    else if (lowerMessage.includes('cibil') || lowerMessage.includes('credit score')) {
      response = "Your CIBIL score is crucial for loan approvals and better interest rates. I can help you understand your current score and provide actionable tips to improve it. Would you like me to run a credit score simulation?";
      suggestions = [
        "Check CIBIL score factors",
        "Simulate score improvements",
        "Get improvement tips",
        "Understand credit utilization"
      ];
      data = { action: 'cibil-analysis' };
    }
    else if (lowerMessage.includes('investment') || lowerMessage.includes('80c') || lowerMessage.includes('elss')) {
      response = "Great question about investments! Based on your risk profile and income, I can recommend the best tax-saving investment options. ELSS, PPF, NPS - each has different benefits. Let me create a personalized portfolio for you.";
      suggestions = [
        "Show investment options",
        "Calculate returns",
        "Risk assessment",
        "Tax saving calculator"
      ];
      data = { action: 'investment-advice' };
    }
    else if (lowerMessage.includes('gst') || lowerMessage.includes('invoice') || lowerMessage.includes('filing')) {
      response = "GST compliance made simple! I can help you with GST calculations, filing deadlines, invoice management, and ensure you never miss important dates. What specific GST help do you need?";
      suggestions = [
        "Calculate GST",
        "Filing calendar",
        "Invoice management",
        "Compliance check"
      ];
      data = { action: 'gst-help' };
    }
    else if (lowerMessage.includes('save') || lowerMessage.includes('deduction')) {
      response = "Let me analyze your potential tax savings! I can identify missed deduction opportunities and suggest optimal investment strategies. Based on current tax laws, here are some ways to maximize your savings.";
      suggestions = [
        "Find missed deductions",
        "Optimize investments",
        "Section 80D benefits",
        "Home loan benefits"
      ];
      data = { action: 'tax-optimization' };
    }
    else if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('help')) {
      response = "Hello! I'm here to simplify your tax and financial planning. I can help with tax calculations, investment advice, CIBIL score improvement, GST compliance, and much more. What would you like to explore today?";
      suggestions = [
        "Calculate my taxes",
        "Investment recommendations",
        "CIBIL score help",
        "GST assistance"
      ];
    }
    else if (lowerMessage.includes('regime') || lowerMessage.includes('old vs new')) {
      response = "The choice between Old and New tax regime depends on your deductions! Old regime allows deductions but has higher slabs, while New regime has lower rates but fewer deductions. Let me calculate which is better for you.";
      suggestions = [
        "Compare regimes for me",
        "Show tax slabs",
        "Calculate savings",
        "Deduction optimization"
      ];
      data = { action: 'regime-comparison' };
    }
    else {
      response = "I understand you're looking for financial guidance. I can help with tax planning, investment advice, credit score improvement, and GST compliance. Could you be more specific about what you need help with?";
      suggestions = [
        "Tax calculation help",
        "Investment planning",
        "Credit score tips",
        "GST assistance"
      ];
    }

    const aiMessage: Message = {
      id: Date.now().toString(),
      type: 'assistant',
      content: response,
      timestamp: new Date(),
      suggestions,
      data
    };

    setMessages(prev => [...prev, aiMessage]);
    setIsTyping(false);
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');

    await processUserMessage(inputValue);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputValue(suggestion);
    handleSendMessage();
  };

  const handleActionClick = (action: string) => {
    switch (action) {
      case 'tax-calculation':
        onNavigate?.('calculator');
        break;
      case 'cibil-analysis':
        onNavigate?.('cibil');
        break;
      case 'investment-advice':
        onNavigate?.('insights');
        break;
      case 'gst-help':
        onNavigate?.('gst');
        break;
      default:
        break;
    }
  };

  if (!isOpen) {
    return (
      <Button
        onClick={onToggle}
        className="fixed bottom-6 right-6 h-14 w-14 rounded-full bg-primary hover:bg-primary/90 text-white shadow-lg z-50"
        size="icon"
      >
        <Bot className="h-6 w-6" />
      </Button>
    );
  }

  return (
    <Card className="fixed bottom-6 right-6 w-96 h-[600px] bg-background/95 backdrop-blur-sm border-primary/20 shadow-2xl z-50 flex flex-col">
      <CardHeader className="pb-3 border-b border-primary/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-primary to-primary/80 rounded-full flex items-center justify-center">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-white text-lg">TaxWise AI</CardTitle>
              <p className="text-white/70 text-sm">Your Smart Finance Assistant</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggle}
            className="text-white/70 hover:text-white hover:bg-primary/20"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex gap-3 ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                {message.type === 'assistant' && (
                  <Avatar className="w-8 h-8 bg-primary/20">
                    <AvatarFallback className="bg-primary text-white text-xs">
                      <Bot className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                )}
                
                <div className={`max-w-[80%] ${message.type === 'user' ? 'order-first' : ''}`}>
                  <div className={`p-3 rounded-lg ${
                    message.type === 'user' 
                      ? 'bg-primary text-white ml-auto' 
                      : 'bg-background/50 text-white border border-primary/20'
                  }`}>
                    <p className="text-sm">{message.content}</p>
                  </div>
                  
                  {message.suggestions && message.suggestions.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {message.suggestions.map((suggestion, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          onClick={() => handleSuggestionClick(suggestion)}
                          className="text-xs h-6 px-2 text-white border-primary/20 hover:bg-primary/20"
                        >
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  )}

                  {message.data?.action && (
                    <div className="mt-2">
                      <Button
                        size="sm"
                        onClick={() => handleActionClick(message.data.action)}
                        className="bg-primary hover:bg-primary/90 text-white"
                      >
                        <Lightbulb className="h-3 w-3 mr-1" />
                        Take Action
                      </Button>
                    </div>
                  )}
                </div>

                {message.type === 'user' && (
                  <Avatar className="w-8 h-8 bg-primary/20">
                    <AvatarFallback className="bg-primary text-white text-xs">
                      <User className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}
            
            {isTyping && (
              <div className="flex gap-3">
                <Avatar className="w-8 h-8 bg-primary/20">
                  <AvatarFallback className="bg-primary text-white text-xs">
                    <Bot className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="bg-background/50 border border-primary/20 p-3 rounded-lg">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            )}
          </div>
          <div ref={messagesEndRef} />
        </ScrollArea>

        <div className="p-4 border-t border-primary/20">
          <div className="flex gap-2">
            <div className="flex-1 flex gap-2">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask me anything about taxes or finance..."
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                className="bg-background/50 border-primary/20 text-white placeholder:text-white/50 flex-1"
              />
              <Button
                variant="outline"
                size="icon"
                onClick={toggleListening}
                className={`${isListening ? 'bg-red-500 hover:bg-red-600' : 'hover:bg-primary/20'} border-primary/20 text-white`}
              >
                {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              </Button>
            </div>
            <Button 
              onClick={handleSendMessage}
              disabled={!inputValue.trim()}
              className="bg-primary hover:bg-primary/90 text-white"
              size="icon"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="mt-2 flex gap-1 flex-wrap">
            <Badge variant="outline" className="text-xs text-white/70 border-primary/20">
              <Bot className="h-3 w-3 mr-1" />
              AI-Powered
            </Badge>
            <Badge variant="outline" className="text-xs text-white/70 border-primary/20">
              <Mic className="h-3 w-3 mr-1" />
              Voice Enabled
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}