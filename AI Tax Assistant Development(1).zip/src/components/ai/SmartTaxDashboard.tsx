import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Alert, AlertDescription } from '../ui/alert';
import {
  Brain,
  Calculator,
  TrendingUp,
  FileText,
  AlertCircle,
  CheckCircle,
  DollarSign,
  PieChart,
  Target,
  Lightbulb,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight,
  Zap
} from 'lucide-react';
import { 
  calculateTotalTax, 
  compareRegimes, 
  getInvestmentRecommendations,
  type TaxableIncome,
  type Deductions 
} from '../../utils/taxCalculations';
import { TaxAIAssistant } from './TaxAIAssistant';

interface SmartInsight {
  id: string;
  type: 'tax_saving' | 'regime_switch' | 'investment' | 'deduction' | 'warning';
  title: string;
  description: string;
  impact: number;
  action: string;
  priority: 'high' | 'medium' | 'low';
}

interface TaxOptimization {
  currentTax: number;
  optimizedTax: number;
  savings: number;
  recommendations: Array<{
    category: string;
    action: string;
    savings: number;
  }>;
}

interface SmartTaxDashboardProps {
  userIncome?: TaxableIncome;
  userDeductions?: Deductions;
  onNavigate: (page: string) => void;
}

export function SmartTaxDashboard({ userIncome, userDeductions, onNavigate }: SmartTaxDashboardProps) {
  const [insights, setInsights] = useState<SmartInsight[]>([]);
  const [optimization, setOptimization] = useState<TaxOptimization | null>(null);
  const [isAIOpen, setIsAIOpen] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Default income and deductions for demonstration
  const defaultIncome: TaxableIncome = {
    basicSalary: 1200000,
    hra: 480000,
    specialAllowance: 240000,
    bonus: 100000,
    otherIncome: 50000,
    businessIncome: 0,
    capitalGains: 0,
    interestIncome: 25000
  };

  const defaultDeductions: Deductions = {
    section80C: 100000,
    section80D: 15000,
    section80G: 10000,
    section24: 150000,
    standardDeduction: 50000,
    professionalTax: 2400,
    epf: 144000,
    nps: 25000
  };

  const income = userIncome || defaultIncome;
  const deductions = userDeductions || defaultDeductions;

  useEffect(() => {
    generateSmartInsights();
    calculateOptimization();
  }, []);

  const generateSmartInsights = () => {
    setIsAnalyzing(true);
    
    setTimeout(() => {
      const generatedInsights: SmartInsight[] = [
        {
          id: '1',
          type: 'tax_saving',
          title: 'Maximize Section 80C Deduction',
          description: `You can save ₹15,000 more in taxes by investing additional ₹50,000 in ELSS or PPF`,
          impact: 15000,
          action: 'Invest ₹50,000 more',
          priority: 'high'
        },
        {
          id: '2',
          type: 'regime_switch',
          title: 'Old Tax Regime is Better',
          description: 'Based on your deductions, old regime saves you ₹28,000 compared to new regime',
          impact: 28000,
          action: 'Continue with Old Regime',
          priority: 'medium'
        },
        {
          id: '3',
          type: 'investment',
          title: 'Add NPS for Extra Deduction',
          description: 'Contribute ₹25,000 more to NPS under 80CCD(1B) to save ₹7,500 in taxes',
          impact: 7500,
          action: 'Increase NPS contribution',
          priority: 'medium'
        },
        {
          id: '4',
          type: 'deduction',
          title: 'Health Insurance Opportunity',
          description: 'Increase health insurance premium to ₹25,000 to claim maximum 80D deduction',
          impact: 3000,
          action: 'Upgrade health insurance',
          priority: 'low'
        },
        {
          id: '5',
          type: 'warning',
          title: 'TDS vs Actual Tax Liability',
          description: 'Your estimated TDS might be lower than actual tax liability. Consider advance tax payment',
          impact: 0,
          action: 'Calculate advance tax',
          priority: 'high'
        }
      ];

      setInsights(generatedInsights);
      setIsAnalyzing(false);
    }, 2000);
  };

  const calculateOptimization = () => {
    const currentCalc = calculateTotalTax(income, deductions, true);
    
    // Optimized deductions
    const optimizedDeductions: Deductions = {
      ...deductions,
      section80C: 150000, // Maxed out
      section80D: 25000,  // Maxed out
      nps: 50000         // Maxed out
    };
    
    const optimizedCalc = calculateTotalTax(income, optimizedDeductions, true);
    
    setOptimization({
      currentTax: currentCalc.totalTax,
      optimizedTax: optimizedCalc.totalTax,
      savings: currentCalc.totalTax - optimizedCalc.totalTax,
      recommendations: [
        {
          category: 'Section 80C',
          action: 'Invest additional ₹50,000 in ELSS/PPF',
          savings: 15000
        },
        {
          category: 'Section 80D',
          action: 'Increase health insurance premium',
          savings: 3000
        },
        {
          category: 'NPS (80CCD1B)',
          action: 'Additional NPS contribution',
          savings: 7500
        }
      ]
    });
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'tax_saving':
        return <DollarSign className="h-4 w-4 text-green-500" />;
      case 'regime_switch':
        return <PieChart className="h-4 w-4 text-blue-500" />;
      case 'investment':
        return <TrendingUp className="h-4 w-4 text-purple-500" />;
      case 'deduction':
        return <Calculator className="h-4 w-4 text-orange-500" />;
      case 'warning':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Lightbulb className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getPriorityBadge = (priority: string) => {
    const variants = {
      high: { variant: 'destructive' as const, label: 'High Priority' },
      medium: { variant: 'secondary' as const, label: 'Medium' },
      low: { variant: 'outline' as const, label: 'Low Priority' }
    };
    const config = variants[priority as keyof typeof variants] || variants.medium;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  return (
    <div className="space-y-6">
      {/* AI Tax Overview */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-primary/20 rounded-lg">
                <Brain className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle>AI Tax Intelligence</CardTitle>
                <CardDescription>Personalized insights and recommendations</CardDescription>
              </div>
            </div>
            <Button onClick={() => setIsAIOpen(true)}>
              <Zap className="h-4 w-4 mr-2" />
              Ask AI Assistant
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {optimization && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-red-600">₹{optimization.currentTax.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Current Tax Liability</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">₹{optimization.optimizedTax.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Optimized Tax (Potential)</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">₹{optimization.savings.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Potential Savings</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Smart Insights */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="h-5 w-5" />
                Smart Tax Insights
              </CardTitle>
              {isAnalyzing && (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
              )}
            </div>
            <CardDescription>
              AI-powered recommendations to optimize your taxes
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {isAnalyzing ? (
              <div className="space-y-3">
                {[1, 2, 3].map(i => (
                  <div key={i} className="animate-pulse">
                    <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-muted rounded w-full"></div>
                  </div>
                ))}
              </div>
            ) : (
              insights.map((insight) => (
                <div key={insight.id} className="p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {getInsightIcon(insight.type)}
                      <h4 className="font-medium text-sm">{insight.title}</h4>
                    </div>
                    {getPriorityBadge(insight.priority)}
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{insight.description}</p>
                  <div className="flex items-center justify-between">
                    <Button size="sm" variant="outline">
                      {insight.action}
                    </Button>
                    {insight.impact > 0 && (
                      <div className="flex items-center gap-1 text-green-600">
                        <ArrowUpRight className="h-3 w-3" />
                        <span className="text-xs font-medium">₹{insight.impact.toLocaleString()}</span>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Tax Optimization Roadmap */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Tax Optimization Roadmap
            </CardTitle>
            <CardDescription>
              Step-by-step plan to minimize your tax liability
            </CardDescription>
          </CardHeader>
          <CardContent>
            {optimization && (
              <div className="space-y-4">
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-green-800 dark:text-green-300">Potential Tax Savings</h4>
                    <Badge variant="secondary">₹{optimization.savings.toLocaleString()}</Badge>
                  </div>
                  <Progress 
                    value={(optimization.savings / optimization.currentTax) * 100} 
                    className="h-2"
                  />
                  <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                    {((optimization.savings / optimization.currentTax) * 100).toFixed(1)}% reduction possible
                  </p>
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium text-sm">Recommended Actions:</h4>
                  {optimization.recommendations.map((rec, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-muted/30 rounded">
                      <div>
                        <p className="text-sm font-medium">{rec.category}</p>
                        <p className="text-xs text-muted-foreground">{rec.action}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-green-600">₹{rec.savings.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground">savings</p>
                      </div>
                    </div>
                  ))}
                </div>

                <Button className="w-full" onClick={() => onNavigate('calculator')}>
                  <Calculator className="h-4 w-4 mr-2" />
                  Calculate Detailed Tax
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Quick Actions
          </CardTitle>
          <CardDescription>
            Common tax-related tasks and tools
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { 
                label: 'Tax Calculator', 
                desc: 'Calculate tax liability', 
                icon: Calculator, 
                page: 'calculator',
                color: 'text-blue-600' 
              },
              { 
                label: 'Upload Documents', 
                desc: 'AI document analysis', 
                icon: FileText, 
                page: 'documents',
                color: 'text-green-600' 
              },
              { 
                label: 'Investment Ideas', 
                desc: 'Tax-saving options', 
                icon: TrendingUp, 
                page: 'insights',
                color: 'text-purple-600' 
              },
              { 
                label: 'Transaction Analysis', 
                desc: 'Expense categorization', 
                icon: BarChart3, 
                page: 'analyzer',
                color: 'text-orange-600' 
              }
            ].map((action, index) => (
              <Button
                key={index}
                variant="outline"
                className="h-auto p-4 flex flex-col items-start gap-2 hover:bg-muted/50"
                onClick={() => onNavigate(action.page)}
              >
                <action.icon className={`h-5 w-5 ${action.color}`} />
                <div className="text-left">
                  <p className="font-medium text-sm">{action.label}</p>
                  <p className="text-xs text-muted-foreground">{action.desc}</p>
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* AI Assistant Modal */}
      <TaxAIAssistant
        isOpen={isAIOpen}
        onToggle={() => setIsAIOpen(!isAIOpen)}
        onNavigate={onNavigate}
      />
    </div>
  );
}