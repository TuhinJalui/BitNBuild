import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { ScrollArea } from '../ui/scroll-area';
import { 
  Brain, 
  Send, 
  Mic, 
  Calculator, 
  FileText, 
  TrendingUp, 
  AlertCircle,
  CheckCircle,
  DollarSign,
  PieChart,
  Target,
  Clock,
  Lightbulb
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { 
  calculateTotalTax, 
  compareRegimes, 
  getInvestmentRecommendations,
  type TaxableIncome,
  type Deductions 
} from '../../utils/taxCalculations';
import { analyzeTransactions, generateInsights, type TransactionData } from '../../utils/csvParser';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  data?: any;
  actionType?: 'calculation' | 'recommendation' | 'analysis' | 'insight';
}

interface TaxAIAssistantProps {
  isOpen: boolean;
  onToggle: () => void;
  userTransactions?: TransactionData[];
  onNavigate: (page: string) => void;
}

export function TaxAIAssistant({ isOpen, onToggle, userTransactions, onNavigate }: TaxAIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: "Hi! I'm your Tax AI Assistant. I can help you with:\n\n• Tax calculations for both Old & New regime\n• Investment recommendations for tax saving\n• Analysis of your financial transactions\n• ITR filing guidance\n• Deduction optimization\n\nWhat would you like to know about your taxes?",
      timestamp: new Date(),
      actionType: 'insight'
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen) {
      inputRef.current?.focus();
    }
  }, [isOpen]);

  const quickActions = [
    { label: 'Calculate Tax', icon: Calculator, action: 'calculate_tax' },
    { label: 'Compare Regimes', icon: PieChart, action: 'compare_regimes' },
    { label: 'Investment Ideas', icon: TrendingUp, action: 'investment_recommendations' },
    { label: 'Analyze Expenses', icon: FileText, action: 'analyze_transactions' },
    { label: 'Tax Saving Tips', icon: Lightbulb, action: 'tax_tips' },
    { label: 'ITR Filing', icon: Target, action: 'itr_filing' }
  ];

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate realistic AI processing delay
    setTimeout(() => {
      const response = generateAIResponse(inputValue);
      setMessages(prev => [...prev, response]);
      setIsTyping(false);
    }, 800 + Math.random() * 1200);
  };

  const handleQuickAction = (action: string) => {
    const responses: Record<string, Message> = {
      calculate_tax: {
        id: Date.now().toString(),
        type: 'assistant',
        content: "I'll help you calculate your tax liability. Please provide your income details:\n\n• Annual Salary/Business Income\n• Other sources of income\n• Deductions (80C, 80D, etc.)\n\nOr you can navigate to the Tax Calculator for a detailed calculation.",
        timestamp: new Date(),
        actionType: 'calculation',
        data: { action: 'navigate', page: 'calculator' }
      },
      compare_regimes: {
        id: Date.now().toString(),
        type: 'assistant',
        content: "Let me help you choose between Old and New tax regime. Based on typical scenarios:\n\n**New Regime is better if:**\n• Limited deductions (< ₹2L)\n• Higher income with fewer investments\n\n**Old Regime is better if:**\n• Significant deductions (> ₹2L)\n• Home loan, insurance, investments\n\nShall I perform a detailed comparison with your data?",
        timestamp: new Date(),
        actionType: 'analysis'
      },
      investment_recommendations: {
        id: Date.now().toString(),
        type: 'assistant',
        content: "Here are smart tax-saving investment options:\n\n**Section 80C (₹1.5L limit):**\n• ELSS Mutual Funds - Best returns\n• PPF - Safe, tax-free returns\n• ULIP - Insurance + Investment\n\n**Section 80D (₹25K limit):**\n• Health Insurance premiums\n\n**Additional (₹50K):**\n• NPS under 80CCD(1B)\n\nWould you like personalized recommendations based on your income?",
        timestamp: new Date(),
        actionType: 'recommendation'
      },
      analyze_transactions: {
        id: Date.now().toString(),
        type: 'assistant',
        content: userTransactions ? 
          generateTransactionAnalysis(userTransactions) :
          "Upload your bank statement or transaction data to get AI-powered analysis of your spending patterns and tax-saving opportunities. Go to Transaction Analyzer to get started.",
        timestamp: new Date(),
        actionType: 'analysis',
        data: userTransactions ? analyzeTransactions(userTransactions) : { action: 'navigate', page: 'analyzer' }
      },
      tax_tips: {
        id: Date.now().toString(),
        type: 'assistant',
        content: "💡 **Smart Tax Saving Tips:**\n\n1. **Maximize 80C**: Invest ₹1.5L in ELSS, PPF, or life insurance\n2. **Health First**: ₹25K health insurance premium deduction\n3. **Home Loan**: Interest up to ₹2L deductible\n4. **NPS Boost**: Extra ₹50K deduction under 80CCD(1B)\n5. **HRA Claims**: If paying rent > 10% of basic salary\n6. **Donation**: 50-100% deduction under 80G\n\nStart early in the financial year for better planning!",
        timestamp: new Date(),
        actionType: 'insight'
      },
      itr_filing: {
        id: Date.now().toString(),
        type: 'assistant',
        content: "📋 **ITR Filing Checklist:**\n\n**Documents needed:**\n• Form 16 from employer\n• Bank statements\n• Investment proofs\n• TDS certificates\n\n**Key dates:**\n• Due date: July 31st (individuals)\n• Late filing penalty: ₹5,000-₹10,000\n\n**Forms:**\n• ITR-1: Salary income only\n• ITR-2: Multiple sources, capital gains\n\nNeed help with specific ITR queries?",
        timestamp: new Date(),
        actionType: 'insight'
      }
    };

    setMessages(prev => [...prev, responses[action]]);
  };

  const generateAIResponse = (query: string): Message => {
    const lowerQuery = query.toLowerCase();
    
    // Pattern matching for different types of queries
    if (lowerQuery.includes('calculate') || lowerQuery.includes('tax') && lowerQuery.includes('income')) {
      return generateTaxCalculationResponse(query);
    }
    
    if (lowerQuery.includes('save') || lowerQuery.includes('investment') || lowerQuery.includes('80c')) {
      return generateInvestmentResponse(query);
    }
    
    if (lowerQuery.includes('regime') || lowerQuery.includes('old') || lowerQuery.includes('new')) {
      return generateRegimeComparisonResponse();
    }
    
    if (lowerQuery.includes('deduction') || lowerQuery.includes('claim')) {
      return generateDeductionResponse();
    }
    
    if (lowerQuery.includes('itr') || lowerQuery.includes('filing') || lowerQuery.includes('return')) {
      return generateITRResponse();
    }

    if (lowerQuery.includes('hra') || lowerQuery.includes('rent')) {
      return generateHRAResponse();
    }

    if (lowerQuery.includes('tds') || lowerQuery.includes('refund')) {
      return generateTDSResponse();
    }

    // Default response with suggestions
    return {
      id: Date.now().toString(),
      type: 'assistant',
      content: `I understand you're asking about "${query}". Here are some things I can help you with:\n\n• Calculate your tax liability\n• Compare Old vs New tax regime\n• Suggest tax-saving investments\n• Analyze your spending patterns\n• ITR filing guidance\n• Deduction optimization\n\nCould you please be more specific about what you'd like to know?`,
      timestamp: new Date(),
      actionType: 'insight'
    };
  };

  const generateTaxCalculationResponse = (query: string): Message => {
    // Extract numbers from query if any
    const numbers = query.match(/\d+/g);
    const hasIncome = numbers && numbers.length > 0;

    if (hasIncome) {
      const income = parseInt(numbers[0]);
      const sampleCalculation = calculateTotalTax(
        { 
          basicSalary: income, 
          hra: income * 0.4, 
          specialAllowance: income * 0.2, 
          bonus: 0, 
          otherIncome: 0, 
          businessIncome: 0, 
          capitalGains: 0, 
          interestIncome: 0 
        },
        { 
          section80C: 100000, 
          section80D: 25000, 
          section80G: 0, 
          section24: 0, 
          standardDeduction: 50000, 
          professionalTax: 2400, 
          epf: income * 0.12, 
          nps: 0 
        },
        true
      );

      return {
        id: Date.now().toString(),
        type: 'assistant',
        content: `Based on ₹${income.toLocaleString()} annual income, here's an estimate:\n\n💰 **Tax Calculation:**\n• Total Income: ₹${sampleCalculation.totalIncome.toLocaleString()}\n• Deductions: ₹${sampleCalculation.totalDeductions.toLocaleString()}\n• Taxable Income: ₹${sampleCalculation.taxableIncome.toLocaleString()}\n• **Tax Liability: ₹${sampleCalculation.totalTax.toLocaleString()}**\n• Effective Rate: ${sampleCalculation.effectiveRate.toFixed(2)}%\n\nThis is an estimate. Use the Tax Calculator for precise calculations with your actual details.`,
        timestamp: new Date(),
        actionType: 'calculation',
        data: sampleCalculation
      };
    }

    return {
      id: Date.now().toString(),
      type: 'assistant',
      content: "I'll help you calculate your tax! Please provide:\n\n1. **Annual Salary/Income**: Your gross annual income\n2. **Deductions**: HRA, 80C investments, etc.\n3. **Regime Preference**: Old or New\n\nExample: \"Calculate tax for 12 lakh salary\"\n\nOr use our Tax Calculator for detailed computation.",
      timestamp: new Date(),
      actionType: 'calculation',
      data: { action: 'navigate', page: 'calculator' }
    };
  };

  const generateInvestmentResponse = (query: string): Message => {
    const sampleRecommendations = getInvestmentRecommendations(
      { section80C: 50000, section80D: 10000, section80G: 0, section24: 0, standardDeduction: 50000, professionalTax: 0, epf: 0, nps: 0 },
      30000
    );

    return {
      id: Date.now().toString(),
      type: 'assistant',
      content: `🎯 **Smart Investment Recommendations:**\n\n${sampleRecommendations.slice(0, 3).map((rec, i) => 
        `${i + 1}. **${rec.instrument}** (${rec.section})\n   • Max: ₹${rec.maxAmount.toLocaleString()}\n   • Tax Saving: ₹${rec.taxSaving.toLocaleString()}\n   • ${rec.description}`
      ).join('\n\n')}\n\n💡 **Tip**: Start with ELSS for best returns with shortest lock-in period.\n\nWant personalized recommendations? Visit Investment Recommender.`,
      timestamp: new Date(),
      actionType: 'recommendation',
      data: sampleRecommendations
    };
  };

  const generateRegimeComparisonResponse = (): Message => {
    const sampleIncome = { basicSalary: 1000000, hra: 400000, specialAllowance: 200000, bonus: 0, otherIncome: 0, businessIncome: 0, capitalGains: 0, interestIncome: 0 };
    const sampleDeductions = { section80C: 150000, section80D: 25000, section80G: 0, section24: 0, standardDeduction: 50000, professionalTax: 2400, epf: 120000, nps: 0 };
    
    const comparison = compareRegimes(sampleIncome, sampleDeductions);

    return {
      id: Date.now().toString(),
      type: 'assistant',
      content: `📊 **Tax Regime Comparison:**\n\n**Old Regime:**\n• Tax: ₹${comparison.oldRegime.totalTax.toLocaleString()}\n• Deductions: ₹${comparison.oldRegime.totalDeductions.toLocaleString()}\n\n**New Regime:**\n• Tax: ₹${comparison.newRegime.totalTax.toLocaleString()}\n• Deductions: ₹${comparison.newRegime.totalDeductions.toLocaleString()}\n\n✅ **Recommended**: ${comparison.recommendation.toUpperCase()} regime\n💰 **Savings**: ₹${comparison.savings.toLocaleString()}\n\nThis is a sample calculation. Use Tax Calculator with your actual figures.`,
      timestamp: new Date(),
      actionType: 'analysis',
      data: comparison
    };
  };

  const generateDeductionResponse = (): Message => {
    return {
      id: Date.now().toString(),
      type: 'assistant',
      content: `📝 **Available Tax Deductions:**\n\n**Section 80C (₹1.5L)**\n• EPF, PPF, ELSS, Life Insurance, Home Loan Principal\n\n**Section 80D (₹25K)**\n• Health Insurance premiums\n\n**Section 24(b) (₹2L)**\n• Home Loan Interest\n\n**Section 80CCD(1B) (₹50K)**\n• Additional NPS contribution\n\n**HRA**\n• House Rent (conditions apply)\n\n**Standard Deduction (₹50K)**\n• Automatic for salaried individuals\n\nNeed help calculating specific deductions?`,
      timestamp: new Date(),
      actionType: 'insight'
    };
  };

  const generateITRResponse = (): Message => {
    return {
      id: Date.now().toString(),
      type: 'assistant',
      content: `📋 **ITR Filing Guide:**\n\n**Choose Right Form:**\n• ITR-1: Salary, pension, one house\n• ITR-2: Multiple income sources, capital gains\n• ITR-3: Business/professional income\n\n**Key Documents:**\n• Form 16 (TDS certificate)\n• Bank statements\n• Investment proofs (80C, 80D)\n• Capital gains statements\n\n**Important Dates:**\n• Due date: July 31st\n• Revised return: December 31st\n\n**E-filing Process:**\n1. Register on Income Tax portal\n2. Choose appropriate ITR form\n3. Fill income & deduction details\n4. Calculate tax & verify\n5. Submit with digital signature/EVC\n\nNeed help with specific ITR sections?`,
      timestamp: new Date(),
      actionType: 'insight'
    };
  };

  const generateHRAResponse = (): Message => {
    return {
      id: Date.now().toString(),
      type: 'assistant',
      content: `🏠 **HRA Exemption Calculation:**\n\nHRA exemption is **minimum of:**\n1. Actual HRA received\n2. 50% of basic salary (Metro) / 40% (Non-metro)\n3. Rent paid - 10% of basic salary\n\n**Requirements:**\n• Must be paying rent\n• Rent receipts for >₹1L annually\n• PAN of landlord if rent >₹1L\n\n**Example:**\nBasic Salary: ₹60,000/month\nHRA Received: ₹24,000/month\nRent Paid: ₹20,000/month\n\nExemption = Min of:\n1. ₹24,000 (HRA received)\n2. ₹30,000 (50% of basic - Metro)\n3. ₹14,000 (Rent - 10% basic)\n\n**Exempt HRA**: ₹14,000/month\n\nNeed help calculating your HRA exemption?`,
      timestamp: new Date(),
      actionType: 'calculation'
    };
  };

  const generateTDSResponse = (): Message => {
    return {
      id: Date.now().toString(),
      type: 'assistant',
      content: `💳 **TDS & Refund Guide:**\n\n**Common TDS Sources:**\n• Salary (employer deducts monthly)\n• Bank Interest (>₹10K annually)\n• Professional fees (>₹30K)\n• Rent (>₹2.4L annually)\n\n**Getting Refund:**\n1. File ITR even if no tax liability\n2. Claim excess TDS deducted\n3. Refund processed after verification\n\n**TDS Certificate Types:**\n• Form 16: Salary TDS\n• Form 16A: Other TDS\n• Form 26AS: Consolidated TDS view\n\n**Pro Tip:**\nSubmit Form 15G/15H to avoid TDS if total income < exemption limit.\n\nCheck Form 26AS to verify TDS credits!`,
      timestamp: new Date(),
      actionType: 'insight'
    };
  };

  const generateTransactionAnalysis = (transactions: TransactionData[]): string => {
    const analysis = analyzeTransactions(transactions);
    const insights = generateInsights(transactions);

    return `📊 **Your Financial Analysis:**\n\n**Summary:**\n• Total Income: ₹${analysis.totalIncome.toLocaleString()}\n• Total Expenses: ₹${analysis.totalExpenses.toLocaleString()}\n• Tax-Saving Investments: ₹${analysis.taxSavingInvestments.toLocaleString()}\n\n**Deductions Found:**\n• Section 80C: ₹${analysis.deductibleExpenses.section80C.toLocaleString()}\n• Section 80D: ₹${analysis.deductibleExpenses.section80D.toLocaleString()}\n\n**💡 Insights:**\n${insights.slice(0, 3).map(insight => `• ${insight}`).join('\n')}\n\nUse Transaction Analyzer for detailed breakdown.`;
  };

  const startVoiceInput = () => {
    if ('webkitSpeechRecognition' in window) {
      const recognition = new (window as any).webkitSpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      setIsListening(true);
      recognition.start();

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputValue(transcript);
        setIsListening(false);
      };

      recognition.onerror = () => {
        setIsListening(false);
        toast.error('Voice recognition failed');
      };

      recognition.onend = () => {
        setIsListening(false);
      };
    } else {
      toast.error('Voice recognition not supported');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl h-[80vh] flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <div className="flex items-center space-x-2">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Brain className="h-5 w-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-lg">Tax AI Assistant</CardTitle>
              <CardDescription>Your intelligent tax consultation partner</CardDescription>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={onToggle}>
            ✕
          </Button>
        </CardHeader>

        <div className="px-6 pb-4">
          <div className="flex flex-wrap gap-2">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Button
                  key={action.action}
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickAction(action.action)}
                  className="text-xs"
                >
                  <Icon className="h-3 w-3 mr-1" />
                  {action.label}
                </Button>
              );
            })}
          </div>
        </div>

        <CardContent className="flex-1 flex flex-col min-h-0">
          <ScrollArea className="flex-1 pr-4">
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-lg p-3 ${
                      message.type === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted'
                    }`}
                  >
                    <div className="flex items-start space-x-2">
                      {message.type === 'assistant' && (
                        <div className="p-1 bg-primary/20 rounded">
                          {message.actionType === 'calculation' && <Calculator className="h-3 w-3 text-primary" />}
                          {message.actionType === 'recommendation' && <TrendingUp className="h-3 w-3 text-primary" />}
                          {message.actionType === 'analysis' && <PieChart className="h-3 w-3 text-primary" />}
                          {message.actionType === 'insight' && <Lightbulb className="h-3 w-3 text-primary" />}
                          {!message.actionType && <Brain className="h-3 w-3 text-primary" />}
                        </div>
                      )}
                      <div className="flex-1">
                        <p className="whitespace-pre-line text-sm">{message.content}</p>
                        {message.data?.action === 'navigate' && (
                          <Button
                            size="sm"
                            className="mt-2"
                            onClick={() => onNavigate(message.data.page)}
                          >
                            Open {message.data.page === 'calculator' ? 'Tax Calculator' : 'Tool'}
                          </Button>
                        )}
                        <p className="text-xs opacity-70 mt-1">
                          {message.timestamp.toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-muted rounded-lg p-3 max-w-[80%]">
                    <div className="flex items-center space-x-2">
                      <div className="p-1 bg-primary/20 rounded">
                        <Brain className="h-3 w-3 text-primary animate-pulse" />
                      </div>
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <div ref={messagesEndRef} />
          </ScrollArea>

          <div className="flex items-center space-x-2 pt-4">
            <div className="flex-1 relative">
              <Input
                ref={inputRef}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask about taxes, deductions, ITR filing..."
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                className="pr-10"
              />
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8"
                onClick={startVoiceInput}
                disabled={isListening}
              >
                <Mic className={`h-4 w-4 ${isListening ? 'text-red-500 animate-pulse' : ''}`} />
              </Button>
            </div>
            <Button onClick={handleSendMessage} disabled={!inputValue.trim() || isTyping}>
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}