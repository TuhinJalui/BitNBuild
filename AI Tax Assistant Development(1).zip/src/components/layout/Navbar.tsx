import React from 'react';
import { Button } from '../ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Badge } from '../ui/badge';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';
import { 
  Brain, 
  User, 
  Settings, 
  LogOut, 
  Bell, 
  CreditCard,
  FileText,
  Calculator,
  Scan,
  TrendingUp,
  Receipt,
  BarChart3
} from 'lucide-react';

interface NavbarProps {
  user: {
    name: string;
    email: string;
  };
  currentPage: string;
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export function Navbar({ user, currentPage, onNavigate, onLogout }: NavbarProps) {
  const navigationItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Brain },
    { id: 'calculator', label: 'Tax Calculator', icon: Calculator },
    { id: 'analyzer', label: 'Transaction Analyzer', icon: Scan },
    { id: 'insights', label: 'Investments', icon: TrendingUp },
    { id: 'cibil', label: 'CIBIL Simulator', icon: CreditCard },
    { id: 'gst', label: 'GST Assistant', icon: Receipt },
    { id: 'documents', label: 'Documents', icon: FileText },
  ];

  return (
    <nav className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4">
        {/* Logo and Brand */}
        <div 
          className="flex items-center space-x-3 cursor-pointer min-w-0"
          onClick={() => onNavigate('dashboard')}
        >
          <div className="bg-primary/20 p-2 rounded-xl shrink-0">
            <Brain className="h-5 w-5 md:h-6 md:w-6 text-primary" />
          </div>
          <div className="min-w-0">
            <h1 className="text-lg md:text-xl font-bold text-foreground truncate">TaxWise</h1>
            <p className="text-xs text-muted-foreground hidden sm:block">AI Tax Assistant</p>
          </div>
        </div>

        {/* Navigation Links */}
        <div className="hidden lg:flex items-center space-x-1">
          {navigationItems.slice(0, 4).map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            
            return (
              <Button
                key={item.id}
                variant={isActive ? "default" : "ghost"}
                className="flex items-center gap-2 text-foreground hover:text-foreground"
                onClick={() => onNavigate(item.id)}
              >
                <Icon className="h-4 w-4" />
                <span className="hidden xl:inline">{item.label}</span>
              </Button>
            );
          })}
          
          {/* More Menu for Additional Items */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="text-foreground hover:text-foreground">
                <BarChart3 className="h-4 w-4 mr-2" />
                <span className="hidden xl:inline">More</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              {navigationItems.slice(4).map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.id;
                return (
                  <DropdownMenuItem 
                    key={item.id} 
                    onClick={() => onNavigate(item.id)}
                    className={isActive ? "bg-accent" : ""}
                  >
                    <Icon className="mr-2 h-4 w-4" />
                    <span>{item.label}</span>
                  </DropdownMenuItem>
                );
              })}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Mobile Navigation */}
        <div className="lg:hidden">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="text-foreground hover:text-foreground">
                <BarChart3 className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel className="px-2">
                <span className="text-sm font-medium">Navigation</span>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              {navigationItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.id;
                return (
                  <DropdownMenuItem 
                    key={item.id} 
                    onClick={() => onNavigate(item.id)}
                    className={isActive ? "bg-accent" : ""}
                  >
                    <Icon className="mr-3 h-4 w-4" />
                    <span className="text-sm">{item.label}</span>
                  </DropdownMenuItem>
                );
              })}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Right Side - Notifications and User Menu */}
        <div className="flex items-center space-x-2 md:space-x-4">
          {/* Notifications */}
          <Button variant="ghost" size="icon" className="relative text-foreground hover:text-foreground">
            <Bell className="h-4 w-4" />
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
            >
              3
            </Badge>
          </Button>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 md:h-10 md:w-10 rounded-full">
                <Avatar className="h-8 w-8 md:h-10 md:w-10">
                  <AvatarImage src="" alt={user.name} />
                  <AvatarFallback className="text-xs md:text-sm">
                    {user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none truncate">{user.name}</p>
                  <p className="text-xs leading-none text-muted-foreground truncate">
                    {user.email}
                  </p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => onNavigate('profile')}>
                <User className="mr-2 h-4 w-4" />
                <span>Profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onNavigate('settings')}>
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={onLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
}