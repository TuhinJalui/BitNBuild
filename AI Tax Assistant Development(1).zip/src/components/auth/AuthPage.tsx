import React, { useState } from 'react';
import { LoginForm } from './LoginForm';
import { RegisterForm } from './RegisterForm';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { Brain, Shield, TrendingUp, Calculator } from 'lucide-react';

interface AuthPageProps {
  onLogin: (email: string, password: string) => void;
  onRegister: (name: string, email: string, password: string) => void;
  onGoogleLogin: () => void;
}

export function AuthPage({ onLogin, onRegister, onGoogleLogin }: AuthPageProps) {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/10 flex">
      {/* Left side - Hero content */}
      <div className="flex-1 flex flex-col justify-center px-8 lg:px-16">
        <div className="max-w-2xl">
          <div className="flex items-center space-x-3 mb-8">
            <div className="bg-primary/20 p-3 rounded-xl">
              <Brain className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold text-foreground">TaxWise</h1>
          </div>
          
          <h2 className="text-5xl font-bold text-foreground mb-6 leading-tight">
            AI-Powered
            <br />
            <span className="text-primary">Tax Assistant</span>
          </h2>
          
          <p className="text-muted-foreground mb-12 leading-relaxed text-[20px] font-bold font-normal">
            Simplify tax filing and optimize your finances with intelligent insights. 
            Get personalized recommendations for tax savings and CIBIL score improvement.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-start space-x-4">
              <div className="bg-primary/10 p-2 rounded-lg">
                <Calculator className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h4>Smart Tax Optimization</h4>
                <p className="text-sm text-muted-foreground">AI analyzes your finances to maximize legal tax savings</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="bg-primary/10 p-2 rounded-lg">
                <TrendingUp className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h4>CIBIL Score Advisor</h4>
                <p className="text-sm text-muted-foreground">Get actionable insights to improve your credit health</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="bg-primary/10 p-2 rounded-lg">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h4>Secure & Private</h4>
                <p className="text-sm text-muted-foreground">Bank-grade security for your financial data</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="bg-primary/10 p-2 rounded-lg">
                <Brain className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h4>AI-Driven Insights</h4>
                <p className="text-sm text-muted-foreground">Personalized financial recommendations</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Right side - Auth form */}
      <div className="flex-1 flex items-center justify-center px-8 lg:px-16">
        <div className="w-full max-w-md">
          {isLogin ? (
            <LoginForm
              onLogin={onLogin}
              onGoogleLogin={onGoogleLogin}
              onToggleMode={() => setIsLogin(false)}
            />
          ) : (
            <RegisterForm
              onRegister={onRegister}
              onGoogleLogin={onGoogleLogin}
              onToggleMode={() => setIsLogin(true)}
            />
          )}
        </div>
      </div>
    </div>
  );
}