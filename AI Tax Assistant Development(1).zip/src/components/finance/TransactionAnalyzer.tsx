import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Textarea } from '../ui/textarea';
import { 
  Upload, 
  Scan, 
  FileText, 
  CheckCircle2, 
  AlertTriangle,
  TrendingUp,
  PieChart,
  Calculator,
  Lightbulb,
  IndianRupee,
  Calendar,
  Tag,
  Search,
  Filter,
  Download
} from 'lucide-react';

interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  category: string;
  taxSection?: string;
  confidence: number;
  verified: boolean;
  suggestions?: string[];
}

interface DeductionOpportunity {
  section: string;
  description: string;
  potentialSaving: number;
  recommendations: string[];
  priority: 'high' | 'medium' | 'low';
}

export function TransactionAnalyzer() {
  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: '1',
      date: '2024-01-15',
      description: 'LIC Premium Payment - Policy #12345678',
      amount: 25000,
      category: 'Insurance',
      taxSection: '80C',
      confidence: 95,
      verified: true,
      suggestions: ['Life insurance premiums are eligible for 80C deduction up to ₹1.5L']
    },
    {
      id: '2',
      date: '2024-01-20',
      description: 'Star Health Insurance Premium',
      amount: 15000,
      category: 'Health Insurance',
      taxSection: '80D',
      confidence: 98,
      verified: true,
      suggestions: ['Health insurance premiums qualify for 80D deduction up to ₹25K']
    },
    {
      id: '3',
      date: '2024-02-01',
      description: 'Home Loan EMI - HDFC Bank',
      amount: 35000,
      category: 'Home Loan',
      taxSection: '24(b)',
      confidence: 85,
      verified: false,
      suggestions: ['Principal component qualifies for 80C, interest for 24(b) deduction']
    },
    {
      id: '4',
      date: '2024-02-05',
      description: 'Medical Expenses - Apollo Hospital',
      amount: 8000,
      category: 'Medical',
      taxSection: '80D',
      confidence: 75,
      verified: false,
      suggestions: ['Medical expenses may qualify for 80D if for preventive health checkup']
    }
  ]);

  const [deductionGaps, setDeductionGaps] = useState<DeductionOpportunity[]>([
    {
      section: '80C',
      description: 'You have used ₹60,000 of ₹1,50,000 limit',
      potentialSaving: 27000,
      recommendations: [
        'Invest ₹90,000 more in ELSS mutual funds',
        'Increase PPF contribution',
        'Consider life insurance or ULIP'
      ],
      priority: 'high'
    },
    {
      section: '80D',
      description: 'Health insurance gap for parents',
      potentialSaving: 7500,
      recommendations: [
        'Buy health insurance for parents (₹25K limit)',
        'Includes preventive health checkup expenses'
      ],
      priority: 'medium'
    },
    {
      section: '80CCD(1B)',
      description: 'NPS contribution not maxed out',
      potentialSaving: 15000,
      recommendations: [
        'Invest in NPS for additional ₹50K deduction',
        'Over and above 80C limit'
      ],
      priority: 'medium'
    }
  ]);

  const [uploadProgress, setUploadProgress] = useState(0);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleFileUpload = (file: File) => {
    setIsAnalyzing(true);
    setUploadProgress(0);

    // Simulate file processing
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsAnalyzing(false);
          // Add mock analyzed transactions
          const newTransactions: Transaction[] = [
            {
              id: Date.now().toString(),
              date: '2024-02-10',
              description: 'Mutual Fund SIP - HDFC Tax Saver',
              amount: 10000,
              category: 'Investment',
              taxSection: '80C',
              confidence: 92,
              verified: false,
              suggestions: ['ELSS mutual funds qualify for 80C deduction']
            }
          ];
          setTransactions(prev => [...prev, ...newTransactions]);
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  const verifyTransaction = (id: string) => {
    setTransactions(prev => 
      prev.map(t => t.id === id ? { ...t, verified: true } : t)
    );
  };

  const totalPotentialSaving = deductionGaps.reduce((sum, gap) => sum + gap.potentialSaving, 0);
  const verifiedTransactions = transactions.filter(t => t.verified);
  const totalDeductions = verifiedTransactions.reduce((sum, t) => sum + t.amount, 0);

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-white">Smart Transaction Analyzer</h1>
        <p className="text-white/70">AI-powered transaction analysis to find tax deduction opportunities</p>
      </div>

      <Tabs defaultValue="analyzer" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="analyzer" className="flex items-center gap-2 text-white">
            <Scan className="h-4 w-4" />
            Analyzer
          </TabsTrigger>
          <TabsTrigger value="opportunities" className="flex items-center gap-2 text-white">
            <Lightbulb className="h-4 w-4" />
            Opportunities
          </TabsTrigger>
          <TabsTrigger value="summary" className="flex items-center gap-2 text-white">
            <PieChart className="h-4 w-4" />
            Summary
          </TabsTrigger>
        </TabsList>

        {/* Transaction Analyzer */}
        <TabsContent value="analyzer" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Upload Section */}
            <Card className="bg-background/50 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Upload className="h-5 w-5" />
                  Upload Documents
                </CardTitle>
                <CardDescription className="text-white/70">
                  Upload bank statements, bills, or receipts for analysis
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-2 border-dashed border-primary/20 rounded-lg p-6 text-center">
                  <Upload className="h-12 w-12 text-primary mx-auto mb-4" />
                  <p className="text-white/70 mb-4">Drag & drop files or click to upload</p>
                  <Input
                    type="file"
                    multiple
                    accept=".pdf,.jpg,.png,.csv"
                    onChange={(e) => {
                      const files = e.target.files;
                      if (files && files[0]) {
                        handleFileUpload(files[0]);
                      }
                    }}
                    className="hidden"
                    id="file-upload"
                  />
                  <Button 
                    variant="outline" 
                    className="text-white border-primary/20 hover:bg-primary/20"
                    onClick={() => document.getElementById('file-upload')?.click()}
                  >
                    Choose Files
                  </Button>
                </div>

                {isAnalyzing && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-white/70">Analyzing...</span>
                      <span className="text-white">{uploadProgress}%</span>
                    </div>
                    <Progress value={uploadProgress} className="w-full" />
                  </div>
                )}

                <div className="space-y-2">
                  <Label className="text-white">Or paste transaction text</Label>
                  <Textarea
                    placeholder="Paste transaction details, bank statements, or bill information..."
                    className="bg-background/50 border-primary/20 text-white"
                    rows={4}
                  />
                  <Button className="w-full bg-primary hover:bg-primary/90 text-white">
                    <Scan className="h-4 w-4 mr-2" />
                    Analyze Text
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Analysis Results */}
            <div className="lg:col-span-2 space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold text-white">Detected Transactions</h3>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="text-white border-primary/20 hover:bg-primary/20">
                    <Filter className="h-4 w-4 mr-1" />
                    Filter
                  </Button>
                  <Button variant="outline" size="sm" className="text-white border-primary/20 hover:bg-primary/20">
                    <Download className="h-4 w-4 mr-1" />
                    Export
                  </Button>
                </div>
              </div>

              <div className="space-y-3">
                {transactions.map((transaction) => (
                  <Card key={transaction.id} className="bg-background/50 border-primary/20">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="text-white font-medium">{transaction.description}</h4>
                            {transaction.verified ? (
                              <CheckCircle2 className="h-4 w-4 text-green-500" />
                            ) : (
                              <AlertTriangle className="h-4 w-4 text-yellow-500" />
                            )}
                          </div>
                          <div className="flex items-center gap-4 text-sm text-white/70">
                            <span>{transaction.date}</span>
                            <span>₹{transaction.amount.toLocaleString()}</span>
                            <Badge variant="outline" className="text-xs text-primary border-primary/20">
                              {transaction.category}
                            </Badge>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge 
                            className={`${
                              transaction.taxSection 
                                ? 'bg-green-500/20 text-green-400' 
                                : 'bg-gray-500/20 text-gray-400'
                            }`}
                          >
                            {transaction.taxSection || 'No section detected'}
                          </Badge>
                          <p className="text-xs text-white/70 mt-1">
                            {transaction.confidence}% confidence
                          </p>
                        </div>
                      </div>

                      {transaction.suggestions && transaction.suggestions.length > 0 && (
                        <div className="mb-3 p-3 bg-primary/5 rounded-lg">
                          <p className="text-sm text-white/70 mb-2">AI Suggestion:</p>
                          <p className="text-sm text-white">{transaction.suggestions[0]}</p>
                        </div>
                      )}

                      <div className="flex justify-between items-center">
                        <div className="flex gap-2">
                          {!transaction.verified && (
                            <Button 
                              size="sm" 
                              onClick={() => verifyTransaction(transaction.id)}
                              className="bg-green-600 hover:bg-green-700 text-white"
                            >
                              Verify & Add
                            </Button>
                          )}
                          <Button variant="outline" size="sm" className="text-white border-primary/20 hover:bg-primary/20">
                            Edit
                          </Button>
                        </div>
                        <Progress value={transaction.confidence} className="w-20" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Deduction Opportunities */}
        <TabsContent value="opportunities" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card className="bg-gradient-to-r from-green-500/20 to-green-500/10 border-green-500/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Potential Tax Savings</p>
                    <p className="text-white text-2xl font-bold">₹{totalPotentialSaving.toLocaleString()}</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-background/50 border-primary/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Current Deductions</p>
                    <p className="text-white text-2xl font-bold">₹{totalDeductions.toLocaleString()}</p>
                  </div>
                  <IndianRupee className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-background/50 border-primary/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Opportunities Found</p>
                    <p className="text-white text-2xl font-bold">{deductionGaps.length}</p>
                  </div>
                  <Lightbulb className="h-8 w-8 text-yellow-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-white">Missed Deduction Opportunities</h3>
            
            {deductionGaps.map((gap, index) => (
              <Card key={index} className="bg-background/50 border-primary/20">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="text-white font-semibold">Section {gap.section}</h4>
                        <Badge 
                          className={`${
                            gap.priority === 'high' ? 'bg-red-500' :
                            gap.priority === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                          } text-white`}
                        >
                          {gap.priority} priority
                        </Badge>
                      </div>
                      <p className="text-white/70">{gap.description}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-green-400 font-bold text-lg">₹{gap.potentialSaving.toLocaleString()}</p>
                      <p className="text-white/70 text-sm">potential saving</p>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    <h5 className="text-white font-medium text-sm">Recommendations:</h5>
                    <ul className="space-y-1">
                      {gap.recommendations.map((rec, idx) => (
                        <li key={idx} className="text-white/70 text-sm flex items-start gap-2">
                          <CheckCircle2 className="h-3 w-3 text-green-500 mt-0.5 flex-shrink-0" />
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Button className="w-full bg-primary hover:bg-primary/90 text-white">
                    <Calculator className="h-4 w-4 mr-2" />
                    Optimize Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Summary */}
        <TabsContent value="summary" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-background/50 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white">Deduction Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-white/70">Section 80C:</span>
                    <span className="text-white font-medium">₹60,000 / ₹1,50,000</span>
                  </div>
                  <Progress value={40} className="w-full" />
                  
                  <div className="flex justify-between">
                    <span className="text-white/70">Section 80D:</span>
                    <span className="text-white font-medium">₹15,000 / ₹25,000</span>
                  </div>
                  <Progress value={60} className="w-full" />
                  
                  <div className="flex justify-between">
                    <span className="text-white/70">Section 24(b):</span>
                    <span className="text-white font-medium">₹35,000 / ₹2,00,000</span>
                  </div>
                  <Progress value={17.5} className="w-full" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-background/50 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white">Action Items</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-red-500/10 rounded-lg border border-red-500/20">
                  <h5 className="text-white font-medium text-sm mb-2">High Priority</h5>
                  <p className="text-white/70 text-sm">Invest ₹90,000 more in 80C instruments</p>
                </div>
                
                <div className="p-3 bg-yellow-500/10 rounded-lg border border-yellow-500/20">
                  <h5 className="text-white font-medium text-sm mb-2">Medium Priority</h5>
                  <p className="text-white/70 text-sm">Consider NPS for additional ₹50K deduction</p>
                </div>
                
                <div className="p-3 bg-green-500/10 rounded-lg border border-green-500/20">
                  <h5 className="text-white font-medium text-sm mb-2">Good Progress</h5>
                  <p className="text-white/70 text-sm">Health insurance coverage is on track</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}