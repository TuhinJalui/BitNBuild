import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { ScrollArea } from '../ui/scroll-area';
import { Badge } from '../ui/badge';
import { 
  MessageCircle, 
  Send, 
  Minimize2, 
  Maximize2, 
  X, 
  Bot, 
  User,
  Lightbulb,
  Calculator,
  FileText,
  TrendingUp
} from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  suggestions?: string[];
}

interface ChatbotProps {
  isOpen: boolean;
  onToggle: () => void;
}

export function Chatbot({ isOpen, onToggle }: ChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: "Hello! I'm your AI Tax Assistant. I can help you with tax calculations, investment advice, CIBIL score improvement, and financial planning. How can I assist you today?",
      timestamp: new Date(),
      suggestions: [
        "Calculate my tax liability",
        "How to improve CIBIL score?",
        "Best tax saving investments",
        "Compare tax regimes"
      ]
    }
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: content,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setNewMessage('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const botResponse = generateBotResponse(content);
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const generateBotResponse = (userInput: string): Message => {
    const input = userInput.toLowerCase();
    
    let response = '';
    let suggestions: string[] = [];

    if (input.includes('tax') && input.includes('calculate')) {
      response = `I can help you calculate your tax liability! Based on your profile, here's what I found:

**For Income ₹12,50,000:**
- Old Regime: ₹1,85,000 (with deductions)
- New Regime: ₹2,30,000 (no deductions)

**Recommendation:** Use the old regime and maximize your 80C deductions. You can save an additional ₹15,000 by investing ₹50,000 more in ELSS.

Would you like me to show detailed calculations?`;
      suggestions = ["Show detailed calculation", "Best 80C investments", "Compare both regimes"];
    } else if (input.includes('cibil') || input.includes('credit score')) {
      response = `Your current CIBIL score is 780 (Excellent)! Here are personalized tips to improve it further:

**Quick Wins:**
• Reduce credit utilization from 45% to 30% (+25 points)
• Set up autopay for all credit cards
• Request credit limit increases

**Long-term Strategy:**
• Keep old credit cards active
• Diversify your credit mix
• Monitor your credit report monthly

Your score has improved by +35 points this year. Great progress!`;
      suggestions = ["Check credit report", "Credit card recommendations", "How to reduce utilization?"];
    } else if (input.includes('investment') || input.includes('80c')) {
      response = `Here are the best tax-saving investments for you based on your profile:

**Top Recommendations:**
1. **ELSS Mutual Funds** - ₹50,000 (High returns + tax saving)
2. **PPF** - ₹1,50,000 annually (Safe, long-term)
3. **NPS** - ₹50,000 additional under 80CCD(1B)

**Your Current Status:**
- 80C utilized: ₹1,00,000/₹1,50,000
- Potential additional saving: ₹15,000

Start with ELSS SIP of ₹4,167/month to complete your 80C limit!`;
      suggestions = ["Start ELSS SIP", "NPS vs PPF comparison", "Show all 80C options"];
    } else if (input.includes('regime')) {
      response = `Great question! Let me compare both tax regimes for your income:

**Old Regime (Recommended for you):**
- Tax: ₹1,85,000 (after deductions)
- Can claim 80C, 80D, HRA, etc.
- Better if you have investments/loans

**New Regime:**
- Tax: ₹2,30,000 (lower rates, no deductions)
- Simpler calculation
- Better for minimal investments

**Verdict:** Old regime saves you ₹45,000 annually! Keep using it while maximizing deductions.`;
      suggestions = ["Maximize deductions", "Switch to new regime?", "Calculate for different income"];
    } else {
      response = `I understand you're asking about "${userInput}". I'm here to help with:

• **Tax Planning** - Calculate liability, choose regime, maximize savings
• **Investment Advice** - 80C options, ELSS, NPS, PPF recommendations  
• **CIBIL Score** - Improvement tips, credit health analysis
• **Financial Planning** - Budget analysis, expense optimization

What specific area would you like to explore?`;
      suggestions = ["Calculate my taxes", "Investment recommendations", "CIBIL improvement tips", "Analyze my expenses"];
    }

    return {
      id: Date.now().toString(),
      type: 'bot',
      content: response,
      timestamp: new Date(),
      suggestions
    };
  };

  const handleSuggestionClick = (suggestion: string) => {
    handleSendMessage(suggestion);
  };

  if (!isOpen) {
    return (
      <Button
        onClick={onToggle}
        className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg z-50"
        size="icon"
      >
        <MessageCircle className="h-6 w-6" />
      </Button>
    );
  }

  return (
    <Card className="fixed bottom-6 right-6 w-96 h-[500px] shadow-2xl z-50 flex flex-col">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 bg-primary text-primary-foreground rounded-t-lg">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Bot className="h-5 w-5" />
          TaxWise AI Assistant
        </CardTitle>
        <div className="flex gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-primary-foreground hover:bg-primary-foreground/20"
            onClick={onToggle}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col p-0">
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div key={message.id} className="space-y-3">
                <div
                  className={`flex gap-3 ${
                    message.type === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  {message.type === 'bot' && (
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                      <Bot className="h-4 w-4 text-primary-foreground" />
                    </div>
                  )}
                  <div
                    className={`max-w-[280px] p-3 rounded-lg ${
                      message.type === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted'
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    <p className="text-xs opacity-70 mt-1">
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                  {message.type === 'user' && (
                    <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                      <User className="h-4 w-4" />
                    </div>
                  )}
                </div>
                
                {message.suggestions && message.suggestions.length > 0 && (
                  <div className="ml-11 space-y-2">
                    <p className="text-xs text-muted-foreground">Quick actions:</p>
                    <div className="flex flex-wrap gap-2">
                      {message.suggestions.map((suggestion, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          className="text-xs h-7"
                          onClick={() => handleSuggestionClick(suggestion)}
                        >
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
            
            {isTyping && (
              <div className="flex gap-3">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <Bot className="h-4 w-4 text-primary-foreground" />
                </div>
                <div className="bg-muted p-3 rounded-lg">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
        
        <div className="p-4 border-t">
          <div className="flex gap-2">
            <Input
              placeholder="Ask me anything about taxes..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage(newMessage)}
              className="flex-1"
            />
            <Button
              onClick={() => handleSendMessage(newMessage)}
              disabled={!newMessage.trim() || isTyping}
              size="icon"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
          
          {/* Quick Action Buttons */}
          <div className="flex gap-2 mt-3">
            <Button
              variant="outline"
              size="sm"
              className="flex items-center gap-1 text-xs"
              onClick={() => handleSendMessage("Calculate my tax liability")}
            >
              <Calculator className="h-3 w-3" />
              Tax Calc
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="flex items-center gap-1 text-xs"
              onClick={() => handleSendMessage("Investment recommendations")}
            >
              <TrendingUp className="h-3 w-3" />
              Invest
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="flex items-center gap-1 text-xs"
              onClick={() => handleSendMessage("How to improve CIBIL score?")}
            >
              <Lightbulb className="h-3 w-3" />
              CIBIL
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}