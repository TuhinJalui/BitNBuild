import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  MessageSquare,
  Calculator,
  CreditCard,
  FileText,
  Home,
  Settings,
  User
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface VoiceAssistantProps {
  onNavigate?: (route: string) => void;
  onAction?: (action: string, data?: any) => void;
}

export function VoiceAssistant({ onNavigate, onAction }: VoiceAssistantProps) {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isMinimized, setIsMinimized] = useState(true);
  const [transcript, setTranscript] = useState('');
  const [response, setResponse] = useState('');
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);
  const [isSupported, setIsSupported] = useState(false);

  useEffect(() => {
    // Check for browser support
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      setIsSupported(true);
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-IN';

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event) => {
        const current = event.resultIndex;
        const transcript = event.results[current][0].transcript;
        setTranscript(transcript);
        
        if (event.results[current].isFinal) {
          processVoiceCommand(transcript);
        }
      };

      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      setRecognition(recognition);
    }
  }, []);

  const processVoiceCommand = async (command: string) => {
    const lowerCommand = command.toLowerCase();
    let responseText = '';

    // Navigation commands
    if (lowerCommand.includes('dashboard') || lowerCommand.includes('home')) {
      onNavigate?.('dashboard');
      responseText = 'Navigating to dashboard';
    } else if (lowerCommand.includes('tax calculator') || lowerCommand.includes('calculate tax')) {
      onNavigate?.('tax-calculator');
      responseText = 'Opening tax calculator';
    } else if (lowerCommand.includes('cibil') || lowerCommand.includes('credit score')) {
      onNavigate?.('cibil');
      responseText = 'Opening CIBIL score analysis';
    } else if (lowerCommand.includes('documents') || lowerCommand.includes('upload')) {
      onNavigate?.('documents');
      responseText = 'Opening document upload section';
    } else if (lowerCommand.includes('profile') || lowerCommand.includes('settings')) {
      onNavigate?.('profile');
      responseText = 'Opening profile settings';
    }
    // Tax-related queries
    else if (lowerCommand.includes('what is') && lowerCommand.includes('80c')) {
      responseText = 'Section 80C allows deduction up to ₹1.5 lakh for investments in PPF, ELSS, life insurance, and other specified instruments.';
    } else if (lowerCommand.includes('what is') && lowerCommand.includes('80d')) {
      responseText = 'Section 80D provides deduction for health insurance premiums up to ₹25,000 for self and family, additional ₹25,000 for parents.';
    } else if (lowerCommand.includes('old regime') || lowerCommand.includes('new regime')) {
      responseText = 'Old regime allows various deductions but has higher tax rates. New regime has lower rates but limited deductions. I can help you calculate which is better for you.';
    } else if (lowerCommand.includes('how to improve') && lowerCommand.includes('cibil')) {
      responseText = 'To improve CIBIL score: Pay bills on time, keep credit utilization below 30%, maintain old credit accounts, and check your credit report regularly.';
    } else if (lowerCommand.includes('tax saving') || lowerCommand.includes('save tax')) {
      responseText = 'Popular tax saving options include ELSS mutual funds, PPF, NPS, life insurance, and home loan interest under section 24B.';
    }
    // Action commands
    else if (lowerCommand.includes('calculate') && lowerCommand.includes('income')) {
      onAction?.('calculate-tax');
      responseText = 'I\'ll help you calculate your tax. Please provide your annual income.';
    } else if (lowerCommand.includes('show') && lowerCommand.includes('recommendations')) {
      onAction?.('show-recommendations');
      responseText = 'Here are your personalized tax saving recommendations.';
    }
    // Default response
    else {
      responseText = 'I can help you with tax calculations, CIBIL score analysis, document uploads, and financial planning. Try saying "calculate tax" or "show my CIBIL score".';
    }

    setResponse(responseText);
    speak(responseText);
  };

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      setIsSpeaking(true);
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-IN';
      utterance.rate = 0.9;
      utterance.pitch = 1;
      
      utterance.onend = () => {
        setIsSpeaking(false);
      };

      speechSynthesis.speak(utterance);
    }
  };

  const startListening = () => {
    if (recognition && !isListening) {
      setTranscript('');
      setResponse('');
      recognition.start();
    }
  };

  const stopListening = () => {
    if (recognition && isListening) {
      recognition.stop();
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  if (!isSupported) {
    return null;
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {!isMinimized && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            transition={{ duration: 0.2 }}
            className="mb-4"
          >
            <Card className="w-80 bg-background/95 backdrop-blur-sm border-primary/20 shadow-lg">
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-white flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" />
                    TaxWise AI Assistant
                  </h3>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setIsMinimized(true)}
                    className="text-white hover:text-primary"
                  >
                    ×
                  </Button>
                </div>

                {(isListening || transcript || response) && (
                  <div className="space-y-2">
                    {isListening && (
                      <div className="flex items-center gap-2 text-white">
                        <motion.div
                          animate={{ scale: [1, 1.2, 1] }}
                          transition={{ repeat: Infinity, duration: 1 }}
                        >
                          <Mic className="h-4 w-4 text-primary" />
                        </motion.div>
                        <span className="text-sm">Listening...</span>
                      </div>
                    )}

                    {transcript && (
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <p className="text-sm text-white">
                          <strong>You said:</strong> {transcript}
                        </p>
                      </div>
                    )}

                    {response && (
                      <div className="p-2 bg-secondary/10 rounded-lg">
                        <p className="text-sm text-white">
                          <strong>Assistant:</strong> {response}
                        </p>
                      </div>
                    )}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2">
                  <Button
                    onClick={isListening ? stopListening : startListening}
                    disabled={isSpeaking}
                    className={`${
                      isListening 
                        ? 'bg-red-500 hover:bg-red-600' 
                        : 'bg-primary hover:bg-primary/90'
                    } text-white`}
                  >
                    {isListening ? (
                      <>
                        <MicOff className="h-4 w-4 mr-2" />
                        Stop
                      </>
                    ) : (
                      <>
                        <Mic className="h-4 w-4 mr-2" />
                        Talk
                      </>
                    )}
                  </Button>

                  <Button
                    onClick={isSpeaking ? stopSpeaking : () => speak('How can I help you with your taxes today?')}
                    variant="outline"
                    className="text-white border-primary/20 hover:bg-primary/10"
                  >
                    {isSpeaking ? (
                      <>
                        <VolumeX className="h-4 w-4 mr-2" />
                        Mute
                      </>
                    ) : (
                      <>
                        <Volume2 className="h-4 w-4 mr-2" />
                        Test
                      </>
                    )}
                  </Button>
                </div>

                <div className="text-xs text-white/70 space-y-1">
                  <p><strong>Try saying:</strong></p>
                  <ul className="space-y-1 ml-2">
                    <li>• "Calculate my tax"</li>
                    <li>• "Show my CIBIL score"</li>
                    <li>• "What is section 80C?"</li>
                    <li>• "Go to dashboard"</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Action Button */}
      <motion.div
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <Button
          size="lg"
          onClick={() => setIsMinimized(!isMinimized)}
          className={`rounded-full w-14 h-14 shadow-lg ${
            isListening 
              ? 'bg-red-500 hover:bg-red-600 animate-pulse' 
              : isSpeaking 
              ? 'bg-blue-500 hover:bg-blue-600' 
              : 'bg-primary hover:bg-primary/90'
          } text-white`}
        >
          {isListening ? (
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ repeat: Infinity, duration: 0.5 }}
            >
              <Mic className="h-6 w-6" />
            </motion.div>
          ) : isSpeaking ? (
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 0.8 }}
            >
              <Volume2 className="h-6 w-6" />
            </motion.div>
          ) : (
            <MessageSquare className="h-6 w-6" />
          )}
        </Button>
      </motion.div>

      {/* Status badges */}
      <AnimatePresence>
        {(isListening || isSpeaking) && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="absolute -top-2 -left-2"
          >
            <Badge 
              variant="secondary" 
              className={`text-xs ${
                isListening ? 'bg-red-500' : 'bg-blue-500'
              } text-white`}
            >
              {isListening ? 'Listening' : 'Speaking'}
            </Badge>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}