import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Separator } from '../ui/separator';
import { 
  Calculator, 
  Calendar, 
  FileText, 
  Upload, 
  AlertCircle, 
  CheckCircle, 
  Clock,
  IndianRupee,
  Building,
  Receipt,
  TrendingUp,
  Download
} from 'lucide-react';
import { useLanguage } from '../language/LanguageProvider';

interface GSTCalculation {
  amount: number;
  cgst: number;
  sgst: number;
  igst: number;
  total: number;
  gstRate: number;
}

interface GSTInvoice {
  id: string;
  number: string;
  date: string;
  amount: number;
  gst: number;
  type: 'sale' | 'purchase';
  status: 'pending' | 'filed';
}

export function GSTAssistant() {
  const { t } = useLanguage();
  const [calculation, setCalculation] = useState<GSTCalculation>({
    amount: 0,
    cgst: 0,
    sgst: 0,
    igst: 0,
    total: 0,
    gstRate: 18
  });

  const [invoices] = useState<GSTInvoice[]>([
    {
      id: '1',
      number: 'INV-001',
      date: '2024-01-15',
      amount: 50000,
      gst: 9000,
      type: 'sale',
      status: 'filed'
    },
    {
      id: '2',
      number: 'INV-002',
      date: '2024-01-20',
      amount: 25000,
      gst: 4500,
      type: 'purchase',
      status: 'pending'
    }
  ]);

  const calculateGST = (amount: number, rate: number, isIntraState: boolean = true) => {
    const gstAmount = (amount * rate) / 100;
    
    if (isIntraState) {
      // CGST + SGST
      const cgst = gstAmount / 2;
      const sgst = gstAmount / 2;
      setCalculation({
        amount,
        cgst,
        sgst,
        igst: 0,
        total: amount + gstAmount,
        gstRate: rate
      });
    } else {
      // IGST
      setCalculation({
        amount,
        cgst: 0,
        sgst: 0,
        igst: gstAmount,
        total: amount + gstAmount,
        gstRate: rate
      });
    }
  };

  const gstRates = [
    { value: 0, label: '0% - Essential goods' },
    { value: 5, label: '5% - Household goods' },
    { value: 12, label: '12% - Business services' },
    { value: 18, label: '18% - Most services' },
    { value: 28, label: '28% - Luxury items' }
  ];

  const upcomingDueDates = [
    { date: '2024-02-20', type: 'GSTR-1', status: 'upcoming' },
    { date: '2024-02-22', type: 'GSTR-3B', status: 'upcoming' },
    { date: '2024-03-20', type: 'GSTR-1', status: 'future' }
  ];

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-white">GST Assistant</h1>
        <p className="text-white/70">Comprehensive GST management for freelancers and small businesses</p>
      </div>

      <Tabs defaultValue="calculator" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="calculator" className="flex items-center gap-2 text-white">
            <Calculator className="h-4 w-4" />
            Calculator
          </TabsTrigger>
          <TabsTrigger value="invoices" className="flex items-center gap-2 text-white">
            <Receipt className="h-4 w-4" />
            Invoices
          </TabsTrigger>
          <TabsTrigger value="compliance" className="flex items-center gap-2 text-white">
            <Calendar className="h-4 w-4" />
            Compliance
          </TabsTrigger>
          <TabsTrigger value="reports" className="flex items-center gap-2 text-white">
            <FileText className="h-4 w-4" />
            Reports
          </TabsTrigger>
        </TabsList>

        {/* GST Calculator */}
        <TabsContent value="calculator" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-background/50 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  GST Calculator
                </CardTitle>
                <CardDescription className="text-white/70">
                  Calculate GST for your transactions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="amount" className="text-white">Taxable Amount (₹)</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="Enter amount"
                    className="bg-background/50 border-primary/20 text-white"
                    onChange={(e) => {
                      const amount = parseFloat(e.target.value) || 0;
                      calculateGST(amount, calculation.gstRate);
                    }}
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-white">GST Rate</Label>
                  <Select
                    value={calculation.gstRate.toString()}
                    onValueChange={(value) => {
                      const rate = parseFloat(value);
                      calculateGST(calculation.amount, rate);
                    }}
                  >
                    <SelectTrigger className="bg-background/50 border-primary/20 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-background border-primary/20">
                      {gstRates.map((rate) => (
                        <SelectItem key={rate.value} value={rate.value.toString()} className="text-white">
                          {rate.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-white">Transaction Type</Label>
                  <Select defaultValue="intrastate">
                    <SelectTrigger className="bg-background/50 border-primary/20 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-background border-primary/20">
                      <SelectItem value="intrastate" className="text-white">Intra-state (CGST + SGST)</SelectItem>
                      <SelectItem value="interstate" className="text-white">Inter-state (IGST)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-background/50 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white">GST Breakdown</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-white/70">Taxable Amount:</span>
                    <span className="text-white font-medium">₹{calculation.amount.toLocaleString()}</span>
                  </div>
                  
                  {calculation.cgst > 0 && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-white/70">CGST ({calculation.gstRate/2}%):</span>
                        <span className="text-white font-medium">₹{calculation.cgst.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70">SGST ({calculation.gstRate/2}%):</span>
                        <span className="text-white font-medium">₹{calculation.sgst.toLocaleString()}</span>
                      </div>
                    </>
                  )}
                  
                  {calculation.igst > 0 && (
                    <div className="flex justify-between">
                      <span className="text-white/70">IGST ({calculation.gstRate}%):</span>
                      <span className="text-white font-medium">₹{calculation.igst.toLocaleString()}</span>
                    </div>
                  )}
                  
                  <Separator className="bg-primary/20" />
                  <div className="flex justify-between text-lg">
                    <span className="text-white font-medium">Total Amount:</span>
                    <span className="text-white font-bold">₹{calculation.total.toLocaleString()}</span>
                  </div>
                </div>

                <Button className="w-full bg-primary hover:bg-primary/90 text-white">
                  Generate Invoice
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Invoice Management */}
        <TabsContent value="invoices" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-white">Invoice Management</h3>
            <Button className="bg-primary hover:bg-primary/90 text-white">
              <Upload className="h-4 w-4 mr-2" />
              Upload Invoice
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card className="bg-background/50 border-primary/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Total Sales</p>
                    <p className="text-white text-2xl font-bold">₹75,000</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-background/50 border-primary/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">GST Collected</p>
                    <p className="text-white text-2xl font-bold">₹13,500</p>
                  </div>
                  <IndianRupee className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-background/50 border-primary/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Pending Invoices</p>
                    <p className="text-white text-2xl font-bold">1</p>
                  </div>
                  <Clock className="h-8 w-8 text-yellow-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-background/50 border-primary/20">
            <CardHeader>
              <CardTitle className="text-white">Recent Invoices</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {invoices.map((invoice) => (
                  <div key={invoice.id} className="flex items-center justify-between p-4 bg-background/30 rounded-lg">
                    <div className="flex items-center gap-4">
                      <Receipt className="h-5 w-5 text-primary" />
                      <div>
                        <p className="text-white font-medium">{invoice.number}</p>
                        <p className="text-white/70 text-sm">{invoice.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-medium">₹{invoice.amount.toLocaleString()}</p>
                      <p className="text-white/70 text-sm">GST: ₹{invoice.gst.toLocaleString()}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant={invoice.status === 'filed' ? 'default' : 'secondary'}
                        className={invoice.status === 'filed' ? 'bg-green-500' : 'bg-yellow-500'}
                      >
                        {invoice.status}
                      </Badge>
                      <Badge variant="outline" className="text-white border-primary/20">
                        {invoice.type}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Compliance Calendar */}
        <TabsContent value="compliance" className="space-y-6">
          <Card className="bg-background/50 border-primary/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                GST Compliance Calendar
              </CardTitle>
              <CardDescription className="text-white/70">
                Never miss a GST filing deadline
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {upcomingDueDates.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-background/30 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className={`w-3 h-3 rounded-full ${
                      item.status === 'upcoming' ? 'bg-red-500' : 'bg-yellow-500'
                    }`}></div>
                    <div>
                      <p className="text-white font-medium">{item.type}</p>
                      <p className="text-white/70 text-sm">{item.date}</p>
                    </div>
                  </div>
                  <Badge 
                    variant={item.status === 'upcoming' ? 'destructive' : 'secondary'}
                    className={item.status === 'upcoming' ? 'bg-red-500' : 'bg-yellow-500'}
                  >
                    {item.status === 'upcoming' ? 'Due Soon' : 'Upcoming'}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-background/50 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white">Filing Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-white/70">GSTR-1 (January)</span>
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/70">GSTR-3B (January)</span>
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/70">GSTR-1 (February)</span>
                    <AlertCircle className="h-5 w-5 text-red-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-background/50 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full bg-primary hover:bg-primary/90 text-white justify-start">
                  <FileText className="h-4 w-4 mr-2" />
                  File GSTR-3B
                </Button>
                <Button variant="outline" className="w-full text-white border-primary/20 hover:bg-primary/10 justify-start">
                  <Download className="h-4 w-4 mr-2" />
                  Download GSTR-1
                </Button>
                <Button variant="outline" className="w-full text-white border-primary/20 hover:bg-primary/10 justify-start">
                  <Building className="h-4 w-4 mr-2" />
                  Update Business Info
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Reports */}
        <TabsContent value="reports" className="space-y-6">
          <Card className="bg-background/50 border-primary/20">
            <CardHeader>
              <CardTitle className="text-white">GST Reports</CardTitle>
              <CardDescription className="text-white/70">
                Detailed analysis of your GST transactions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button className="h-16 bg-primary hover:bg-primary/90 text-white justify-start">
                  <div className="flex flex-col items-start">
                    <span className="font-medium">Monthly GST Report</span>
                    <span className="text-xs opacity-70">Detailed monthly breakdown</span>
                  </div>
                </Button>
                <Button variant="outline" className="h-16 text-white border-primary/20 hover:bg-primary/10 justify-start">
                  <div className="flex flex-col items-start">
                    <span className="font-medium">Annual Summary</span>
                    <span className="text-xs opacity-70">Yearly GST analysis</span>
                  </div>
                </Button>
                <Button variant="outline" className="h-16 text-white border-primary/20 hover:bg-primary/10 justify-start">
                  <div className="flex flex-col items-start">
                    <span className="font-medium">Input Tax Credit</span>
                    <span className="text-xs opacity-70">ITC reconciliation</span>
                  </div>
                </Button>
                <Button variant="outline" className="h-16 text-white border-primary/20 hover:bg-primary/10 justify-start">
                  <div className="flex flex-col items-start">
                    <span className="font-medium">Export Report</span>
                    <span className="text-xs opacity-70">Download all data</span>
                  </div>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}