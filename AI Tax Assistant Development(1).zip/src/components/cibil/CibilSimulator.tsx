import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Slider } from '../ui/slider';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Progress } from '../ui/progress';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { 
  TrendingUp, 
  TrendingDown, 
  AlertCircle, 
  CheckCircle, 
  Calculator,
  Target,
  CreditCard,
  Calendar,
  IndianRupee,
  Lightbulb,
  BarChart3
} from 'lucide-react';

interface SimulationScenario {
  id: string;
  name: string;
  description: string;
  currentValue: number;
  newValue: number;
  impact: number;
  color: string;
}

export function CibilSimulator() {
  const [currentScore, setCurrentScore] = useState(742);
  const [userProfile, setUserProfile] = useState({
    totalCreditLimit: 500000,
    currentDebt: 325000,
    monthlyIncome: 75000,
    existingLoans: 2,
    creditHistory: 5, // years
    paymentHistory: 95 // % on time
  });
  
  const [scenarios, setScenarios] = useState<SimulationScenario[]>([
    {
      id: 'debt_reduction',
      name: 'Reduce Credit Card Debt',
      description: 'Pay down credit card balances to reduce utilization',
      currentValue: 65, // Current utilization %
      newValue: 30, // Target utilization %
      impact: 35,
      color: 'green'
    },
    {
      id: 'new_credit_line',
      name: 'Increase Credit Limit',
      description: 'Request higher credit limit or new credit card',
      currentValue: 500000, // Current total limit
      newValue: 750000, // New total limit
      impact: 25,
      color: 'blue'
    },
    {
      id: 'loan_closure',
      name: 'Close Personal Loan',
      description: 'Pay off and close existing personal loan',
      currentValue: 1, // Has loan
      newValue: 0, // No loan
      impact: 15,
      color: 'purple'
    },
    {
      id: 'missed_payment',
      name: 'Payment Delay Impact',
      description: 'What happens if you miss a payment',
      currentValue: 0, // No missed payments
      newValue: 1, // One missed payment
      impact: -45,
      color: 'red'
    },
    {
      id: 'new_loan',
      name: 'Take New Personal Loan',
      description: 'Impact of applying for a new personal loan',
      currentValue: 0,
      newValue: 1,
      impact: -25,
      color: 'orange'
    },
    {
      id: 'close_old_card',
      name: 'Close Oldest Credit Card',
      description: 'Impact of closing your oldest credit card',
      currentValue: 0,
      newValue: 1,
      impact: -20,
      color: 'red'
    }
  ]);

  const updateScenario = (id: string, newValue: number) => {
    setScenarios(prev => prev.map(scenario => 
      scenario.id === id 
        ? { ...scenario, newValue }
        : scenario
    ));
  };

  const getProjectedScore = () => {
    const totalImpact = scenarios.reduce((sum, scenario) => {
      if (scenario.id === 'debt_reduction') {
        // Calculate impact based on utilization reduction
        const utilizationDrop = scenario.currentValue - scenario.newValue;
        return sum + (utilizationDrop * 0.8); // 0.8 points per % reduction
      }
      if (scenario.id === 'new_credit_line') {
        // Calculate impact based on credit limit increase
        const limitIncrease = (scenario.newValue - scenario.currentValue) / scenario.currentValue;
        return sum + (limitIncrease * 50); // Impact based on % increase
      }
      return sum + (scenario.newValue !== scenario.currentValue ? scenario.impact : 0);
    }, 0);
    
    return Math.max(300, Math.min(900, currentScore + Math.round(totalImpact)));
  };

  const getScoreColor = (score: number) => {
    if (score >= 800) return 'text-green-500';
    if (score >= 750) return 'text-blue-500';
    if (score >= 700) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 800) return 'Excellent';
    if (score >= 750) return 'Very Good';
    if (score >= 700) return 'Good';
    if (score >= 650) return 'Fair';
    return 'Poor';
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-white">Advanced CIBIL Score Simulator</h1>
        <p className="text-white/70">Run detailed "what-if" scenarios to understand how different actions affect your credit score</p>
      </div>

      <Tabs defaultValue="simulator" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="simulator" className="flex items-center gap-2 text-white">
            <Calculator className="h-4 w-4" />
            Simulator
          </TabsTrigger>
          <TabsTrigger value="profile" className="flex items-center gap-2 text-white">
            <Target className="h-4 w-4" />
            Profile
          </TabsTrigger>
          <TabsTrigger value="timeline" className="flex items-center gap-2 text-white">
            <Calendar className="h-4 w-4" />
            Timeline
          </TabsTrigger>
          <TabsTrigger value="insights" className="flex items-center gap-2 text-white">
            <Lightbulb className="h-4 w-4" />
            Insights
          </TabsTrigger>
        </TabsList>

        <TabsContent value="simulator" className="space-y-6">
          {/* Current vs Projected Score */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-background/50 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white">Current CIBIL Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center space-y-2">
                  <div className={`text-4xl font-bold ${getScoreColor(currentScore)}`}>
                    {currentScore}
                  </div>
                  <Badge variant="secondary" className="text-white bg-primary/20">{getScoreLabel(currentScore)}</Badge>
                  <Progress value={(currentScore - 300) / 6} className="w-full mt-4" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-primary/20 to-primary/10 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white">Projected Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center space-y-2">
                  <div className={`text-4xl font-bold ${getScoreColor(getProjectedScore())}`}>
                    {getProjectedScore()}
                  </div>
                  <Badge variant="secondary" className="text-white bg-primary/20">{getScoreLabel(getProjectedScore())}</Badge>
                  <div className="flex items-center justify-center mt-2">
                    {getProjectedScore() > currentScore ? (
                      <div className="flex items-center text-green-500">
                        <TrendingUp className="w-4 h-4 mr-1" />
                        <span className="text-sm">+{getProjectedScore() - currentScore} points</span>
                      </div>
                    ) : getProjectedScore() < currentScore ? (
                      <div className="flex items-center text-red-500">
                        <TrendingDown className="w-4 h-4 mr-1" />
                        <span className="text-sm">{getProjectedScore() - currentScore} points</span>
                      </div>
                    ) : (
                      <div className="flex items-center text-white/70">
                        <span className="text-sm">No change</span>
                      </div>
                    )}
                  </div>
                  <Progress value={(getProjectedScore() - 300) / 6} className="w-full mt-4" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-background/50 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white">Current Utilization</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center space-y-2">
                  <div className="text-4xl font-bold text-white">
                    {Math.round((userProfile.currentDebt / userProfile.totalCreditLimit) * 100)}%
                  </div>
                  <Badge variant="outline" className="text-white border-primary/20">
                    ₹{userProfile.currentDebt.toLocaleString()} / ₹{userProfile.totalCreditLimit.toLocaleString()}
                  </Badge>
                  <Progress 
                    value={(userProfile.currentDebt / userProfile.totalCreditLimit) * 100} 
                    className="w-full mt-4" 
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Multi-Scenario Simulator */}
          <Card className="bg-background/50 border-primary/20">
            <CardHeader>
              <CardTitle className="text-white">Multi-Scenario Simulator</CardTitle>
              <CardDescription className="text-white/70">
                Adjust multiple factors simultaneously to see their combined impact
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="positive" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="positive" className="text-white">Score Improvement</TabsTrigger>
                  <TabsTrigger value="negative" className="text-white">Risk Scenarios</TabsTrigger>
                </TabsList>
                
                <TabsContent value="positive" className="space-y-6 mt-6">
                  {scenarios.filter(s => s.impact > 0).map((scenario) => (
                    <div key={scenario.id} className="space-y-4 p-4 bg-green-500/10 rounded-lg border border-green-500/20">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <h4 className="font-medium text-white">{scenario.name}</h4>
                          <p className="text-sm text-white/70">{scenario.description}</p>
                        </div>
                        <div className="text-right">
                          <CheckCircle className="w-5 h-5 text-green-500 mb-1" />
                          <span className="text-green-400 text-sm font-medium">+{scenario.impact}</span>
                        </div>
                      </div>
                      
                      {scenario.id === 'debt_reduction' && (
                        <div className="space-y-3">
                          <div className="flex justify-between text-sm">
                            <span className="text-white/70">Reduce utilization to:</span>
                            <span className="text-white font-medium">{scenario.newValue}%</span>
                          </div>
                          <Slider
                            value={[scenario.newValue]}
                            onValueChange={(value) => updateScenario(scenario.id, value[0])}
                            max={80}
                            min={5}
                            step={5}
                            className="w-full"
                          />
                          <div className="flex justify-between text-xs text-white/50">
                            <span>5% (Excellent)</span>
                            <span>80% (High Risk)</span>
                          </div>
                          <div className="p-2 bg-primary/5 rounded text-sm text-white/70">
                            💡 Reduce by ₹{Math.round(((userProfile.currentDebt / userProfile.totalCreditLimit * 100) - scenario.newValue) / 100 * userProfile.totalCreditLimit).toLocaleString()} to achieve this
                          </div>
                        </div>
                      )}
                      
                      {scenario.id === 'new_credit_line' && (
                        <div className="space-y-3">
                          <div className="flex justify-between text-sm">
                            <span className="text-white/70">Increase limit to:</span>
                            <span className="text-white font-medium">₹{(scenario.newValue / 100000).toFixed(1)}L</span>
                          </div>
                          <Slider
                            value={[scenario.newValue]}
                            onValueChange={(value) => updateScenario(scenario.id, value[0])}
                            max={2000000}
                            min={userProfile.totalCreditLimit}
                            step={50000}
                            className="w-full"
                          />
                          <div className="flex justify-between text-xs text-white/50">
                            <span>₹{(userProfile.totalCreditLimit/100000).toFixed(1)}L (Current)</span>
                            <span>₹20L (Maximum)</span>
                          </div>
                          <div className="p-2 bg-primary/5 rounded text-sm text-white/70">
                            💡 New utilization would be {Math.round((userProfile.currentDebt / scenario.newValue) * 100)}%
                          </div>
                        </div>
                      )}

                      {scenario.id === 'loan_closure' && (
                        <div className="p-3 bg-primary/5 rounded-lg">
                          <div className="flex items-center justify-between">
                            <span className="text-white/70 text-sm">Close personal loan?</span>
                            <Button
                              variant={scenario.newValue === 0 ? "default" : "outline"}
                              size="sm"
                              onClick={() => updateScenario(scenario.id, scenario.newValue === 0 ? 1 : 0)}
                              className="text-white"
                            >
                              {scenario.newValue === 0 ? 'Yes, Close Loan' : 'Keep Loan Open'}
                            </Button>
                          </div>
                          {scenario.newValue === 0 && (
                            <p className="text-xs text-white/70 mt-2">
                              ✓ Reduces total debt burden and improves credit mix
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </TabsContent>
                
                <TabsContent value="negative" className="space-y-6 mt-6">
                  {scenarios.filter(s => s.impact < 0).map((scenario) => (
                    <div key={scenario.id} className="space-y-4 p-4 bg-red-500/10 rounded-lg border border-red-500/20">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <h4 className="font-medium text-white">{scenario.name}</h4>
                          <p className="text-sm text-white/70">{scenario.description}</p>
                        </div>
                        <div className="text-right">
                          <AlertCircle className="w-5 h-5 text-red-500 mb-1" />
                          <span className="text-red-400 text-sm font-medium">{scenario.impact}</span>
                        </div>
                      </div>
                      
                      <div className="p-3 bg-red-500/5 rounded-lg">
                        <div className="text-sm space-y-2">
                          <div className="flex justify-between">
                            <span className="text-white/70">Immediate Impact:</span>
                            <span className="text-red-400">{scenario.impact} points</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-white/70">Recovery Time:</span>
                            <span className="text-white">
                              {scenario.id === 'missed_payment' ? '3-6 months' : 
                               scenario.id === 'new_loan' ? '1-2 months' : '6-12 months'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Credit Profile Management */}
        <TabsContent value="profile" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-background/50 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white">Your Credit Profile</CardTitle>
                <CardDescription className="text-white/70">
                  Update your details for more accurate simulations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white">Monthly Income</Label>
                    <Input
                      type="number"
                      value={userProfile.monthlyIncome}
                      onChange={(e) => setUserProfile(prev => ({ ...prev, monthlyIncome: Number(e.target.value) }))}
                      className="bg-background/50 border-primary/20 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white">Credit History (Years)</Label>
                    <Input
                      type="number"
                      value={userProfile.creditHistory}
                      onChange={(e) => setUserProfile(prev => ({ ...prev, creditHistory: Number(e.target.value) }))}
                      className="bg-background/50 border-primary/20 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white">Total Credit Limit</Label>
                    <Input
                      type="number"
                      value={userProfile.totalCreditLimit}
                      onChange={(e) => setUserProfile(prev => ({ ...prev, totalCreditLimit: Number(e.target.value) }))}
                      className="bg-background/50 border-primary/20 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white">Current Debt</Label>
                    <Input
                      type="number"
                      value={userProfile.currentDebt}
                      onChange={(e) => setUserProfile(prev => ({ ...prev, currentDebt: Number(e.target.value) }))}
                      className="bg-background/50 border-primary/20 text-white"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-background/50 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white">Credit Health Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-white/70">Credit Utilization</span>
                      <span className="text-white">{Math.round((userProfile.currentDebt / userProfile.totalCreditLimit) * 100)}%</span>
                    </div>
                    <Progress value={(userProfile.currentDebt / userProfile.totalCreditLimit) * 100} />
                    <p className="text-xs text-white/50 mt-1">
                      {(userProfile.currentDebt / userProfile.totalCreditLimit) * 100 <= 30 ? 'Excellent' : 
                       (userProfile.currentDebt / userProfile.totalCreditLimit) * 100 <= 50 ? 'Good' : 
                       (userProfile.currentDebt / userProfile.totalCreditLimit) * 100 <= 70 ? 'Fair' : 'Poor'}
                    </p>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-white/70">Payment History</span>
                      <span className="text-white">{userProfile.paymentHistory}%</span>
                    </div>
                    <Progress value={userProfile.paymentHistory} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-white/70">Credit History</span>
                      <span className="text-white">{userProfile.creditHistory} years</span>
                    </div>
                    <Progress value={Math.min(100, (userProfile.creditHistory / 10) * 100)} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Timeline & Recovery */}
        <TabsContent value="timeline" className="space-y-6">
          <Card className="bg-background/50 border-primary/20">
            <CardHeader>
              <CardTitle className="text-white">Score Improvement Timeline</CardTitle>
              <CardDescription className="text-white/70">
                Track your expected score improvements over time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {[1, 3, 6, 12].map(months => {
                  const projectedImprovement = Math.round((getProjectedScore() - currentScore) * (months / 12));
                  const futureScore = Math.min(900, currentScore + projectedImprovement);
                  
                  return (
                    <div key={months} className="flex items-center justify-between p-4 bg-primary/5 rounded-lg">
                      <div className="flex items-center gap-4">
                        <Calendar className="h-5 w-5 text-primary" />
                        <div>
                          <h4 className="text-white font-medium">{months} Month{months > 1 ? 's' : ''}</h4>
                          <p className="text-white/70 text-sm">Expected progress checkpoint</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-bold text-white">{futureScore}</div>
                        <div className="text-sm text-green-400">
                          +{projectedImprovement} points
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* AI Insights */}
        <TabsContent value="insights" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-background/50 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Lightbulb className="h-5 w-5" />
                  AI Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 bg-green-500/10 rounded-lg border border-green-500/20">
                  <h5 className="text-white font-medium text-sm mb-2">Priority Action</h5>
                  <p className="text-white/70 text-sm">
                    Reduce credit utilization to below 30% by paying down ₹{Math.round((userProfile.currentDebt - (userProfile.totalCreditLimit * 0.3))).toLocaleString()}.
                    This could improve your score by 35+ points.
                  </p>
                </div>
                
                <div className="p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
                  <h5 className="text-white font-medium text-sm mb-2">Medium Priority</h5>
                  <p className="text-white/70 text-sm">
                    Request credit limit increases from existing cards to improve your credit utilization ratio automatically.
                  </p>
                </div>
                
                <div className="p-3 bg-yellow-500/10 rounded-lg border border-yellow-500/20">
                  <h5 className="text-white font-medium text-sm mb-2">Long-term Strategy</h5>
                  <p className="text-white/70 text-sm">
                    Maintain payment history above 95% and avoid new credit inquiries for the next 6 months.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-background/50 border-primary/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Score Factors Impact
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-white/70 text-sm">Payment History (35%)</span>
                      <span className="text-green-400 text-sm">Excellent</span>
                    </div>
                    <Progress value={95} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-white/70 text-sm">Credit Utilization (30%)</span>
                      <span className="text-red-400 text-sm">Needs Work</span>
                    </div>
                    <Progress value={65} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-white/70 text-sm">Credit History (15%)</span>
                      <span className="text-blue-400 text-sm">Good</span>
                    </div>
                    <Progress value={75} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-white/70 text-sm">Credit Mix (10%)</span>
                      <span className="text-green-400 text-sm">Good</span>
                    </div>
                    <Progress value={80} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-white/70 text-sm">New Credit (10%)</span>
                      <span className="text-yellow-400 text-sm">Fair</span>
                    </div>
                    <Progress value={60} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

    </div>
  );
}