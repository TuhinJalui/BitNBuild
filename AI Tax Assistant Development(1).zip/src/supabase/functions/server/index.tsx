import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/middleware'
import { createClient } from 'npm:@supabase/supabase-js@2'
import * as kv from './kv_store.tsx'

const app = new Hono()

// CORS configuration
app.use('*', cors({
  origin: '*',
  allowHeaders: ['Content-Type', 'Authorization'],
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']
}))

// Logger
app.use('*', logger(console.log))

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') as string,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') as string,
)

// Health check
app.get('/make-server-a807569f/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() })
})

// User Authentication Routes
app.post('/make-server-a807569f/auth/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json()
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    })

    if (error) {
      return c.json({ error: `Signup error: ${error.message}` }, 400)
    }

    // Store user profile data
    await kv.set(`user_profile_${data.user.id}`, {
      id: data.user.id,
      email,
      name,
      created_at: new Date().toISOString(),
      financial_data: {},
      preferences: {}
    })

    return c.json({ success: true, user: data.user })
  } catch (error) {
    console.log('Signup error:', error)
    return c.json({ error: 'Internal server error during signup' }, 500)
  }
})

// Financial Data Routes
app.get('/make-server-a807569f/user/profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized access to user profile' }, 401)
    }

    const profile = await kv.get(`user_profile_${user.id}`)
    if (!profile) {
      return c.json({ error: 'User profile not found' }, 404)
    }

    return c.json({ profile })
  } catch (error) {
    console.log('Profile fetch error:', error)
    return c.json({ error: 'Internal server error while fetching profile' }, 500)
  }
})

app.put('/make-server-a807569f/user/profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized access to update profile' }, 401)
    }

    const updates = await c.req.json()
    const existingProfile = await kv.get(`user_profile_${user.id}`)
    
    const updatedProfile = {
      ...existingProfile,
      ...updates,
      updated_at: new Date().toISOString()
    }

    await kv.set(`user_profile_${user.id}`, updatedProfile)
    return c.json({ success: true, profile: updatedProfile })
  } catch (error) {
    console.log('Profile update error:', error)
    return c.json({ error: 'Internal server error while updating profile' }, 500)
  }
})

// Tax Calculation Routes
app.post('/make-server-a807569f/tax/calculate', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized access to tax calculation' }, 401)
    }

    const { income, regime, deductions } = await c.req.json()
    
    // Tax calculation logic
    const calculateOldRegimeTax = (taxableIncome: number) => {
      let tax = 0
      if (taxableIncome > 1000000) {
        tax += (taxableIncome - 1000000) * 0.3
        taxableIncome = 1000000
      }
      if (taxableIncome > 500000) {
        tax += (taxableIncome - 500000) * 0.2
        taxableIncome = 500000
      }
      if (taxableIncome > 250000) {
        tax += (taxableIncome - 250000) * 0.05
      }
      return tax
    }

    const calculateNewRegimeTax = (taxableIncome: number) => {
      let tax = 0
      if (taxableIncome > 1500000) {
        tax += (taxableIncome - 1500000) * 0.3
        taxableIncome = 1500000
      }
      if (taxableIncome > 1200000) {
        tax += (taxableIncome - 1200000) * 0.25
        taxableIncome = 1200000
      }
      if (taxableIncome > 900000) {
        tax += (taxableIncome - 900000) * 0.2
        taxableIncome = 900000
      }
      if (taxableIncome > 600000) {
        tax += (taxableIncome - 600000) * 0.15
        taxableIncome = 600000
      }
      if (taxableIncome > 300000) {
        tax += (taxableIncome - 300000) * 0.1
        taxableIncome = 300000
      }
      if (taxableIncome > 250000) {
        tax += (taxableIncome - 250000) * 0.05
      }
      return tax
    }

    let taxLiability = 0
    let taxableIncome = income

    if (regime === 'old') {
      const totalDeductions = (deductions?.section80C || 0) + 
                             (deductions?.section80D || 0) + 
                             (deductions?.hra || 0) + 
                             (deductions?.homeLoan || 0)
      taxableIncome = income - totalDeductions
      taxLiability = calculateOldRegimeTax(taxableIncome)
    } else {
      taxableIncome = income - 50000 // Standard deduction
      taxLiability = calculateNewRegimeTax(taxableIncome)
    }

    const calculation = {
      income,
      regime,
      deductions,
      taxableIncome,
      taxLiability,
      effectiveRate: (taxLiability / income) * 100,
      takeHome: income - taxLiability,
      calculated_at: new Date().toISOString()
    }

    // Save calculation history
    const historyKey = `tax_calculations_${user.id}`
    const existingHistory = await kv.get(historyKey) || []
    const updatedHistory = [calculation, ...existingHistory.slice(0, 9)] // Keep last 10 calculations
    await kv.set(historyKey, updatedHistory)

    return c.json({ success: true, calculation })
  } catch (error) {
    console.log('Tax calculation error:', error)
    return c.json({ error: 'Internal server error during tax calculation' }, 500)
  }
})

app.get('/make-server-a807569f/tax/history', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized access to tax history' }, 401)
    }

    const history = await kv.get(`tax_calculations_${user.id}`) || []
    return c.json({ history })
  } catch (error) {
    console.log('Tax history fetch error:', error)
    return c.json({ error: 'Internal server error while fetching tax history' }, 500)
  }
})

// CIBIL Score Management
app.post('/make-server-a807569f/cibil/update', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized access to CIBIL data update' }, 401)
    }

    const { score, factors } = await c.req.json()
    
    const cibilData = {
      score,
      factors,
      updated_at: new Date().toISOString()
    }

    // Save CIBIL history
    const historyKey = `cibil_history_${user.id}`
    const existingHistory = await kv.get(historyKey) || []
    const updatedHistory = [cibilData, ...existingHistory.slice(0, 11)] // Keep last 12 months
    await kv.set(historyKey, updatedHistory)

    return c.json({ success: true, cibilData })
  } catch (error) {
    console.log('CIBIL update error:', error)
    return c.json({ error: 'Internal server error during CIBIL update' }, 500)
  }
})

app.get('/make-server-a807569f/cibil/history', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized access to CIBIL history' }, 401)
    }

    const history = await kv.get(`cibil_history_${user.id}`) || []
    return c.json({ history })
  } catch (error) {
    console.log('CIBIL history fetch error:', error)
    return c.json({ error: 'Internal server error while fetching CIBIL history' }, 500)
  }
})

// Financial Insights and Recommendations
app.get('/make-server-a807569f/insights/recommendations', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized access to recommendations' }, 401)
    }

    const profile = await kv.get(`user_profile_${user.id}`)
    const taxHistory = await kv.get(`tax_calculations_${user.id}`) || []
    const cibilHistory = await kv.get(`cibil_history_${user.id}`) || []

    // Generate AI-powered recommendations based on user data
    const recommendations = []

    if (taxHistory.length > 0) {
      const latestCalculation = taxHistory[0]
      if (latestCalculation.effectiveRate > 20) {
        recommendations.push({
          type: 'tax_saving',
          priority: 'high',
          title: 'High Tax Liability Detected',
          description: 'Consider maximizing your 80C deductions with ELSS investments',
          action: 'Invest in ELSS mutual funds',
          potential_saving: Math.min(50000, latestCalculation.taxLiability * 0.3)
        })
      }
    }

    if (cibilHistory.length > 0) {
      const latestScore = cibilHistory[0]
      if (latestScore.score < 750) {
        recommendations.push({
          type: 'credit_improvement',
          priority: 'medium',
          title: 'CIBIL Score Improvement Opportunity',
          description: 'Your credit score can be improved with better credit utilization',
          action: 'Reduce credit card utilization below 30%',
          potential_improvement: 25
        })
      }
    }

    await kv.set(`recommendations_${user.id}`, {
      recommendations,
      generated_at: new Date().toISOString()
    })

    return c.json({ recommendations })
  } catch (error) {
    console.log('Recommendations generation error:', error)
    return c.json({ error: 'Internal server error while generating recommendations' }, 500)
  }
})

// Voice Assistant Chat Integration
app.post('/make-server-a807569f/chat/voice', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized access to voice chat' }, 401)
    }

    const { message, intent } = await c.req.json()
    
    let response = ''
    
    switch (intent) {
      case 'tax_calculation':
        response = 'I can help you calculate your taxes. Please provide your annual income and preferred tax regime.'
        break
      case 'cibil_inquiry':
        const cibilHistory = await kv.get(`cibil_history_${user.id}`) || []
        if (cibilHistory.length > 0) {
          const latestScore = cibilHistory[0].score
          response = `Your current CIBIL score is ${latestScore}. ${latestScore >= 750 ? 'Excellent credit health!' : 'There are opportunities to improve your score.'}`
        } else {
          response = 'I don\'t have your current CIBIL score data. Would you like to update it?'
        }
        break
      case 'recommendations':
        const recommendations = await kv.get(`recommendations_${user.id}`)
        if (recommendations?.recommendations?.length > 0) {
          response = `I have ${recommendations.recommendations.length} personalized recommendations for you. The top priority is: ${recommendations.recommendations[0].title}`
        } else {
          response = 'Let me generate some personalized recommendations based on your financial data.'
        }
        break
      default:
        response = 'I can help you with tax calculations, CIBIL score analysis, and financial recommendations. What would you like to know?'
    }

    // Save chat history
    const chatKey = `voice_chats_${user.id}`
    const existingChats = await kv.get(chatKey) || []
    const newChat = {
      message,
      response,
      intent,
      timestamp: new Date().toISOString()
    }
    const updatedChats = [newChat, ...existingChats.slice(0, 49)] // Keep last 50 chats
    await kv.set(chatKey, updatedChats)

    return c.json({ response, intent })
  } catch (error) {
    console.log('Voice chat error:', error)
    return c.json({ error: 'Internal server error during voice chat processing' }, 500)
  }
})

// Document Storage (File Upload) Routes
app.post('/make-server-a807569f/documents/upload', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized access to document upload' }, 401)
    }

    // Create bucket if it doesn't exist
    const bucketName = `make-a807569f-documents-${user.id}`
    const { data: buckets } = await supabase.storage.listBuckets()
    const bucketExists = buckets?.some(bucket => bucket.name === bucketName)
    
    if (!bucketExists) {
      await supabase.storage.createBucket(bucketName, { private: true })
    }

    const { fileName, fileData, fileType } = await c.req.json()
    
    // Upload file to Supabase Storage
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from(bucketName)
      .upload(`${Date.now()}-${fileName}`, fileData, {
        contentType: fileType
      })

    if (uploadError) {
      return c.json({ error: `File upload error: ${uploadError.message}` }, 400)
    }

    // Create signed URL for access
    const { data: signedUrlData } = await supabase.storage
      .from(bucketName)
      .createSignedUrl(uploadData.path, 60 * 60 * 24 * 7) // 1 week expiry

    // Save document metadata
    const documentData = {
      id: crypto.randomUUID(),
      fileName,
      fileType,
      filePath: uploadData.path,
      signedUrl: signedUrlData?.signedUrl,
      uploadedAt: new Date().toISOString(),
      userId: user.id
    }

    const documentsKey = `documents_${user.id}`
    const existingDocuments = await kv.get(documentsKey) || []
    const updatedDocuments = [documentData, ...existingDocuments]
    await kv.set(documentsKey, updatedDocuments)

    return c.json({ success: true, document: documentData })
  } catch (error) {
    console.log('Document upload error:', error)
    return c.json({ error: 'Internal server error during document upload' }, 500)
  }
})

app.get('/make-server-a807569f/documents/list', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized access to documents list' }, 401)
    }

    const documents = await kv.get(`documents_${user.id}`) || []
    return c.json({ documents })
  } catch (error) {
    console.log('Documents list fetch error:', error)
    return c.json({ error: 'Internal server error while fetching documents' }, 500)
  }
})

Deno.serve(app.fetch)